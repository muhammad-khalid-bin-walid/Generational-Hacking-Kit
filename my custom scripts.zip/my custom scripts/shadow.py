import paramiko
import logging
from getpass import getpass

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def exploit_ssh():
    # Prompt the user for input
    target = input("Enter the target IP address: ")
    username = input("Enter the username: ")
    password = getpass("Enter the password: ")  # Use getpass for secure password input
    command = input("Enter the command to execute (default: 'ls'): ") or "ls"  # Default to 'ls' if no command is provided

    try:
        # Log the start of the connection attempt
        logging.info(f"Attempting to connect to {target} as {username}...")

        # Create SSH client
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Connect with a timeout of 10 seconds
        client.connect(target, username=username, password=password, timeout=10)

        # Log successful connection
        logging.info(f"Connected to {target}. Executing command: {command}")

        # Execute the command
        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode()
        errors = stderr.read().decode()

        # Print the output and errors
        if output:
            print("Command Output:")
            print(output)
        if errors:
            print("Command Errors:")
            print(errors)

        # Close the connection
        client.close()
        logging.info("Connection closed.")

    except paramiko.AuthenticationException:
        logging.error("Authentication failed. Check username and password.")
    except paramiko.SSHException as e:
        logging.error(f"SSH error: {str(e)}")
    except paramiko.ssh_exception.NoValidConnectionsError:
        logging.error("Unable to connect to the target. Check if the IP is correct and SSH is running.")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {str(e)}")

# Run the exploit function directly
exploit_ssh()
