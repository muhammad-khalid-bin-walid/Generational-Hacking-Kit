import phonenumbers
from phonenumbers import geocoder, carrier

def get_phone_details(phone_number):
    try:
        # Parse the phone number
        parsed_number = phonenumbers.parse(phone_number)

        # Get the location information
        location = geocoder.description_for_number(parsed_number, "en")

        # Get the carrier information
        carrier_info = carrier.name_for_number(parsed_number, "en")

        return location, carrier_info
    except phonenumbers.phonenumberutil.NumberParseException as e:
        return f"Error parsing phone number: {e}", None

if __name__ == "__main__":
    phone_number = input("Enter the phone number to track (include country code): ")
    location, carrier_info = get_phone_details(phone_number)
    if carrier_info:
        print(f"The phone number {phone_number} is located in: {location}")
        print(f"The carrier for the phone number is: {carrier_info}")
    else:
        print(location)
