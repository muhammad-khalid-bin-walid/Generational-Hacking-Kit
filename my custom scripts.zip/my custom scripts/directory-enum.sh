# Enumerate common directories and files on the web server
nmap --script http-enum -p 80,443 stage.opsci.smce.nasa.gov

# Generate a sitemap by spidering the target website
nmap --script http-sitemap-generator -p 80,443 stage.opsci.smce.nasa.gov

# Search for backup files on the web server
nmap --script http-backup-finder -p 80,443 stage.opsci.smce.nasa.gov

# Check for backup configuration files on the web server
nmap --script http-config-backup -p 80,443 stage.opsci.smce.nasa.gov

# Fetch and parse the robots.txt file to identify disallowed directories
nmap --script http-robots.txt -p 80,443 stage.opsci.smce.nasa.gov

# Enumerate the HTTP methods supported by the web server
nmap --script http-methods -p 80,443 stage.opsci.smce.nasa.gov

# Identify the web application framework used by the target server
nmap --script http-devframework -p 80,443 stage.opsci.smce.nasa.gov

# Perform brute force password auditing against web applications
nmap --script http-brute -p 80,443 stage.opsci.smce.nasa.gov

# Check for the Apache Struts 2 vulnerability (CVE-2017-5638)
nmap --script http-vuln-cve2017-5638 -p 80,443 stage.opsci.smce.nasa.gov
