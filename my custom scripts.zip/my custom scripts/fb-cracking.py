from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse

class PhishingHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Serve the fake login page
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"""
                <html>
                <body>
                    <h2>Facebook Login</h2>
                    <form method="POST" action="/login">
                        <label>Username:</label><input type="text" name="username"><br>
                        <label>Password:</label><input type="password" name="password"><br>
                        <input type="submit" value="Login">
                    </form>
                </body>
                </html>
            """)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        # Handle form submission
        if self.path == "/login":
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length).decode('utf-8')
            params = urllib.parse.parse_qs(post_data)
            username = params.get('username', [''])[0]
            password = params.get('password', [''])[0]
            
            # Simulate capturing credentials (printed to console)
            print(f"Captured credentials: {username}/{password}")
            
            # Show educational message
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"""
                <html>
                <body>
                    <h2>Phishing Simulation</h2>
                    <p>This was a simulated phishing attempt. Your credentials were not stored or misused.</p>
                    <p><strong>Prevention Tips:</strong></p>
                    <ul>
                        <li>Always check the URL before entering credentials.</li>
                        <li>Look for HTTPS in the address bar.</li>
                        <li>Be wary of unsolicited emails or messages asking for login details.</li>
                    </ul>
                </body>
                </html>
            """)
        else:
            self.send_response(404)
            self.end_headers()

def run_server(port=8000):
    server_address = ('', port)
    httpd = HTTPServer(server_address, PhishingHandler)
    print(f"Server running on port {port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run_server()
