from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, ElementNotInteractableException, TimeoutException

# Set up the webdriver
driver = webdriver.Chrome()

# Navigate to the Facebook page
driver.get("https://www.facebook.com/<page_name>")

# Login to Facebook (replace with your credentials)
username = "your_username"
password = "your_password"

try:
    # Find and enter username
    email_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "email"))
    )
    email_input.send_keys(username)

    # Find and enter password
    pass_input = driver.find_element(By.ID, "pass")
    pass_input.send_keys(password)

    # Find and click login button
    login_button = driver.find_element(By.ID, "loginbutton")
    login_button.click()

    # Wait for the page to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "//div[@class='_4xev']"))
    )

    # Find the "See More" button to expand the list of posts
    see_more = driver.find_element(By.XPATH, "//div[@class='_4xev']")
    driver.execute_script("arguments[0].click();", see_more)

    # Wait for the posts to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[@data-testid='post_message']"))
    )

    # Find all the posts on the page
    posts = driver.find_elements(By.XPATH, "//div[@data-testid='post_message']")

    # Iterate through the posts and report each one
    for post in posts:
        try:
            # Click the "More" button to open the post options
            more_button = post.find_element(By.XPATH, ".//div[@class='_1dwg _1w_m _q7o']")
            driver.execute_script("arguments[0].click();", more_button)

            # Wait for the options menu to appear
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "//span[text()='Report']"))
            )

            # Click the "Report" button
            report_button = driver.find_element(By.XPATH, "//span[text()='Report']")
            driver.execute_script("arguments[0].click();", report_button)

            # Select the "It's spam" option
            spam_option = driver.find_element(By.XPATH, "//span[text()='It's spam']")
            driver.execute_script("arguments[0].click();", spam_option)

            # Click the "Report" button to submit the report
            submit_button = driver.find_element(By.XPATH, "//span[text()='Report']")
            driver.execute_script("arguments[0].click();", submit_button)

            # Wait for the report confirmation message to appear
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Close']"))
            )

            # Close the report confirmation message
            close_button = driver.find_element(By.XPATH, "//div[@aria-label='Close']")
            driver.execute_script("arguments[0].click();", close_button)

            print("Reported post:", post.text)

        except (NoSuchElementException, ElementNotInteractableException, TimeoutException) as e:
            print("Error reporting post:", e)

except Exception as e:
    print("Error during login or navigation:", e)

# Close the webdriver
driver.quit()
