#!/bin/bash

# Define the pip configuration file path
PIP_CONFIG_FILE="$HOME/.config/pip/pip.conf"

# Create the directory if it doesn't exist
mkdir -p "$(dirname "$PIP_CONFIG_FILE")"

# Add the break-system-packages option to the pip configuration
echo "[global]" > "$PIP_CONFIG_FILE"
echo "break-system-packages = true" >> "$PIP_CONFIG_FILE"

# Confirm the changes
echo "The pip configuration has been updated to always use the --break-system-packages option."
echo "Configuration file location: $PIP_CONFIG_FILE"
cat "$PIP_CONFIG_FILE"
