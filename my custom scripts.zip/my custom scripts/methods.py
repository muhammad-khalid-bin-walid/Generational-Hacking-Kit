import requests

url = input("Enter the URL to send requests: ")

# GET request
response_get = requests.get(url)
print("GET request status code:", response_get.status_code)
print("GET request content:", response_get.content)

# POST request
response_post = requests.post(url, data={'key': 'value'})
print("POST request status code:", response_post.status_code)
print("POST request content:", response_post.content)

# DELETE request
response_delete = requests.delete(url)
print("DELETE request status code:", response_delete.status_code)
print("DELETE request content:", response_delete.content)

# PATCH request
response_patch = requests.patch(url, data={'key': 'value'})
print("PATCH request status code:", response_patch.status_code)
print("PATCH request content:", response_patch.content)

# PUT request
response_put = requests.put(url, data={'key': 'value'})
print("PUT request status code:", response_put.status_code)
print("PUT request content:", response_put.content)
