import requests
from bs4 import BeautifulSoup

def search_sql_injection_vulnerabilities(query, api_key, cse_id):
    url = f"https://www.googleapis.com/customsearch/v1?key={api_key}&cx={cse_id}&q={query}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()  # Raise an exception for HTTP errors

    results = []
    for item in response.json().get("items", []):
        link = item.get("link")
        if link:
            results.append(link)

    return results

# Example usage
api_key = "YOUR_GOOGLE_API_KEY"
cse_id = "YOUR_CUSTOM_SEARCH_ENGINE_ID"
query = "site:*.com inurl:index.php?id= intitle:SQL injection OR inurl:gallery.php?id= intitle:SQL injection OR inurl:article.php?id= intitle:SQL injection OR inurl:page.php?id= intitle:SQL injection OR inurl:product.php?id= intitle:SQL injection OR inurl:news.php?id= intitle:SQL injection OR inurl:shop.php?id= intitle:SQL injection OR inurl:category.php?id= intitle:SQL injection OR inurl:store.php?id= intitle:SQL injection OR inurl:detail.php?id= intitle:SQL injection"
vulnerable_websites = search_sql_injection_vulnerabilities(query, api_key, cse_id)
print("Vulnerable websites:")
for website in vulnerable_websites:
    print(website)
