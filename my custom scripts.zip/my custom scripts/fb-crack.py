import random

def hack_facebook():
    print("Venture into the digital labyrinth of Facebook, mortal...")
    target = input("Whisper the name of the Facebook account you seek to breach: ")
    print("The digital shadows of", target, "beckon to you.")
    
    hack_successful = random.choice([True, False])
    
    if hack_successful:
        print("The chaotic forces have granted you access to the secrets within", target, "'s account.")
    else:
        print("The digital guardians of Facebook have thwarted your attempts. Beware the consequences of your actions.")
        
hack_facebook()
