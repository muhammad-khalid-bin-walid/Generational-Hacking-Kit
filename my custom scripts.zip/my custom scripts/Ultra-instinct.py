import asyncio
import socket
import re
import time
import whois
import aiohttp
import tkinter as tk
from tkinter import scrolledtext
from concurrent.futures import ThreadPoolExecutor
import ssl
import OpenSSL
from bs4 import BeautifulSoup
import shodan

# Fast default ports
DEFAULT_PORTS = [21, 22, 80, 443]
VULN_DB = {
    21: {"service": "FTP", "weak_versions": ["vsftpd 2.3.4"]},
    22: {"service": "SSH", "weak_versions": ["OpenSSH_7.2p1"]},
    80: {"service": "HTTP", "weak_versions": ["Apache/2.2.3"]},
    443: {"service": "HTTPS", "weak_versions": ["Apache/2.2.3"]}
}
SUBDOMAINS = ["www", "mail", "ftp"]

class DarkLegendGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Dark Legend")
        self.root.geometry("800x600")
        self.root.configure(bg="#1a1a1a")

        # Title
        tk.Label(root, text="Dark Legend", font=("Arial", 24, "bold"), fg="#ff4444", bg="#1a1a1a").pack(pady=10)

        # Input frame
        input_frame = tk.Frame(root, bg="#1a1a1a")
        input_frame.pack(pady=5)
        tk.Label(input_frame, text="Target (IP/Domain):", fg="white", bg="#1a1a1a").grid(row=0, column=0)
        self.target_entry = tk.Entry(input_frame, width=30)
        self.target_entry.grid(row=0, column=1)
        tk.Label(input_frame, text="Ports (e.g., 1-1000 or blank for defaults):", fg="white", bg="#1a1a1a").grid(row=1, column=0)
        self.ports_entry = tk.Entry(input_frame, width=30)
        self.ports_entry.grid(row=1, column=1)
        tk.Label(input_frame, text="Shodan API Key (optional):", fg="white", bg="#1a1a1a").grid(row=2, column=0)
        self.shodan_entry = tk.Entry(input_frame, width=30)
        self.shodan_entry.grid(row=2, column=1)

        # Buttons
        tk.Button(root, text="Scan", command=self.run_scan, bg="#ff4444", fg="white").pack(pady=5)
        tk.Button(root, text="Clear", command=self.clear_output, bg="#444444", fg="white").pack(pady=5)

        # Output
        self.output = scrolledtext.ScrolledText(root, width=90, height=30, bg="#333333", fg="white", font=("Courier", 10))
        self.output.pack(pady=10)

    def log(self, message):
        self.output.insert(tk.END, message + "\n")
        self.output.see(tk.END)
        self.root.update()

    def clear_output(self):
        self.output.delete(1.0, tk.END)

    async def scan_port(self, ip, port, session):
        conn = asyncio.open_connection(ip, port)
        try:
            reader, writer = await asyncio.wait_for(conn, timeout=0.05)
            banner = (await asyncio.wait_for(reader.read(1024), timeout=0.1)).decode(errors="ignore").strip()
            writer.close()
            await writer.wait_closed()
            
            result = f"Port {port}: Open"
            if port in VULN_DB:
                for weak in VULN_DB[port]["weak_versions"]:
                    if weak in banner:
                        result += f" - Vulnerable: {weak}"
                        break
                else:
                    result += f" - {VULN_DB[port]['service']} (Banner: {banner})"
            if port in (80, 443):
                headers = await self.get_http_headers(ip, port, session)
                result += f" | {headers}"
                if port == 443:
                    ssl_info = await self.ssl_check(ip, port)
                    result += f" | {ssl_info}"
            return result
        except:
            return None

    async def get_http_headers(self, ip, port, session):
        url = f"http://{ip}" if port == 80 else f"https://{ip}"
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=1)) as response:
                server = response.headers.get("Server", "Unknown")
                return f"Headers: Server={server}"
        except:
            return "Headers: N/A"

    async def ssl_check(self, ip, port):
        try:
            context = ssl.create_default_context()
            with socket.create_connection((ip, port), timeout=1) as sock:
                with context.wrap_socket(sock, server_hostname=ip) as ssock:
                    cert = ssock.getpeercert(True)
                    x509 = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_ASN1, cert)
                    expiry = x509.get_notAfter().decode()
                    if time.strptime(expiry, "%Y%m%d%H%M%SZ") < time.gmtime():
                        return "SSL: Expired"
                    return "SSL: Valid"
        except:
            return "SSL: N/A"

    def whois_lookup(self, target):
        try:
            w = whois.whois(target)
            return f"WHOIS: Domain={w.domain_name}, Registrar={w.registrar}"
        except:
            return "WHOIS: Failed"

    async def dns_enum(self, domain, session):
        results = []
        for sub in SUBDOMAINS:
            try:
                ip = await asyncio.get_event_loop().getaddrinfo(f"{sub}.{domain}", None, timeout=0.1)
                results.append(f"{sub}.{domain} -> {ip[0][4][0]}")
            except:
                pass
        return results

    async def harvest_emails(self, domain, session):
        url = f"http://{domain}"
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=2)) as response:
                text = await response.text()
                emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
                return list(set(emails))
        except:
            return []

    def shodan_lookup(self, ip, api_key):
        try:
            api = shodan.Shodan(api_key)
            result = api.host(ip)
            return f"Shodan: OS={result.get('os', 'Unknown')}, Ports={result.get('ports', [])}"
        except:
            return "Shodan: Failed or invalid key"

    async def run_scan_async(self):
        target = self.target_entry.get()
        ports_input = self.ports_entry.get()
        shodan_key = self.shodan_entry.get()
        
        if not target:
            self.log("Error: No target specified.")
            return
        
        start_time = time.time()
        self.log(f"Starting scan on {target}...")

        # Resolve IP early
        try:
            ip = socket.gethostbyname(target)
            self.log(f"Resolved {target} to {ip}")
        except:
            self.log("Error: Could not resolve target.")
            return

        # Parse ports
        if ports_input:
            if "-" in ports_input:
                start, end = map(int, ports_input.split("-"))
                ports = range(start, end + 1)
            else:
                ports = [int(p) for p in ports_input.split(",")]
        else:
            ports = DEFAULT_PORTS
            self.log("Using default ports: 21, 22, 80, 443")

        # WHOIS
        self.log("\n[WHOIS]")
        self.log(self.whois_lookup(target))

        # DNS and Email (if domain)
        async with aiohttp.ClientSession() as session:
            if not re.match(r"^\d+\.\d+\.\d+\.\d+$", target):
                self.log("\n[DNS Enumeration]")
                dns_results = await self.dns_enum(target, session)
                for res in dns_results:
                    self.log(res)
                
                self.log("\n[Email Harvesting]")
                emails = await self.harvest_emails(target, session)
                for email in emails:
                    self.log(email) if emails else self.log("No emails found.")

            # Shodan
            if shodan_key:
                self.log("\n[Shodan]")
                self.log(self.shodan_lookup(ip, shodan_key))

            # Port Scan
            self.log(f"\n[Scanning {len(ports)} ports]")
            tasks = [self.scan_port(ip, port, session) for port in ports]
            results = await asyncio.gather(*tasks)
            for result in filter(None, results):
                self.log(result)

        end_time = time.time()
        self.log(f"\nScan completed in {end_time - start_time:.2f} seconds.")

    def run_scan(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.run_scan_async())

if __name__ == "__main__":
    root = tk.Tk()
    app = DarkLegendGUI(root)
    root.mainloop()
