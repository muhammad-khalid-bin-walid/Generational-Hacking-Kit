import requests
import concurrent.futures
import argparse
import json
import csv
import re
import time
import random
import tkinter as tk
from tkinter import ttk, messagebox
from typing import List, Dict, Tuple
from urllib.parse import quote

# Goku ASCII for CLI flair
GOKU_ASCII = r"""
          __,__
  .--.  .-"     "-.  .--.
 / .. \/  .-. .-.  \/ .. \
| |  '|  /   Y   \  |'  | |
| \   \  |  : :  |  /   / |
 \ '- ,\.-""""""""-./ ,-' /
  ''-' /          \ '-' /
       |  POWER UP!  |
       \  OMNITRACE  /
        \._     _./
          \ '~'~ /
           | : : |
           | : : |
"""

# Simulated platform list (expand this with a real JSON file)
PLATFORMS = [
    {'name': 'Twitter', 'url_template': 'https://twitter.com/{}', 'check_method': 'http'},
    {'name': 'GitHub', 'url_template': 'https://github.com/{}', 'check_method': 'http'},
    {'name': 'Instagram', 'url_template': 'https://instagram.com/{}', 'check_method': 'http'},
    {'name': 'Reddit', 'url_template': 'https://reddit.com/user/{}', 'check_method': 'http'},
]

# Proxy list (add real proxies or use a service)
PROXIES = [
    {'http': 'http://proxy1.example:8080', 'https': 'http://proxy1.example:8080'},
    {'http': 'http://proxy2.example:8080', 'https': 'http://proxy2.example:8080'},
]

def generate_variations(username: str) -> List[str]:
    """Generate intelligent username variations."""
    variations = {username.lower()}  # Normalize and dedupe
    # Numbers
    for i in range(1, 5):
        variations.add(username + str(i))
        variations.add(str(i) + username)
    # Common swaps
    swaps = {'o': '0', 'l': '1', 'e': '3', 's': '5', 'a': '4'}
    for orig, new in swaps.items():
        if orig in username:
            variations.add(username.replace(orig, new))
    # Separators and suffixes
    for sep in ['_', '-', '.', 'x']:
        variations.add(username + sep)
        variations.add(sep + username)
    # Regex tweaks (e.g., double letters)
    if re.search(r'(.)\1', username):
        variations.add(re.sub(r'(.)\1', r'\1', username))  # Remove doubles
    return list(variations)

def check_username(platform: Dict[str, str], username: str, use_proxy: bool = False) -> Tuple[str, bool, Dict]:
    """Check a username on a platform with stealth and enrichment."""
    url = platform['url_template'].format(quote(username))
    headers = {
        'User-Agent': random.choice([
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
        ])
    }
    proxies = random.choice(PROXIES) if use_proxy and PROXIES else None
    try:
        response = requests.get(url, headers=headers, proxies=proxies, timeout=5)
        if response.status_code == 200:
            # Basic enrichment (expand with APIs later)
            details = {'url': url, 'status': 'active'}
            if 'twitter.com' in url:  # Example enrichment
                details['bio'] = response.text.split('<meta name="description" content="')[1].split('"')[0] if '<meta name="description" content="' in response.text else 'N/A'
            return platform['name'], True, details
        return platform['name'], False, {'url': url, 'status': 'inactive'}
    except requests.RequestException as e:
        return platform['name'], False, {'url': url, 'error': str(e)}

def scan_platforms(username: str, platforms: List[Dict], stealth: bool = False, verbose: bool = False) -> Dict:
    """Scan platforms asynchronously with variations."""
    variations = generate_variations(username)
    results = {var: {'hits': [], 'misses': [], 'errors': []} for var in variations}
    
    print(f"\n[Goku Voice] Powering up! Scanning {len(variations)} variations across {len(platforms)} platforms...")
    time.sleep(1)  # Dramatic effect
    
    for var in variations:
        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
            future_to_check = {executor.submit(check_username, p, var, stealth): p for p in platforms}
            for future in concurrent.futures.as_completed(future_to_check):
                name, found, details = future.result()
                if found:
                    results[var]['hits'].append({name: details})
                elif 'error' in details:
                    results[var]['errors'].append({name: details})
                else:
                    results[var]['misses'].append(name)
    
    # CLI output
    for var, data in results.items():
        if data['hits']:
            print(f"\nVariation: {var}")
            for hit in data['hits']:
                for platform, info in hit.items():
                    print(f"  [+] {platform}: {info['url']} (Status: {info.get('status', 'N/A')})")
                    if 'bio' in info:
                        print(f"      Bio: {info['bio']}")
        if verbose and data['misses']:
            print(f"  [-] Not found: {', '.join(data['misses'])}")
        if data['errors']:
            print(f"  [!] Errors: {', '.join([list(e.keys())[0] + ': ' + list(e.values())[0]['error'] for e in data['errors']])}")
    
    return results

def save_results(results: Dict, format: str = 'json'):
    """Export results to a file."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    if format == 'json':
        with open(f"omnitrace_results_{timestamp}.json", 'w') as f:
            json.dump(results, f, indent=4)
    elif format == 'csv':
        with open(f"omnitrace_results_{timestamp}.csv", 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Variation', 'Platform', 'URL', 'Status', 'Bio'])
            for var, data in results.items():
                for hit in data['hits']:
                    for platform, info in hit.items():
                        writer.writerow([var, platform, info['url'], info.get('status', 'N/A'), info.get('bio', 'N/A')])

def cli_main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="OmniTrace: The ultimate username tracker.")
    parser.add_argument('username', help="Target username")
    parser.add_argument('-s', '--stealth', action='store_true', help="Use proxies for stealth")
    parser.add_argument('-v', '--verbose', action='store_true', help="Show all results")
    parser.add_argument('-o', '--output', choices=['json', 'csv'], default='json', help="Output format")
    args = parser.parse_args()

    print(GOKU_ASCII)
    print(f"Target locked: {args.username}")
    results = scan_platforms(args.username, PLATFORMS, args.stealth, args.verbose)
    save_results(results, args.output)
    print(f"\n[Goku Voice] Mission complete! Results saved to omnitrace_results_*.{args.output}")

# GUI with Goku flair
class OmniTraceGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("OmniTrace - Goku Edition")
        self.root.geometry("800x600")
        self.root.configure(bg='#ff6200')  # Orange Goku vibe

        # Goku label
        self.goku_label = ttk.Label(root, text="Goku says: Enter your target!", font=("Arial", 16, "bold"), background='#ff6200', foreground='white')
        self.goku_label.pack(pady=10)

        # Entry
        self.entry = ttk.Entry(root, width=30)
        self.entry.pack(pady=10)

        # Options
        self.stealth_var = tk.BooleanVar()
        self.verbose_var = tk.BooleanVar()
        ttk.Checkbutton(root, text="Stealth Mode", variable=self.stealth_var).pack()
        ttk.Checkbutton(root, text="Verbose Output", variable=self.verbose_var).pack()

        # Scan button
        self.scan_btn = ttk.Button(root, text="Power Up!", command=self.scan)
        self.scan_btn.pack(pady=10)

        # Progress (Kamehameha bar)
        self.progress = ttk.Progressbar(root, length=300, mode='determinate')
        self.progress.pack(pady=10)

        # Results
        self.results_text = tk.Text(root, height=15, width=80, bg='white', fg='black')
        self.results_text.pack(pady=10)

    def scan(self):
        username = self.entry.get()
        if not username:
            messagebox.showwarning("Input Error", "Goku needs a target, bro!")
            return

        self.goku_label.config(text="Goku says: Ka-me-ha-me-ha!")
        self.scan_btn.config(state='disabled')
        self.progress['value'] = 0
        self.results_text.delete(1.0, tk.END)

        # Simulate progress
        for i in range(0, 101, 10):
            self.progress['value'] = i
            self.root.update()
            time.sleep(0.1)

        # Run scan
        results = scan_platforms(username, PLATFORMS, self.stealth_var.get(), self.verbose_var.get())
        save_results(results, 'json')

        # Show results in GUI
        for var, data in results.items():
            if data['hits']:
                self.results_text.insert(tk.END, f"\nVariation: {var}\n")
                for hit in data['hits']:
                    for platform, info in hit.items():
                        self.results_text.insert(tk.END, f"  [+] {platform}: {info['url']} (Status: {info.get('status')})\n")
                        if 'bio' in info:
                            self.results_text.insert(tk.END, f"      Bio: {info['bio']}\n")
        
        self.goku_label.config(text="Goku says: Target acquired!")
        self.scan_btn.config(state='normal')

def gui_main():
    root = tk.Tk()
    app = OmniTraceGUI(root)
    root.mainloop()

if __name__ == "__main__":
    # Default to CLI, use --gui for GUI mode
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--gui', action='store_true')
    args, unknown = parser.parse_known_args()
    if args.gui:
        gui_main()
    else:
        cli_main()
