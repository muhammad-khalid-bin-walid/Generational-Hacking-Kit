import asyncio
import socket
import time

async def scan_port(ip, port, open_ports):
    conn = asyncio.open_connection(ip, port)
    try:
        # Attempt to connect with a very short timeout
        reader, writer = await asyncio.wait_for(conn, timeout=0.1)
        open_ports.append(port)
        writer.close()
        await writer.wait_closed()
    except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
        pass  # Port closed or unreachable

async def scan_range(ip, start_port, end_port):
    open_ports = []
    tasks = []
    
    # Create tasks for all ports in range
    for port in range(start_port, end_port + 1):
        task = scan_port(ip, port, open_ports)
        tasks.append(task)
    
    # Run all tasks concurrently
    await asyncio.gather(*tasks)
    
    return sorted(open_ports)

async def main():
    target = input("Enter IP address to scan (e.g., 127.0.0.1): ").strip()
    start = int(input("Enter starting port (e.g., 1): "))
    end = int(input("Enter ending port (e.g., 1000): "))
    
    if not target or start < 1 or end < start:
        print("Invalid input. Please provide a valid IP and port range.")
        return
    
    print(f"Scanning {target} from port {start} to {end}...")
    start_time = time.time()
    
    open_ports = await scan_range(target, start, end)
    
    end_time = time.time()
    elapsed = end_time - start_time
    
    if open_ports:
        print(f"Open ports: {open_ports}")
    else:
        print("No open ports found.")
    print(f"Scan completed in {elapsed:.2f} seconds.")

if __name__ == "__main__":
    asyncio.run(main())
