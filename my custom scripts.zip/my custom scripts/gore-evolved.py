import requests

# Replace 'YOUR_API_KEY' with your actual Numverify API key
API_KEY = 'c058390d1e4a144774b5b328881208b2'

# The number to query
number = '+8801863-535958'

# URL for the Numverify API
url = f'http://apilayer.net/api/validate?access_key={API_KEY}&number={number}'

# Make the API request
response = requests.get(url)

# Check if the request was successful
if response.status_code == 200:
    # Parse the JSON response
    data = response.json()
    
    # Extract the required details
    country_code = data.get('country_code')
    country_name = data.get('country_name')
    location = data.get('location')
    carrier = data.get('carrier')
    line_type = data.get('line_type')
    
    # Print the details
    print(f'Country Code: {country_code}')
    print(f'Country Name: {country_name}')
    print(f'Location: {location}')
    print(f'Carrier: {carrier}')
    print(f'Line Type: {line_type}')
else:
    print('Failed to retrieve details.')
