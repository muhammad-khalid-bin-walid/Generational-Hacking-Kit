import paramiko

def exploit_ssh():
    # Prompt the user for input
    target = input("Enter the target IP address: ")
    username = input("Enter the username: ")
    password = input("Enter the password: ")

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(target, username=username, password=password)

        # Interact with the SSH session
        stdin, stdout, stderr = client.exec_command('ls')
        print(stdout.read().decode())

        client.close()
    except paramiko.AuthenticationException:
        print("Authentication failed.")
    except paramiko.SSHException as e:
        print(f"SSH error: {str(e)}")

# Run the exploit function directly
exploit_ssh()
