import bcrypt

password = b"hey john"  # Convert password to bytes
salt = bcrypt.gensalt()  # Generate a salt
hashed_password = bcrypt.hashpw(password, salt)  # Create the hash

print(hashed_password)  # Display the hashed password
