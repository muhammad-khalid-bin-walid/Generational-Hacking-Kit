import asyncio
import socket
import re
import time

# Basic vulnerability database (example versions known to be weak)
VULN_DB = {
    21: {"service": "FTP", "weak_versions": ["vsftpd 2.3.4"]},  # Backdoor in vsftpd 2.3.4
    22: {"service": "SSH", "weak_versions": ["OpenSSH_7.2p1", "OpenSSH_4.3"]},  # Old/vuln versions
    80: {"service": "HTTP", "weak_versions": ["Apache/2.2.3", "nginx/0.7.65"]}  # Outdated/vuln
}

async def check_vulnerability(ip, port):
    conn = asyncio.open_connection(ip, port)
    try:
        reader, writer = await asyncio.wait_for(conn, timeout=0.2)
        
        # Send a basic request based on port
        if port == 80:  # HTTP
            writer.write(b"GET / HTTP/1.1\r\nHost: test\r\n\r\n")
        elif port == 21:  # FTP
            pass  # Banner usually sent automatically
        elif port == 22:  # SSH
            pass  # Banner sent on connect
        
        await writer.drain()
        banner = await asyncio.wait_for(reader.read(1024), timeout=0.5)
        banner_str = banner.decode(errors="ignore").strip()
        
        writer.close()
        await writer.wait_closed()
        
        # Check if banner matches known vulnerable versions
        if port in VULN_DB:
            service_info = VULN_DB[port]
            for weak_version in service_info["weak_versions"]:
                if re.search(weak_version, banner_str, re.IGNORECASE):
                    return f"{service_info['service']} - Potentially vulnerable version: {weak_version} (Banner: {banner_str})"
            return f"{service_info['service']} - No known vulnerabilities detected (Banner: {banner_str})"
        return "Service detected, no vulnerability check available"
    
    except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
        return None  # Port closed or no response

async def scan_port(ip, port, results):
    conn = asyncio.open_connection(ip, port)
    try:
        await asyncio.wait_for(conn, timeout=0.1)
        vuln_result = await check_vulnerability(ip, port)
        if vuln_result:
            results.append((port, vuln_result))
    except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
        pass  # Port closed

async def scan_range(ip, start_port, end_port):
    results = []
    tasks = []
    
    for port in range(start_port, end_port + 1):
        task = scan_port(ip, port, results)
        tasks.append(task)
    
    await asyncio.gather(*tasks)
    return sorted(results, key=lambda x: x[0])

async def main():
    target = input("Enter IP address to scan (e.g., 127.0.0.1): ").strip()
    start = int(input("Enter starting port (e.g., 1): "))
    end = int(input("Enter ending port (e.g., 1000): "))
    
    if not target or start < 1 or end < start:
        print("Invalid input. Please provide a valid IP and port range.")
        return
    
    print(f"Scanning {target} from port {start} to {end} with vulnerability checks...")
    start_time = time.time()
    
    results = await scan_range(target, start, end)
    
    end_time = time.time()
    elapsed = end_time - start_time
    
    if results:
        print("\nResults:")
        for port, vuln_info in results:
            print(f"Port {port}: {vuln_info}")
    else:
        print("No open ports or vulnerabilities found.")
    print(f"Scan completed in {elapsed:.2f} seconds.")

if __name__ == "__main__":
    asyncio.run(main())
