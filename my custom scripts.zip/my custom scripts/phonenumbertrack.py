import phonenumbers
from phonenumbers import geocoder

def get_phone_location(phone_number):
    try:
        # Parse the phone number
        parsed_number = phonenumbers.parse(phone_number)

        # Get the location information
        location = geocoder.description_for_number(parsed_number, "en")

        return location
    except phonenumbers.phonenumberutil.NumberParseException as e:
        return f"Error parsing phone number: {e}"

if __name__ == "__main__":
    phone_number = input("Enter the phone number to track (include country code): ")
    location = get_phone_location(phone_number)
    print(f"The phone number {phone_number} is located in: {location}")
