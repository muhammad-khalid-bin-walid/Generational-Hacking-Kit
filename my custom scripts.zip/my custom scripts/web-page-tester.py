import argparse
import json
import os
import time
import requests
from urllib.parse import urlparse
from datetime import datetime
import ssl
import socket

# Set up PageSpeed Insights API key
API_KEY = os.getenv("PAGESPEED_API_KEY")
if not API_KEY:
    API_KEY = input("Enter your PageSpeed Insights API key: ")

# Test website availability
def test_availability(url):
    try:
        start = time.time()
        response = requests.get(url, timeout=10)
        end = time.time()
        return {
            "status": response.status_code,
            "response_time": round(end - start, 2)
        }
    except Exception as e:
        return {"error": str(e)}

# Test web performance using PageSpeed Insights
def test_performance(url):
    api_url = f"https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url={url}&key={API_KEY}"
    try:
        response = requests.get(api_url)
        data = response.json()
        lighthouse = data.get('lighthouseResult', {})
        categories = lighthouse.get('categories', {})
        performance_score = categories.get('performance', {}).get('score', 'N/A')
        return {"performance_score": performance_score}
    except Exception as e:
        return {"error": str(e)}

# Test SSL/TLS configuration
def test_ssl(url):
    try:
        parsed_url = urlparse(url)
        if parsed_url.scheme != 'https':
            return {"error": "Not using HTTPS"}
        hostname = parsed_url.hostname
        port = 443
        context = ssl.create_default_context()
        with socket.create_connection((hostname, port)) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                expiry_date = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                is_valid = expiry_date > datetime.now()
                return {
                    "valid": is_valid,
                    "expiry_date": expiry_date.strftime('%Y-%m-%d'),
                    "protocol": ssock.version()
                }
    except Exception as e:
        return {"error": str(e)}

# Test security headers
def test_headers(url):
    try:
        response = requests.get(url, timeout=10)
        headers = response.headers
        security_headers = {
            "Content-Security-Policy": headers.get("Content-Security-Policy", "Missing"),
            "X-Frame-Options": headers.get("X-Frame-Options", "Missing"),
            "X-Content-Type-Options": headers.get("X-Content-Type-Options", "Missing"),
            "Strict-Transport-Security": headers.get("Strict-Transport-Security", "Missing")
        }
        return security_headers
    except Exception as e:
        return {"error": str(e)}

# Test HTTP methods support
def test_http_methods(url):
    methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD', 'CONNECT', 'TRACE']
    results = {}
    try:
        # Send OPTIONS request to get allowed methods
        options_response = requests.options(url, timeout=5)
        if 'Allow' in options_response.headers:
            allow = options_response.headers['Allow']
            allowed_methods = [m.strip().upper() for m in allow.split(',')]
            results['allowed_methods'] = allowed_methods
        else:
            results['allowed_methods'] = 'Not provided'
    except requests.RequestException as e:
        results['allowed_methods'] = f'Error: {str(e)}'
    
    # Send individual requests for each method
    for method in methods:
        try:
            response = requests.request(method, url, timeout=5)
            results[method] = response.status_code
        except requests.RequestException as e:
            results[method] = str(e)
    return results

# Run selected tests on a URL
def run_tests(url, selected_tests):
    results = {}
    if "availability" in selected_tests:
        results["availability"] = test_availability(url)
    if "performance" in selected_tests:
        results["performance"] = test_performance(url)
    if "ssl" in selected_tests:
        results["ssl"] = test_ssl(url)
    if "headers" in selected_tests:
        results["headers"] = test_headers(url)
    if "http_methods" in selected_tests:
        results["http_methods"] = test_http_methods(url)
    return results

# Parse command-line arguments
parser = argparse.ArgumentParser(description="OmniSiteTester: Comprehensive Website Testing Tool")
parser.add_argument("--urls", required=True, help="Comma-separated URLs or file with URLs (one per line)")
parser.add_argument("--tests", default="all", help="Tests to run: all, or comma-separated list (availability, performance, ssl, headers, http_methods)")
parser.add_argument("--output", default="report.json", help="Output file for results")
args = parser.parse_args()

# Read URLs from input
if args.urls.endswith(".txt"):
    with open(args.urls, "r") as f:
        urls = [line.strip() for line in f if line.strip()]
else:
    urls = args.urls.split(",")

# Determine which tests to run
all_tests = ["availability", "performance", "ssl", "headers", "http_methods"]
if args.tests == "all":
    selected_tests = all_tests
else:
    selected_tests = args.tests.split(",")
    for test in selected_tests:
        if test not in all_tests:
            print(f"Invalid test: {test}")
            exit(1)

# Execute tests and collect results
results = {}
for url in urls:
    results[url] = run_tests(url, selected_tests)

# Save results to file
with open(args.output, "w") as f:
    json.dump(results, f, indent=4)

print(f"Testing complete. Results saved to {args.output}")
