import asyncio
import socket
import re
import time
import whois
import aiohttp
from scapy.all import sniff, IP, TCP
import ssl
import OpenSSL
from bs4 import BeautifulSoup
import shodan  # pip install shodan
import getpass

# Vulnerability database
VULN_DB = {
    21: {"service": "FTP", "weak_versions": ["vsftpd 2.3.4"]},
    22: {"service": "SSH", "weak_versions": ["OpenSSH_7.2p1", "OpenSSH_4.3"]},
    80: {"service": "HTTP", "weak_versions": ["Apache/2.2.3", "nginx/0.7.65"]},
    443: {"service": "HTTPS", "weak_versions": ["Apache/2.2.3", "nginx/0.7.65"]}
}

SUBDOMAINS = ["www", "mail", "ftp", "test", "dev"]

async def check_vulnerability(ip, port, session):
    conn = asyncio.open_connection(ip, port)
    try:
        reader, writer = await asyncio.wait_for(conn, timeout=0.2)
        banner = ""
        if port in (80, 443):
            writer.write(b"GET / HTTP/1.1\r\nHost: test\r\n\r\n")
            await writer.drain()
            banner = (await asyncio.wait_for(reader.read(1024), timeout=0.5)).decode(errors="ignore")
        else:
            banner = (await asyncio.wait_for(reader.read(1024), timeout=0.5)).decode(errors="ignore")
        writer.close()
        await writer.wait_closed()
        
        if port in VULN_DB:
            for weak_version in VULN_DB[port]["weak_versions"]:
                if re.search(weak_version, banner, re.IGNORECASE):
                    return f"{VULN_DB[port]['service']} - Vulnerable: {weak_version} (Banner: {banner.strip()})"
            return f"{VULN_DB[port]['service']} - No known vulns (Banner: {banner.strip()})"
        return "Service detected, no vuln check"
    except:
        return None

async def get_http_headers(ip, port, session):
    url = f"http://{ip}" if port == 80 else f"https://{ip}"
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=2)) as response:
            headers = dict(response.headers)
            server = headers.get("Server", "Unknown")
            if any(v in server for v in ["Apache/2.2", "nginx/0.7"]):
                return f"Headers reveal potential vuln: {server}"
            return f"Headers: Server={server}"
    except:
        return "No headers retrieved"

async def ssl_check(ip, port):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((ip, port)) as sock:
            with context.wrap_socket(sock, server_hostname=ip) as ssock:
                cert = ssock.getpeercert(True)
                x509 = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_ASN1, cert)
                expiry = x509.get_notAfter().decode()
                if time.strptime(expiry, "%Y%m%d%H%M%SZ") < time.gmtime():
                    return "SSL - Expired certificate"
                return "SSL - Valid certificate"
    except:
        return "SSL check failed"

async def harvest_emails(domain, session):
    url = f"http://{domain}"
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as response:
            text = await response.text()
            soup = BeautifulSoup(text, "html.parser")
            emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", soup.get_text())
            return list(set(emails))  # Unique emails
    except:
        return []

async def exploitdb_search(banner, session):
    query = f"site:exploit-db.com {banner}"
    url = f"https://www.google.com/search?q={query}"
    try:
        async with session.get(url, headers={"User-Agent": "Mozilla/5.0"}) as response:
            text = await response.text()
            if "exploit-db.com/exploits" in text:
                return "Possible exploits found on Exploit-DB"
            return "No Exploit-DB matches"
    except:
        return "Exploit-DB search failed"

def shodan_lookup(ip, api_key):
    try:
        api = shodan.Shodan(api_key)
        result = api.host(ip)
        return f"Shodan: OS={result.get('os', 'Unknown')}, Ports={result.get('ports', [])}"
    except:
        return "Shodan lookup failed or API key invalid"

async def scan_port(ip, port, results, session):
    conn = asyncio.open_connection(ip, port)
    try:
        await asyncio.wait_for(conn, timeout=0.1)
        vuln_result = await check_vulnerability(ip, port, session)
        if vuln_result:
            extra = ""
            if port in (80, 443):
                extra += await get_http_headers(ip, port, session)
                if port == 443:
                    extra += " | " + await ssl_check(ip, port)
                extra += " | " + await exploitdb_search(vuln_result.split("Banner:")[0], session)
            results.append((port, f"{vuln_result} | {extra}"))
    except:
        pass

async def scan_range(ip, start_port, end_port, session):
    results = []
    tasks = [scan_port(ip, port, results, session) for port in range(start_port, end_port + 1)]
    await asyncio.gather(*tasks)
    return sorted(results, key=lambda x: x[0])

def whois_lookup(target):
    try:
        w = whois.whois(target)
        return f"WHOIS: Domain={w.domain_name}, Registrar={w.registrar}, Updated={w.updated_date}"
    except:
        return "WHOIS lookup failed"

async def dns_enum(domain):
    results = []
    async with aiohttp.ClientSession() as session:
        for sub in SUBDOMAINS:
            try:
                ip = await asyncio.get_event_loop().getaddrinfo(f"{sub}.{domain}", None)
                results.append(f"{sub}.{domain} -> {ip[0][4][0]}")
            except:
                pass
    return results

def packet_sniffer(count=10):
    print(f"Sniffing {count} packets (requires root/admin)...")
    try:
        packets = sniff(count=count, filter="tcp", timeout=10)
        for pkt in packets:
            if IP in pkt and TCP in pkt:
                print(f"{pkt[IP].src}:{pkt[TCP].sport} -> {pkt[IP].dst}:{pkt[TCP].dport}")
    except PermissionError:
        print("Permission denied - run as root/admin.")
    except:
        print("Sniffing failed.")

async def main():
    target = input("Enter IP or domain (e.g., 127.0.0.1 or example.com): ").strip()
    start = int(input("Enter starting port (e.g., 1): "))
    end = int(input("Enter ending port (e.g., 1000): "))
    shodan_key = input("Enter Shodan API key (optional, press Enter to skip): ").strip()
    
    if not target or start < 1 or end < start:
        print("Invalid input.")
        return
    
    start_time = time.time()
    
    # WHOIS
    print("\n[WHOIS Lookup]")
    print(whois_lookup(target))
    
    # DNS Enum (if domain)
    if not re.match(r"^\d+\.\d+\.\d+\.\d+$", target):
        print("\n[DNS Enumeration]")
        dns_results = await dns_enum(target)
        for res in dns_results:
            print(res)
        # Email Harvesting
        print("\n[Email Harvesting]")
        async with aiohttp.ClientSession() as session:
            emails = await harvest_emails(target, session)
            if emails:
                for email in emails:
                    print(email)
            else:
                print("No emails found.")
    
    # Shodan (if API key provided)
    if shodan_key:
        print("\n[Shodan Lookup]")
        print(shodan_lookup(target, shodan_key))
    
    # Port Scan + Tools
    print(f"\n[Scanning {target} from port {start} to {end}]")
    async with aiohttp.ClientSession() as session:
        results = await scan_range(target, start, end, session)
        if results:
            for port, info in results:
                print(f"Port {port}: {info}")
        else:
            print("No open ports or vulnerabilities found.")
    
    # Packet Sniffer
    sniff_choice = input("\nRun packet sniffer for 10 packets? (y/n): ").lower()
    if sniff_choice == "y":
        packet_sniffer()
    
    end_time = time.time()
    print(f"\nCompleted in {end_time - start_time:.2f} seconds.")

if __name__ == "__main__":
    asyncio.run(main())
