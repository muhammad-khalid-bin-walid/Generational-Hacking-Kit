import dns.resolver
import requests
import argparse
import concurrent.futures
from urllib.parse import urlparse
from typing import List, Dict
import json

# Known vulnerable services and their fingerprints (simplified for demonstration)
VULNERABLE_SERVICES = {
    "github.io": {
        "fingerprint": "There isn't a GitHub Pages site here",
        "message": "Vulnerable to GitHub Pages takeover"
    },
    "herokuapp.com": {
        "fingerprint": "No such app",
        "message": "Vulnerable to Heroku takeover"
    },
    "s3.amazonaws.com": {
        "fingerprint": "NoSuchBucket",
        "message": "Vulnerable to AWS S3 takeover"
    },
    "azurewebsites.net": {
        "fingerprint": "404 Web Site not found",
        "message": "Vulnerable to Azure takeover"
    }
}

class SubdomainTakeoverTester:
    def __init__(self, domain: str, subdomains_file: str = None, threads: int = 10):
        self.domain = domain
        self.subdomains = self._load_subdomains(subdomains_file) if subdomains_file else [domain]
        self.threads = threads
        self.results = []

    def _load_subdomains(self, file_path: str) -> List[str]:
        """Load subdomains from a file or generate basic ones."""
        try:
            with open(file_path, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"Subdomains file {file_path} not found. Using base domain only.")
            return [self.domain]

    def _resolve_cname(self, subdomain: str) -> str:
        """Resolve CNAME record for a subdomain."""
        try:
            answers = dns.resolver.resolve(subdomain, 'CNAME')
            for rdata in answers:
                return str(rdata.target).rstrip('.')
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            return None
        except Exception as e:
            print(f"Error resolving CNAME for {subdomain}: {e}")
            return None

    def _check_service(self, subdomain: str, cname: str) -> Dict:
        """Check if the CNAME points to a vulnerable service."""
        for service, details in VULNERABLE_SERVICES.items():
            if service in cname:
                try:
                    # Attempt HTTP request to check fingerprint
                    response = requests.get(f"http://{subdomain}", timeout=5)
                    if details["fingerprint"] in response.text:
                        return {
                            "subdomain": subdomain,
                            "cname": cname,
                            "status": "VULNERABLE",
                            "message": details["message"]
                        }
                except requests.RequestException:
                    # If HTTP fails, try HTTPS
                    try:
                        response = requests.get(f"https://{subdomain}", timeout=5)
                        if details["fingerprint"] in response.text:
                            return {
                                "subdomain": subdomain,
                                "cname": cname,
                                "status": "VULNERABLE",
                                "message": details["message"]
                            }
                    except requests.RequestException:
                        pass
                return {
                    "subdomain": subdomain,
                    "cname": cname,
                    "status": "UNKNOWN",
                    "message": f"Could not confirm {service} takeover vulnerability"
                }
        return {
            "subdomain": subdomain,
            "cname": cname,
            "status": "NOT_VULNERABLE",
            "message": "No known vulnerable service detected"
        }

    def test_subdomain(self, subdomain: str) -> None:
        """Test a single subdomain for takeover vulnerability."""
        cname = self._resolve_cname(subdomain)
        if cname:
            result = self._check_service(subdomain, cname)
            self.results.append(result)
        else:
            self.results.append({
                "subdomain": subdomain,
                "cname": None,
                "status": "NO_CNAME",
                "message": "No CNAME record found"
            })

    def run(self) -> List[Dict]:
        """Run the takeover test across all subdomains using threading."""
        print(f"Testing {len(self.subdomains)} subdomains for takeover vulnerabilities...")
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.threads) as executor:
            executor.map(self.test_subdomain, self.subdomains)
        return self.results

def main():
    parser = argparse.ArgumentParser(description="Subdomain Takeover Vulnerability Tester")
    parser.add_argument("-d", "--domain", required=True, help="Target domain (e.g., example.com)")
    parser.add_argument("-f", "--file", help="File containing subdomains (one per line)")
    parser.add_argument("-t", "--threads", type=int, default=10, help="Number of threads (default: 10)")
    parser.add_argument("-o", "--output", help="Output JSON file for results")
    args = parser.parse_args()

    tester = SubdomainTakeoverTester(args.domain, args.file, args.threads)
    results = tester.run()

    # Print results
    for result in results:
        print(f"Subdomain: {result['subdomain']}")
        print(f"CNAME: {result['cname']}")
        print(f"Status: {result['status']}")
        print(f"Message: {result['message']}\n")

    # Save to file if specified
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to {args.output}")

if __name__ == "__main__":
    main()
