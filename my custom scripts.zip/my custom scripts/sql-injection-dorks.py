import requests
from bs4 import BeautifulSoup

def search_sql_injection_vulnerabilities(query):
    url = f"https://www.google.com/search?q={query}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    }

    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")

    results = []
    for link in soup.find_all("a"):
        url = link.get("href")
        if url and "http" in url:
            results.append(url)
    
    return results

# Example usage
query = "site:*.com inurl:index.php?id= intitle:SQL injection OR inurl:gallery.php?id= intitle:SQL injection OR inurl:article.php?id= intitle:SQL injection OR inurl:page.php?id= intitle:SQL injection OR inurl:product.php?id= intitle:SQL injection OR inurl:news.php?id= intitle:SQL injection OR inurl:shop.php?id= intitle:SQL injection OR inurl:category.php?id= intitle:SQL injection OR inurl:store.php?id= intitle:SQL injection OR inurl:detail.php?id= intitle:SQL injection"
vulnerable_websites = search_sql_injection_vulnerabilities(query)
print("Vulnerable websites:")
for website in vulnerable_websites:
    print(website)
