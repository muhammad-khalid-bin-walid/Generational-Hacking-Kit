import asyncio
import socket
import re
import time
import whois
import aiohttp
import ssl
import OpenSSL
import shodan
from concurrent.futures import ThreadPoolExecutor

# Optimized defaults
DEFAULT_PORTS = [21, 22, 80, 443]
VULN_DB = {
    21: {"service": "FTP", "weak_versions": ["vsftpd 2.3.4"]},
    22: {"service": "SSH", "weak_versions": ["OpenSSH_7.2p1"]},
    80: {"service": "HTTP", "weak_versions": ["Apache/2.2.3"]},
    443: {"service": "HTTPS", "weak_versions": ["Apache/2.2.3"]}
}
SUBDOMAINS = ["www", "mail", "ftp"]

async def scan_port(ip, port, session):
    conn = asyncio.open_connection(ip, port)
    try:
        reader, writer = await asyncio.wait_for(conn, timeout=0.05)
        banner = (await asyncio.wait_for(reader.read(1024), timeout=0.1)).decode(errors="ignore").strip()
        writer.close()
        await writer.wait_closed()
        
        result = f"Port {port}: Open"
        if port in VULN_DB:
            for weak in VULN_DB[port]["weak_versions"]:
                if weak in banner:
                    result += f" - Vulnerable: {weak}"
                    break
                else:
                    result += f" - {VULN_DB[port]['service']} (Banner: {banner})"
        if port in (80, 443):
            headers = await get_http_headers(ip, port, session)
            result += f" | {headers}"
            if port == 443:
                ssl_info = await ssl_check(ip, port)
                result += f" | {ssl_info}"
        return result
    except:
        return None

async def get_http_headers(ip, port, session):
    url = f"http://{ip}" if port == 80 else f"https://{ip}"
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=1)) as response:
            server = response.headers.get("Server", "Unknown")
            return f"Headers: Server={server}"
    except:
        return "Headers: N/A"

async def ssl_check(ip, port):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((ip, port), timeout=1) as sock:
            with context.wrap_socket(sock, server_hostname=ip) as ssock:
                cert = ssock.getpeercert(True)
                x509 = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_ASN1, cert)
                expiry = x509.get_notAfter().decode()
                if time.strptime(expiry, "%Y%m%d%H%M%SZ") < time.gmtime():
                    return "SSL: Expired"
                return "SSL: Valid"
    except:
        return "SSL: N/A"

def whois_lookup(target):
    try:
        w = whois.whois(target)
        return f"WHOIS: Domain={w.domain_name}, Registrar={w.registrar}"
    except:
        return "WHOIS: Failed"

async def dns_enum(domain, session):
    results = []
    for sub in SUBDOMAINS:
        try:
            ip = await asyncio.get_event_loop().getaddrinfo(f"{sub}.{domain}", None, timeout=0.1)
            results.append(f"{sub}.{domain} -> {ip[0][4][0]}")
        except:
            pass
    return results

async def harvest_emails(domain, session):
    url = f"http://{domain}"
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=2)) as response:
            text = await response.text()
            emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
            return list(set(emails))
    except:
        return []

def shodan_lookup(ip, api_key):
    try:
        api = shodan.Shodan(api_key)
        result = api.host(ip)
        return f"Shodan: OS={result.get('os', 'Unknown')}, Ports={result.get('ports', [])}"
    except:
        return "Shodan: Failed or invalid key"

async def main():
    print("Ultra-Instinct Scanner")
    target = input("Enter target (IP/Domain): ").strip()
    ports_input = input("Enter ports (e.g., 1-1000, or blank for defaults): ").strip()
    shodan_key = input("Shodan API key (optional, blank to skip): ").strip()
    
    if not target:
        print("Error: No target specified.")
        return
    
    start_time = time.time()
    print(f"\nScanning {target}...")

    # Resolve IP
    try:
        ip = socket.gethostbyname(target)
        print(f"Resolved {target} to {ip}")
    except:
        print("Error: Could not resolve target.")
        return

    # Parse ports
    if ports_input:
        if "-" in ports_input:
            start, end = map(int, ports_input.split("-"))
            ports = range(start, end + 1)
        else:
            ports = [int(p) for p in ports_input.split(",")]
    else:
        ports = DEFAULT_PORTS
        print("Using default ports: 21, 22, 80, 443")

    # WHOIS
    print("\n[WHOIS]")
    print(whois_lookup(target))

    # Async tasks
    async with aiohttp.ClientSession() as session:
        if not re.match(r"^\d+\.\d+\.\d+\.\d+$", target):
            print("\n[DNS Enumeration]")
            dns_results = await dns_enum(target, session)
            for res in dns_results:
                print(res)
            
            print("\n[Email Harvesting]")
            emails = await harvest_emails(target, session)
            print("\n".join(emails) if emails else "No emails found.")

        if shodan_key:
            print("\n[Shodan]")
            print(shodan_lookup(ip, shodan_key))

        # Port Scan
        print(f"\n[Scanning {len(ports)} ports]")
        tasks = [scan_port(ip, port, session) for port in ports]
        results = await asyncio.gather(*tasks)
        for result in filter(None, results):
            print(result)

    end_time = time.time()
    print(f"\nCompleted in {end_time - start_time:.2f} seconds.")

if __name__ == "__main__":
    asyncio.run(main())
