import requests
from bs4 import BeautifulSoup
import time

# Function to perform a simple Google search
def google_search(query):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    url = f"https://www.google.com/search?q={query}"
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        results = soup.find_all("div", class_="tF2Cxc")  # Google result container
        
        for i, result in enumerate(results[:5], 1):  # Limit to top 5 results
            title = result.find("h3")
            link = result.find("a")["href"]
            if title and link:
                print(f"Result {i}:")
                print(f"Title: {title.text}")
                print(f"URL: {link}")
                print("-" * 50)
    else:
        print(f"Failed to retrieve results. Status code: {response.status_code}")

# Main execution
if __name__ == "__main__":
    print("Welcome to a Simple OSINT Search Tool!")
    keyword = input("Enter a keyword to search (e.g., name, company, topic): ").strip()
    if keyword:
        print(f"Searching for: {keyword}")
        print("Please wait a moment...")
        time.sleep(2)  # Small delay to mimic processing
        google_search(keyword)
    else:
        print("No keyword entered. Please try again.")
