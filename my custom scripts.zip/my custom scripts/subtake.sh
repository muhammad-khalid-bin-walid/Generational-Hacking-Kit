#!/bin/bash

url=$1

# Create main directory
mkdir -p "$url/recon"

# Create subdirectories
mkdir -p "$url/recon/scans"
mkdir -p "$url/recon/httprobe"
mkdir -p "$url/recon/potential_takeovers"
mkdir -p "$url/recon/wayback/params"
mkdir -p "$url/recon/wayback/extensions"
# Optional: Uncomment if needed in the future
# mkdir -p "$url/recon/eyewitness"

# Run httprobe
echo "[*] Running httprobe on $url"
cat $url | httprobe > $url/recon/httprobe/httprobe.txt

# Run nmap scan
echo "[*] Running nmap scan on $url"
nmap -A $url -oN $url/recon/scans/nmap.txt

# Run subjack for potential takeovers
echo "[*] Running subjack on $url"
subjack -w $url -t 100 -o $url/recon/potential_takeovers/takeovers.txt -ssl

# Run waybackurls
echo "[*] Running waybackurls on $url"
echo $url | waybackurls > $url/recon/wayback/waybackurls.txt

# Extract parameters and extensions from Wayback Machine
echo "[*] Extracting parameters and extensions from Wayback Machine data"
cat $url/recon/wayback/waybackurls.txt | grep '?*=' | sort -u > $url/recon/wayback/params/params.txt
cat $url/recon/wayback/waybackurls.txt | grep -oE '\.[a-z]+' | sort -u > $url/recon/wayback/extensions/extensions.txt

# Optional: Run Eyewitness
# echo "[*] Running Eyewitness on $url"
# eyewitness -f $url/recon/httprobe/httprobe.txt -d $url/recon/eyewitness --web

echo "[*] Reconnaissance completed for $url"
