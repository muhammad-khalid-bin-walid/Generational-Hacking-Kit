#!/bin/bash

# Define the new user details
new_user='{
    "_id": "667bf71d5bb193f20666a6a1",
    "serial": 4,
    "photo": "https://i.ibb.co/L1QVQ9L/Sadia-Akter.png",
    "name": "Sadia Akter",
    "email": "sadia.cse8th@gmail.com",
    "designation": "Software Engineer",
    "phone": "",
    "facebookLink": "",
    "twitterLink": "",
    "instagramLink": "",
    "linkedinLink": ""
}'

# Load the existing JSON data
data=$(cat teams.json)

# Append the new user to the existing data
data=$(echo "$data" | jq --argjson new_user "$new_user" '.data += [$new_user]')

# Update the count of teams
count=$(echo "$data" | jq '.data | length')
data=$(echo "$data" | jq --argjson count "$count" '.count = $count')

# Save the updated JSON data
echo "$data" > teams.json
