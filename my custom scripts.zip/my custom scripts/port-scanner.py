import socket
import threading
from queue import Queue

# Function to scan a single port
def scan_port(ip, port, open_ports):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)  # Quick timeout to speed up scanning
    result = sock.connect_ex((ip, port))
    if result == 0:  # 0 means the port is open
        open_ports.append(port)
    sock.close()

# Function to handle multi-threaded scanning
def scan_ports(ip, start_port, end_port):
    print(f"Scanning {ip} from port {start_port} to {end_port}...")
    open_ports = []
    thread_queue = Queue()
    
    # Create threads for each port
    def threader():
        while True:
            port = thread_queue.get()
            scan_port(ip, port, open_ports)
            thread_queue.task_done()

    # Start 100 threads
    for _ in range(100):
        t = threading.Thread(target=threader)
        t.daemon = True
        t.start()

    # Add ports to the queue
    for port in range(start_port, end_port + 1):
        thread_queue.put(port)

    # Wait for all threads to finish
    thread_queue.join()

    # Report results
    if open_ports:
        print(f"Open ports found: {sorted(open_ports)}")
    else:
        print("No open ports found.")

# Main execution
if __name__ == "__main__":
    target = input("Enter IP address to scan (e.g., 192.168.1.1): ").strip()
    start = int(input("Enter starting port (e.g., 1): "))
    end = int(input("Enter ending port (e.g., 1000): "))
    
    if target and start > 0 and end >= start:
        scan_ports(target, start, end)
    else:
        print("Invalid input. Please provide a valid IP and port range.")
