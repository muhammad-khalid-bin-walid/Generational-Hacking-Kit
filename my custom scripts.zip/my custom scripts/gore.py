import phonenumbers
from phonenumbers import geocoder, carrier
from geopy.geocoders import Nominatim
import requests

def get_phone_details(phone_number):
    try:
        # Parse the phone number
        parsed_number = phonenumbers.parse(phone_number)

        # Get the location information
        location = geocoder.description_for_number(parsed_number, "en")

        # Get the carrier information
        carrier_info = carrier.name_for_number(parsed_number, "en")

        return location, carrier_info
    except phonenumbers.phonenumberutil.NumberParseException as e:
        return f"Error parsing phone number: {e}", None

def get_geo_location(location):
    geolocator = Nominatim(user_agent="geoapiExercises")
    try:
        location = geolocator.geocode(location)
        if location:
            return location.latitude, location.longitude
        else:
            return None, None
    except Exception as e:
        return None, None

def get_ip_location(ip_address):
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}")
        if response.status_code == 200:
            data = response.json()
            if data["status"] == "success":
                return data["city"], data["lat"], data["lon"]
    except requests.RequestException as e:
        print(f"Error fetching IP location: {e}")
    return None, None, None

if __name__ == "__main__":
    phone_number = input("Enter the phone number to track (include country code): ")
    location, carrier_info = get_phone_details(phone_number)
    if carrier_info:
        print(f"The phone number {phone_number} is located in: {location}")
        print(f"The carrier for the phone number is: {carrier_info}")

        # Get geographic coordinates for the location
        lat, lon = get_geo_location(location)
        if lat and lon:
            print(f"Geographic coordinates: Latitude {lat}, Longitude {lon}")
        else:
            print("Could not retrieve geographic coordinates.")

        # Get IP location (for demonstration purposes, using a placeholder IP)
        ip_address = "8.8.8.8"  # Replace with the actual IP address if available
        city, ip_lat, ip_lon = get_ip_location(ip_address)
        if city:
            print(f"IP address {ip_address} is located in: {city}")
            print(f"IP geographic coordinates: Latitude {ip_lat}, Longitude {ip_lon}")
        else:
            print("Could not retrieve IP location.")
    else:
        print(location)
