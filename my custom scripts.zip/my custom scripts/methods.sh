#!/bin/bash

# Ask for the target URL
read -p "Enter target URL: " TARGET_URL

# Define methods to test
METHODS=("OPTIONS" "GET" "POST" "PUT" "DELETE" "PATCH" "HEAD")

echo "Testing HTTP methods for $TARGET_URL..."
echo "--------------------------------------"

# Loop through each HTTP method and test it
for METHOD in "${METHODS[@]}"; do
    echo "Testing $METHOD..."
    curl -X $METHOD -i "$TARGET_URL"
    echo "--------------------------------------"
done

echo "Testing completed!"
