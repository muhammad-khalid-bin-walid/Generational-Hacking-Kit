import socket
import requests
import argparse
import logging
import time
from datetime import datetime

# Ethical use disclaimer
DISCLAIMER = """
This tool is for ethical testing purposes only. 
Use it only on systems where you have explicit permission.
Unauthorized use is illegal and unethical.
"""

# Set up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter('%(message)s'))
logger.addHandler(console_handler)

# Vulnerability advice for common services
VULN_ADVICE = {
    "SSH": "Ensure SSH is updated and configured securely (e.g., key-based auth, no root login).",
    "FTP": "Check if anonymous FTP is enabled; disable if not needed.",
    "Apache": "Ensure Apache is updated to avoid known exploits.",
    "nginx": "Check nginx configuration for security best practices.",
    "MySQL": "Ensure MySQL is not exposed publicly; use strong passwords.",
}

def port_scan(target, ports, delay=0.1):
    """Scan the target system for open ports with a delay between attempts."""
    open_ports = []
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((target, port))
        if result == 0:
            open_ports.append(port)
        sock.close()
        time.sleep(delay)  # Rate limiting
    return open_ports

def service_enumeration(target, port, user_agent=None):
    """Gather basic info about services on open ports."""
    try:
        if port in [80, 443]:
            # Handle web ports with HTTP/HTTPS requests
            protocol = "https" if port == 443 else "http"
            headers = {'User-Agent': user_agent} if user_agent else {}
            response = requests.get(f"{protocol}://{target}", headers=headers, timeout=5)
            server = response.headers.get("Server", "Unknown")
            return f"Service: {server}"
        else:
            # Banner grabbing for non-web ports
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((target, port))
            banner = sock.recv(1024).decode('utf-8', errors='ignore').strip()
            sock.close()
            return f"Service: {banner}"
    except Exception as e:
        return f"Service: Failed to enumerate ({e})"

def vulnerability_check(service):
    """Provide basic vulnerability feedback based on service."""
    for keyword, advice in VULN_ADVICE.items():
        if keyword.lower() in service.lower():
            return advice
    return "No specific vulnerabilities identified."

def main():
    # Display disclaimer
    logger.info(DISCLAIMER)

    # Set up command-line arguments
    parser = argparse.ArgumentParser(description="Ethical System Testing Tool")
    parser.add_argument("--target", required=True, help="Target IP or hostname (e.g., 192.168.1.1 or example.com)")
    parser.add_argument("--ports", default="22,80,443", help="Comma-separated list or range of ports (e.g., 22,80 or 1-100)")
    parser.add_argument("--delay", type=float, default=0.1, help="Delay between port scans in seconds")
    parser.add_argument("--user-agent", help="Custom User-Agent for HTTP requests")
    parser.add_argument("--log-file", help="File to log the output")
    args = parser.parse_args()

    # Add file handler for logging if specified
    if args.log_file:
        file_handler = logging.FileHandler(args.log_file)
        file_handler.setFormatter(logging.Formatter('%(message)s'))
        logger.addHandler(file_handler)

    # Parse ports (supporting ranges and lists)
    ports_str = args.ports
    try:
        if '-' in ports_str:
            start, end = map(int, ports_str.split('-'))
            if start > end or start < 1 or end > 65535:
                raise ValueError("Invalid port range")
            ports = list(range(start, end + 1))
        else:
            ports = [int(port) for port in ports_str.split(",")]
            if any(p < 1 or p > 65535 for p in ports):
                raise ValueError("Ports must be between 1 and 65535")
    except ValueError as e:
        logger.error(f"Invalid ports: {e}")
        return

    # Start the scan
    logger.info(f"Starting scan on {args.target} at {datetime.now()}")
    
    # Perform port scan
    open_ports = port_scan(args.target, ports, args.delay)
    if open_ports:
        logger.info(f"Open ports found: {open_ports}")
        for port in open_ports:
            service = service_enumeration(args.target, port, args.user_agent)
            logger.info(f"Port {port}: {service}")
            vuln = vulnerability_check(service)
            logger.info(f"  {vuln}")
    else:
        logger.info("No open ports found.")

    logger.info(f"Scan completed at {datetime.now()}")

if __name__ == "__main__":
    main()
