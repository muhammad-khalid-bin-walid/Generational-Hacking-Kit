import requests
import concurrent.futures
import argparse
import json
import csv
import re
import time
import random
from typing import List, Dict, Tuple
from urllib.parse import quote
from functools import lru_cache
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Goku ASCII Art
GOKU_ASCII = r"""
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣶⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣷⡒⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣆⠙⡄⠀⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣤⣤⣤⣤⣤⣤⣤⣤⠤⢄⡀⠀⠀⣿⣿⣿⣿⣿⣿⡆⠘⡄⠀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣿⣿⣿⣿⣿⣿⣿⣦⡈⠒⢄⢸⣿⣿⣿⣿⣿⣿⡀⠱⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣦⠀⠱⣿⣿⣿⣿⣿⣿⣇⠀⢃⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣷⡄⣹⣿⣿⣿⣿⣿⣿⣶⣾⣿⣶⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣶⣾⣭⣍⡉⠙⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣠⣶⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡷⢂⣓⣶⣶⣶⣶⣤⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⠟⢀⣴⢿⣿⣿⣿⠟⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠋⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠤⠤⠤⠤⠙⣻⣿⣿⣿⣿⣿⣿⣾⣿⣿⡏⣠⠟⡉⣾⣿⣿⠋⡠⠊⣿⡟⣹⣿⢿⣿⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣶⣤⣭⣤⣼⣿⢛⣿⣿⣿⣿⣻⣿⣿⠇⠐⢀⣿⣿⡷⠋⠀⢠⣿⣺⣿⣿⢺⣿⣋⣉⣉⣩⣴⣶⣤⣤⣄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠻⠿⣿⣿⣿⣇⢻⣿⣿⡿⠿⣿⣯⡀⠀⢸⣿⠋⢀⣠⣶⠿⠿⢿⡿⠈⣾⣿⣿⣿⣿⡿⠿⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⢧⡸⣿⣿⣿⠀⠃⠻⠟⢦⢾⢣⠶⠿⠏⠀⠰⠀⣼⡇⣸⣿⣿⠟⠉⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⣶⣽⣿⡟⠓⠒⠀⠀⡀⠀⠠⠤⠬⠉⠁⣰⣥⣾⣿⣿⣶⣶⣷⡶⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠹⠟⣿⣿⡄⠀⠀⠠⡇⠀⠀⠀⠀⠀⢠⡟⠛⠛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠋⠹⣷⣄⠀⠐⣊⣀⠀⠀⢀⡴⠁⠣⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣀⠤⠊⢁⡸⠀⣆⠹⣿⣧⣀⠀⠀⡠⠖⡑⠁⠀⠀⠀⠑⢄⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣦⣶⣿⣿⣟⣁⣤⣾⠟⠁⢀⣿⣆⠹⡆⠻⣿⠉⢀⠜⡰⠀⠀⠈⠑⢦⡀⠈⢾⠑⡾⠲⣄⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠖⠒⠚⠛⠛⠢⠽⢄⣘⣤⡎⠠⠿⠂⠀⠠⠴⠶⢉⡭⠃⢸⠃⠀⣿⣿⣿⠡⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡤⠶⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣋⠁⠀⠀⠀⠀⠀⢹⡇⠀⠀⠀⠀⠒⠢⣤⠔⠁⠀⢀⡏⠀⠀⢸⣿⣿⠀⢻⡟⠑⠢⢄⡀⠀⠀⠀⠀
⠀⠀⠀⠀⢸⠀⠀⠀⡀⠉⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⣀⣀⡀⠀⢸⣷⡀⣀⣀⡠⠔⠊⠀⠀⢀⣠⡞⠀⠀⠀⢸⣿⡿⠀⠘⠀⠀⠀⠀⠈⠑⢤⠀⠀
⠀⠀⢀⣴⣿⡀⠀⠀⡇⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣝⡛⠿⢿⣷⣦⣄⡀⠈⠉⠉⠁⠀⠀⠀⢀⣠⣴⣾⣿⡿⠁⠀⠀⠀⢸⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⡜⠀⠀
⠀⢀⣾⣿⣿⡇⠀⢰⣷⠀⢀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⣭⣍⣉⣉⠀⢀⣀⣤⣶⣾⣿⣿⣿⢿⠿⠁⠀⠀⠀⠀⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰⠉⢦⠀
⢀⣼⣿⣿⡿⢱⠀⢸⣿⡀⢸⣧⡀⠀⢿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡭⠖⠁⠀⡠⠂⠀⠀⠀⠀⠀⠀⠀⠀⢠⠀⠀⠀⢠⠃⠀⠈⣀
⢸⣿⣿⣿⡇⠀⢧⢸⣿⣇⢸⣿⣷⡀⠈⣿⣿⣇⠈⠛⢿⣿⣿⣿⣿⣿⣿⠿⠿⠿⠿⠿⠿⠟⡻⠟⠉⠀⠀⡠⠊⠀⢠⠀⠀⠀⠀⠀⠀⠀⠀⣾⡄⠀⢠⣿⠔⠁⠀⢸
⠈⣿⣿⣿⣷⡀⠀⢻⣿⣿⡜⣿⣿⣷⡀⠈⢿⣿⡄⠀⠀⠈⠛⠿⣿⣿⣿⣷⣶⣶⣶⡶⠖⠉⠀⣀⣤⡶⠋⠀⣠⣶⡏⠀⠀⠀⠀⠀⠀⠀⢰⣿⣧⣶⣿⣿⠖⡠⠖⠁
⠀⣿⣿⣷⣌⡛⠶⣼⣿⣿⣷⣿⣿⣿⣿⡄⠈⢻⣷⠀⣄⡀⠀⠀⠀⠈⠉⠛⠛⠛⠁⣀⣤⣶⣾⠟⠋⠀⣠⣾⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⠷⠊⠀⢰⠀
⢰⣿⣿⠀⠈⢉⡶⢿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠙⢇⠈⢿⣶⣦⣤⣀⣀⣠⣤⣶⣿⣿⡿⠛⠁⢀⣤⣾⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⣸⣿⡿⠿⠋⠙⠒⠄⠀⠉⡄
⣿⣿⡏⠀⠀⠁⠀⠀⠀⠉⠉⠙⢻⣿⣿⣿⣿⣷⡀⠀⠀⠀⠻⣿⣿⣿⣿⣿⠿⠿⠛⠁⠀⣀⣴⣿⣿⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⢠⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰
"""

# Platform list (25 total)
PLATFORMS = [
    {'name': 'Twitter', 'url_template': 'https://twitter.com/{}'},
    {'name': 'GitHub', 'url_template': 'https://github.com/{}'},
    {'name': 'Instagram', 'url_template': 'https://instagram.com/{}'},
    {'name': 'Reddit', 'url_template': 'https://reddit.com/user/{}'},
    {'name': 'Facebook', 'url_template': 'https://facebook.com/{}'},
    {'name': 'LinkedIn', 'url_template': 'https://linkedin.com/in/{}'},
    {'name': 'YouTube', 'url_template': 'https://youtube.com/@{}'},
    {'name': 'Twitch', 'url_template': 'https://twitch.tv/{}'},
    {'name': 'TikTok', 'url_template': 'https://tiktok.com/@{}'},
    {'name': 'Pinterest', 'url_template': 'https://pinterest.com/{}'},
    {'name': 'Medium', 'url_template': 'https://medium.com/@{}'},
    {'name': 'Discord', 'url_template': 'https://discord.com/users/{}'},
    {'name': 'Steam', 'url_template': 'https://steamcommunity.com/id/{}'},
    {'name': 'SoundCloud', 'url_template': 'https://soundcloud.com/{}'},
    {'name': 'DeviantArt', 'url_template': 'https://deviantart.com/{}'},
    {'name': 'Tumblr', 'url_template': 'https://{}.tumblr.com'},
    {'name': 'Snapchat', 'url_template': 'https://snapchat.com/add/{}'},
    {'name': 'Vimeo', 'url_template': 'https://vimeo.com/{}'},
    {'name': 'Behance', 'url_template': 'https://behance.net/{}'},
    {'name': 'Dribbble', 'url_template': 'https://dribbble.com/{}'},
    {'name': 'Flickr', 'url_template': 'https://flickr.com/people/{}'},
    {'name': 'Bitbucket', 'url_template': 'https://bitbucket.org/{}'},
    {'name': 'GitLab', 'url_template': 'https://gitlab.com/{}'},
    {'name': 'Patreon', 'url_template': 'https://patreon.com/{}'},
    {'name': 'Mastodon', 'url_template': 'https://mastodon.social/@{}'},
]

# User-Agents
UA_LIST = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1 Mobile/15E148 Safari/604.1',
]

# Proxy list (optional)
PROXIES = []

# Session with retries
session = requests.Session()
retry_strategy = Retry(total=3, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

@lru_cache(maxsize=256)
def generate_variations(username: str) -> tuple:
    """Generate robust username variations."""
    original = username.strip()
    if not original:
        return tuple()
    base = original.lower()
    variations = {original, base}

    if ' ' in original:
        variations.update([original.replace(' ', sep) for sep in ['', '_', '-', '.']])

    for i in '1234':
        variations.update([base + i, i + base, original + i, i + original])

    swaps = {'o': '0', 'l': '1', 'e': '3', 's': '5', 'a': '4', 'i': '1'}
    for orig, new in swaps.items():
        if orig in base:
            variations.add(base.replace(orig, new))
        if orig in original:
            variations.add(original.replace(orig, new))

    for sep in '_-.x':
        variations.update([base + sep, sep + base, original + sep, sep + original])

    variations.update([original.upper(), original.capitalize()])

    for char in '!@#$':
        variations.update([base + char, char + base])

    if re.search(r'(.)\1', base):
        variations.add(re.sub(r'(.)\1', r'\1', base))

    valid_variations = set()
    for var in variations:
        cleaned = var
        if '.tumblr.com' in PLATFORMS[15]['url_template']:  # Tumblr
            cleaned = re.sub(r'\.+', '.', var.strip('.'))  # No consecutive dots
        cleaned = re.sub(r'[^a-zA-Z0-9_.-]', '', cleaned) if not any(c in cleaned for c in '@#') else cleaned
        if (cleaned and len(cleaned) > 1 and not cleaned.startswith(('.', '_', '-')) 
            and not cleaned.endswith(('.', '_', '-')) and '..' not in cleaned):
            valid_variations.add(cleaned)
    
    return tuple(valid_variations)

def check_username(args: Tuple[Dict[str, str], str, bool]) -> Tuple[str, bool, Dict]:
    """Error-free username check."""
    platform, original_username, use_proxy = args
    formatted_username = original_username
    if platform['name'] in ['YouTube', 'TikTok', 'Medium', 'Mastodon'] and '@' not in original_username:
        formatted_username = '@' + original_username
    
    url = platform['url_template'].format(quote(formatted_username))
    if not re.match(r'^https?://[a-zA-Z0-9-._]+', url) or '..' in url:
        return platform['name'], False, {
            'url': url, 'status': 'invalid_url', 'username': original_username, 'formatted': formatted_username
        }

    headers = {'User-Agent': random.choice(UA_LIST)}
    proxies = random.choice(PROXIES) if use_proxy and PROXIES else None
    try:
        response = session.get(url, headers=headers, proxies=proxies, timeout=3, allow_redirects=False)
        status = response.status_code == 200
        if status and platform['name'] == 'Tumblr' and 'This Tumblr is Empty' in response.text:
            status = False
        return platform['name'], status, {
            'url': url,
            'status': 'active' if status else f'code_{response.status_code}',
            'username': original_username,
            'formatted': formatted_username
        }
    except (requests.RequestException, ValueError) as e:
        return platform['name'], False, {
            'url': url, 'status': f'error_{str(e)[:50]}', 'username': original_username, 'formatted': formatted_username
        }

def scan_platforms(username: str, stealth: bool = False, verbose: bool = False) -> Dict:
    """Error-free platform scanning."""
    variations = generate_variations(username)
    if not variations:
        print("\n[Goku Voice] Kamehameha! No valid targets to scan!")
        return {}
    
    results = {var: {'hits': [], 'misses': []} for var in variations}
    tasks = [(p, v, stealth) for v in variations for p in PLATFORMS]
    total_tasks = len(tasks)
    print(f"\n[Goku Voice] Powering up! Scanning {total_tasks} checks at lightning speed!")
    
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(50, total_tasks or 1)) as executor:
            future_to_result = {executor.submit(check_username, task): task for task in tasks}
            completed = 0
            for future in concurrent.futures.as_completed(future_to_result):
                completed += 1
                if verbose and completed % 100 == 0:
                    print(f"[Goku Voice] Progress: {completed}/{total_tasks} targets blasted!")
                platform_name, found, details = future.result()
                var = details['username']  # Use original username, not formatted
                if var not in results:  # Fallback for unexpected key mismatches
                    results[var] = {'hits': [], 'misses': []}
                if found:
                    results[var]['hits'].append({platform_name: details})
                elif verbose:
                    results[var]['misses'].append(platform_name)
    except Exception as e:
        print(f"[Goku Voice] Whoa! Unexpected power surge: {e}")
        return results  # Return partial results if something fails
    
    if verbose:
        for var, data in results.items():
            if data['hits']:
                print(f"\n[Target]: {var}")
                for hit in data['hits']:
                    for p, info in hit.items():
                        print(f"  [+] {p}: {info['url']} (Status: {info['status']})")
            elif verbose > 1:
                print(f"\n[Target]: {var} - No hits (Misses: {', '.join(data['misses'])})")
    
    return results

def save_results(results: Dict, format: str = 'json') -> str:
    """Error-free result saving."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    filename = f"goku_results_{timestamp}.{format}"
    try:
        if format == 'json':
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(results, f, separators=(',', ':'))
        else:  # CSV
            with open(filename, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['Variation', 'Platform', 'URL', 'Status'])
                for var, data in results.items():
                    for hit in data['hits']:
                        for p, info in hit.items():
                            writer.writerow([var, p, info['url'], info['status']])
        return filename
    except (IOError, TypeError) as e:
        print(f"[Goku Voice] Oops! Couldn't save the power: {e}")
        return ""

def cli_main():
    """Error-free CLI entry."""
    parser = argparse.ArgumentParser(description="GokuTrace: Lightning-fast username tracker.")
    parser.add_argument('username', help="Target username")
    parser.add_argument('-s', '--stealth', action='store_true', help="Use proxies if available")
    parser.add_argument('-v', '--verbose', action='count', default=0, help="Verbose output (repeat for more: -vv)")
    parser.add_argument('-o', '--output', choices=['json', 'csv'], default='json', help="Output format")
    try:
        args = parser.parse_args()
    except SystemExit:
        print("[Goku Voice] Huh? Invalid command! Try: python script.py <username> [-s] [-v] [-o json|csv]")
        return

    print(GOKU_ASCII)
    start_time = time.time()
    results = scan_platforms(args.username, args.stealth, args.verbose)
    filename = save_results(results, args.output)
    elapsed = time.time() - start_time
    if filename:
        hits = sum(len(data['hits']) for data in results.values())
        print(f"\n[Goku Voice] It's over 9000! Scan complete in {elapsed:.2f}s! Found {hits} hits. Saved to {filename}")
    else:
        print(f"\n[Goku Voice] Power drained in {elapsed:.2f}s! Failed to save results.")

if __name__ == "__main__":
    cli_main()
