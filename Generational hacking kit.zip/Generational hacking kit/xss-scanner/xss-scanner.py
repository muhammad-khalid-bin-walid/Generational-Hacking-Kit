#!/usr/bin/env python3
# xss-scanner-ultimate.py
# Ultimate XSS Vulnerability Scanner
# Scans websites for XSS vulnerabilities with advanced features, PoCs, and target-based result storage
# Compatible with Python 3.13.2
# Date: April 29, 2025

import argparse
import logging
import logging.handlers
import os
import sys
import json
import time
import sqlite3
from datetime import datetime
from urllib.parse import urlparse, urljoin, parse_qs, urlencode
from pathlib import Path
import requests
from bs4 import BeautifulSoup
import validators
import yaml
import asyncio
import aiohttp
from aiohttp_socks import ProxyConnector
from typing import List, Dict, Set, Optional, Tuple
import re
import string
from cryptography.fernet import Fernet
from hashlib import sha256
import base64
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import socket
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from fastapi import FastAPI
import uvicorn
import threading
import html
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Optional dependencies with fallbacks
try:
    from playwright.async_api import async_playwright
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False
try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False
try:
    from rich.console import Console
    from rich.table import Table
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
try:
    from Levenshtein import distance as levenshtein_distance
    HAS_LEVENSHTEIN = True
except ImportError:
    HAS_LEVENSHTEIN = False
try:
    from reportlab.lib import colors
    HAS_REPORTLAB = True
except ImportError:
    HAS_REPORTLAB = False
try:
    from aiohttp_socks import ProxyConnector
    HAS_AIOHTTP_SOCKS = True
except ImportError:
    HAS_AIOHTTP_SOCKS = False
try:
    from fastapi import FastAPI
    from uvicorn import Config, Server
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

# Setup logging with rotation
log_handler = logging.handlers.RotatingFileHandler(
    "xss_scanner.log", maxBytes=10*1024*1024, backupCount=5
)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        log_handler
    ]
)
logger = logging.getLogger(__name__)

# Rich console
console = Console() if HAS_RICH else None

# Check required dependencies
try:
    import requests
    import bs4
    import lxml
    import validators
    import yaml
except ImportError as e:
    logger.error(f"Missing required dependency: {e}. Please run install.sh.")
    sys.exit(1)

# XSS payloads (safe for testing, triggers alerts without harm)
XSS_PAYLOADS = [
    "<script>alert('XSS');</script>",
    "<img src=x onerror=alert('XSS')>",
    "\"><script>alert('XSS')</script>",
    "javascript:alert('XSS')",
    "<svg onload=alert('XSS')>",
    "<input type='text' value='' onfocus=alert('XSS')>",
    "<body onload=alert('XSS')>",
    "<iframe src=javascript:alert('XSS')>",
    "<a href=javascript:alert('XSS')>Click</a>",
    "';alert('XSS');//",
    "%3Cscript%3Ealert('XSS')%3C/script%3E",
    "<script>prompt('XSS');</script>",
]

class XSSScanner:
    def __init__(self, args: argparse.Namespace):
        self.url: Optional[str] = args.url
        self.urls: List[str] = args.urls.split(",") if args.urls else []
        self.url_file: Optional[str] = args.url_file
        self.max_depth: int = args.max_depth
        self.output_format: str = args.output_format
        self.delay: float = args.delay
        self.proxy: Optional[str] = args.proxy
        self.login_url: Optional[str] = args.login_url
        self.credentials: Dict = {}
        self.cookies: Dict = {}
        self.headers: Dict = {}
        self.verbose: bool = args.verbose
        self.gui: bool = args.gui
        self.use_js: bool = args.use_js
        self.encrypt_reports: bool = args.encrypt_reports
        self.encryption_key: Optional[str] = args.encryption_key
        self.parallel: int = args.parallel
        self.profile: str = args.profile
        self.email: Optional[str] = args.email
        self.smtp_server: Optional[str] = args.smtp_server
        self.smtp_port: int = args.smtp_port
        self.smtp_user: Optional[str] = args.smtp_user
        self.smtp_pass: Optional[str] = args.smtp_pass
        self.session: aiohttp.ClientSession = None
        self.vulnerabilities: List[Dict] = []
        self.pages_scanned: int = 0
        self.inputs_scanned: int = 0
        self.output_folder: Path = Path.cwd()
        self.visited_urls: Set[str] = set()
        self.db_conn: Optional[sqlite3.Connection] = None
        self.progress_bar = None
        self.poc_count: int = 0
        self.rate_limit_detected: bool = False
        self.rate_limit_delay: float = 0.0
        self.poc_server_thread: Optional[threading.Thread] = None
        self.poc_server_port: int = 8000

        # Load scan profile
        self._load_profile()
        # Validate inputs
        self._validate_inputs(args)
        self._configure_logging()

    def _load_profile(self) -> None:
        """Load scan profile from YAML."""
        profiles = {
            "quick": {"max_depth": 1, "parallel": 2, "delay": 0.5, "use_js": False},
            "deep": {"max_depth": 5, "parallel": 10, "delay": 1.0, "use_js": True},
            "stealth": {"max_depth": 3, "parallel": 1, "delay": 5.0, "use_js": False}
        }
        if self.profile and self.profile in profiles:
            profile = profiles[self.profile]
            self.max_depth = profile.get("max_depth", self.max_depth)
            self.parallel = profile.get("parallel", self.parallel)
            self.delay = profile.get("delay", self.delay)
            self.use_js = profile.get("use_js", self.use_js)
            logger.info(f"Applied scan profile: {self.profile}")

    def _validate_inputs(self, args: argparse.Namespace) -> None:
        """Validate all input arguments."""
        if self.url and not validators.url(self.url):
            logger.error(f"Invalid URL: {self.url}")
            raise ValueError(f"Invalid URL: {self.url}")
        self.urls = [u.strip() for u in self.urls if u.strip()]
        for u in self.urls:
            if not validators.url(u):
                logger.error(f"Invalid URL: {u}")
                raise ValueError(f"Invalid URL: {u}")
        self.urls = [u if u.startswith(("http://", "https://")) else f"https://{u}" for u in self.urls]
        if self.url:
            self.url = self.url if self.url.startswith(("http://", "https://")) else f"https://{self.url}"
            self.urls.append(self.url)

        if self.max_depth < 0:
            raise ValueError("Maximum depth must be non-negative")
        if self.delay < 0:
            raise ValueError("Delay must be non-negative")
        if self.parallel < 1:
            raise ValueError("Parallel tasks must be at least 1")

        if args.credentials:
            try:
                self.credentials = json.loads(args.credentials)
            except json.JSONDecodeError as e:
                logger.error(f"Invalid credentials JSON: {e}")
                raise ValueError(f"Invalid credentials JSON: {e}")
        if args.cookies:
            try:
                self.cookies = json.loads(args.cookies)
            except json.JSONDecodeError as e:
                logger.error(f"Invalid cookies JSON: {e}")
                raise ValueError(f"Invalid cookies JSON: {e}")
        if args.headers:
            try:
                self.headers = json.loads(args.headers)
            except json.JSONDecodeError as e:
                logger.error(f"Invalid headers JSON: {e}")
                raise ValueError(f"Invalid headers JSON: {e}")

        if self.url_file:
            url_file_path = Path(self.url_file)
            if not url_file_path.is_file():
                logger.error(f"URL file not found: {self.url_file}")
                raise FileNotFoundError(f"URL file not found: {self.url_file}")

        if self.encrypt_reports and not self.encryption_key:
            raise ValueError("Encryption key is required when --encrypt-reports is specified")

        if self.email and not all([self.smtp_server, self.smtp_port, self.smtp_user, self.smtp_pass]):
            raise ValueError("SMTP server, port, user, and password are required for email notifications")

        if self.use_js and not HAS_PLAYWRIGHT:
            logger.warning("Playwright not installed. Falling back to non-JS mode.")
            self.use_js = False

        if self.verbose:
            logger.setLevel(logging.DEBUG)

    def _configure_logging(self) -> None:
        """Configure logging with JSON handler."""
        if HAS_RICH:
            logger.handlers.append(logging.StreamHandler(sys.stdout))
            logger.info("Rich console enabled")

    async def setup(self) -> None:
        """Initialize session and database."""
        try:
            # Setup aiohttp session
            connector = ProxyConnector.from_url(self.proxy) if self.proxy and HAS_AIOHTTP_SOCKS else aiohttp.TCPConnector(ssl=True, limit=self.parallel)
            timeout = aiohttp.ClientTimeout(total=30)
            self.session = aiohttp.ClientSession(
                connector=connector,
                timeout=timeout,
                headers={
                    "User-Agent": "XSS-Scanner/1.0 (Python/3.13; +https://x.ai)",
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    **self.headers
                },
                cookies=self.cookies
            )
            logger.info(f"Proxy configured: {self.proxy or 'None'}")

            # Setup SQLite database
            self.db_conn = sqlite3.connect("xss_scanner.db")
            self.db_conn.execute("""
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    url TEXT,
                    parameter TEXT,
                    payload TEXT,
                    severity TEXT,
                    details TEXT,
                    poc_file TEXT,
                    score REAL
                )
            """)
            self.db_conn.commit()
            logger.info("SQLite database initialized")

            # Start PoC server
            if HAS_FASTAPI:
                self._start_poc_server()
        except Exception as e:
            logger.error(f"Setup failed: {e}")
            raise

    def _start_poc_server(self) -> None:
        """Start a local FastAPI server for PoC testing."""
        app = FastAPI()
        @app.get("/poc/{poc_id}")
        async def serve_poc(poc_id: str):
            poc_path = self.output_folder / f"poc_{poc_id}_*.html"
            for file in self.output_folder.glob(f"poc_{poc_id}_*.html"):
                try:
                    if self.encrypt_reports:
                        with file.open("rb") as f:
                            content = self._decrypt_content(f.read())
                    else:
                        with file.open("r", encoding="utf-8") as f:
                            content = f.read()
                    return {"content": content}
                except Exception as e:
                    return {"error": f"Failed to load PoC: {e}"}
            return {"error": "PoC not found"}

        def run_server():
            config = Config(app=app, host="127.0.0.1", port=self.poc_server_port)
            server = Server(config)
            server.run()

        self.poc_server_thread = threading.Thread(target=run_server, daemon=True)
        self.poc_server_thread.start()
        logger.info(f"Started PoC server at http://127.0.0.1:{self.poc_server_port}")

    def setup_output_folder(self) -> None:
        """Setup output folder with target name and timestamp."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            if self.url:
                domain = urlparse(self.url).netloc
            elif self.urls:
                domain = urlparse(self.urls[0]).netloc
            else:
                domain = "combined"
            valid_chars = "-_.() %s%s" % (string.ascii_letters, string.digits)
            domain = ''.join(c if c in valid_chars else '_' for c in domain)
            self.output_folder = Path(f"xss_results_{domain}_{timestamp}")
            self.output_folder.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created output folder: {self.output_folder}")
        except (OSError, PermissionError) as e:
            logger.error(f"Failed to setup output folder: {e}")
            raise RuntimeError(f"Failed to setup output folder: {e}")

    async def scan(self) -> None:
        """Main scanning logic."""
        try:
            await self.setup()
            self.setup_output_folder()
            urls = await self.get_urls()
            if not urls:
                logger.error("No valid URLs provided")
                sys.exit(1)

            if HAS_RICH:
                console.print(f"[bold green]Target URLs:[/bold green] {', '.join(urls)}")
            else:
                logger.info(f"Target URLs: {', '.join(urls)}")

            await self.authenticate()

            if HAS_TQDM:
                self.progress_bar = tqdm(total=len(urls), desc="Scanning URLs", unit="url")
            
            tasks = [self.scan_url(url, depth=0) for url in urls]
            await asyncio.gather(*tasks, return_exceptions=True)

            if self.progress_bar:
                self.progress_bar.close()

            self.generate_reports()
            if self.email:
                self._send_email_notification()
            if HAS_RICH:
                console.print(f"[bold green]Scan completed:[/bold green] {self.inputs_scanned} inputs scanned, {len(self.vulnerabilities)} vulnerabilities found")
            else:
                logger.info(f"Scan completed: {self.inputs_scanned} inputs scanned, {len(self.vulnerabilities)} vulnerabilities found")
        except Exception as e:
            logger.error(f"Scan failed: {e}")
            sys.exit(1)
        finally:
            if self.session:
                await self.session.close()
            if self.db_conn:
                self.db_conn.close()

    async def get_urls(self) -> List[str]:
        """Gather URLs from input sources."""
        urls: Set[str] = set(self.urls)
        if self.url_file:
            try:
                with Path(self.url_file).open("r", encoding="utf-8") as f:
                    urls.update(line.strip() for line in f if line.strip())
            except (IOError, UnicodeDecodeError) as e:
                logger.error(f"Failed to read URL file {self.url_file}: {e}")
                return []
        return [url for url in urls if self.is_valid_url(url)]

    @lru_cache(maxsize=1000)
    def is_valid_url(self, url: str) -> bool:
        """Validate URL with caching."""
        try:
            if not validators.url(url):
                logger.warning(f"Invalid URL: {url}")
                return False
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                logger.warning(f"Invalid URL: {url}")
                return False
            return True
        except Exception as e:
            logger.warning(f"Invalid URL {url}: {e}")
            return False

    async def authenticate(self) -> None:
        """Handle authentication."""
        if self.login_url and self.credentials:
            try:
                async with self.session.post(self.login_url, json=self.credentials) as response:
                    response.raise_for_status()
                    logger.info(f"Authenticated successfully at {self.login_url}")
            except aiohttp.ClientError as e:
                logger.error(f"Authentication failed at {self.login_url}: {e}")
        if self.cookies:
            try:
                self.session.cookie_jar.update_cookies(self.cookies)
                logger.info("Authenticated with cookies")
            except Exception as e:
                logger.error(f"Failed to set cookies: {e}")

    async def scan_url(self, url: str, depth: int) -> None:
        """Scan a single URL."""
        if depth > self.max_depth or url in self.visited_urls:
            return

        self.visited_urls.add(url)
        self.pages_scanned += 1
        logger.debug(f"Crawled: {url} (Depth: {depth})")

        try:
            if self.use_js and HAS_PLAYWRIGHT:
                html = await self.fetch_with_playwright(url)
            else:
                async with self.session.get(url) as response:
                    self._detect_rate_limit(response)
                    response.raise_for_status()
                    html = await response.text()
            soup = BeautifulSoup(html, "lxml")
        except (aiohttp.ClientError, ValueError) as e:
            logger.warning(f"Failed to fetch or parse {url}: {e}")
            return

        # Test query parameters
        await self.test_query_params(url)

        # Test forms
        forms = soup.find_all("form")
        self.inputs_scanned += len(forms)
        for form in forms:
            await self.test_form(url, form)

        # Crawl links
        try:
            links = [urljoin(url, a.get("href")) for a in soup.find_all("a", href=True)]
            tasks = [self.scan_url(link, depth + 1) for link in links if self.is_valid_url(link) and link not in self.visited_urls]
            await asyncio.gather(*tasks, return_exceptions=True)
        except Exception as e:
            logger.error(f"Error crawling links from {url}: {e}")

        if self.progress_bar:
            self.progress_bar.update(1)
        time.sleep(self.delay + self.rate_limit_delay)

    def _detect_rate_limit(self, response: aiohttp.ClientResponse) -> None:
        """Detect rate limiting or CAPTCHAs."""
        if response.status in (429, 403):
            self.rate_limit_detected = True
            self.rate_limit_delay = min(self.rate_limit_delay + 1.0, 10.0)
            logger.warning(f"Rate limit detected (status {response.status}). Increasing delay to {self.rate_limit_delay}s")
        elif "captcha" in response.headers.get("Content-Type", "").lower() or "captcha" in str(response.url).lower():
            self.rate_limit_detected = True
            self.rate_limit_delay = 5.0
            logger.warning("CAPTCHA detected. Pausing scan with 5s delay")
        else:
            self.rate_limit_delay = max(self.rate_limit_delay - 0.5, 0.0)

    async def fetch_with_playwright(self, url: str) -> str:
        """Fetch page with Playwright."""
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            try:
                await page.goto(url, timeout=30000)
                await page.wait_for_load_state("domcontentloaded")
                html = await page.content()
                return html
            except Exception as e:
                logger.warning(f"Playwright failed for {url}: {e}")
                return ""
            finally:
                await browser.close()

    async def test_query_params(self, url: str) -> None:
        """Test query parameters for XSS vulnerabilities."""
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)
        if not query_params:
            return

        for param in query_params.keys():
            for payload in XSS_PAYLOADS:
                test_params = query_params.copy()
                test_params[param] = [payload]
                test_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{urlencode(test_params, doseq=True)}"
                try:
                    async with self.session.get(test_url) as response:
                        self._detect_rate_limit(response)
                        response.raise_for_status()
                        html = await response.text()
                        if self._is_xss_vulnerable(html, payload):
                            vuln = {
                                "url": url,
                                "parameter": param,
                                "payload": payload,
                                "severity": "High",
                                "details": f"Reflected XSS in query parameter '{param}' with payload: {payload}",
                                "timestamp": datetime.now().isoformat(),
                                "poc_file": self._generate_poc(url, test_url, payload, param),
                                "score": 7.5
                            }
                            self.vulnerabilities.append(vuln)
                            self._save_vuln_to_db(vuln)
                            logger.warning(f"XSS vulnerability: {vuln['details']}")
                except aiohttp.ClientError as e:
                    logger.debug(f"Failed to test query param {param} at {url}: {e}")

    async def test_form(self, url: str, form: BeautifulSoup) -> None:
        """Test a form for XSS vulnerabilities."""
        action = form.get("action")
        form_url = urljoin(url, action) if action else url
        method = form.get("method", "get").lower()
        inputs = form.find_all("input")
        form_data = {inp.get("name"): inp.get("value") or "" for inp in inputs if inp.get("name")}

        for name in form_data.keys():
            for payload in XSS_PAYLOADS:
                test_data = form_data.copy()
                test_data[name] = payload
                try:
                    if method == "post":
                        async with self.session.post(form_url, data=test_data) as response:
                            self._detect_rate_limit(response)
                            response.raise_for_status()
                            html = await response.text()
                    else:
                        async with self.session.get(form_url, params=test_data) as response:
                            self._detect_rate_limit(response)
                            response.raise_for_status()
                            html = await response.text()

                    if self._is_xss_vulnerable(html, payload):
                        vuln = {
                            "url": url,
                            "parameter": name,
                            "payload": payload,
                            "severity": "High",
                            "details": f"XSS in form input '{name}' with payload: {payload}",
                            "timestamp": datetime.now().isoformat(),
                            "poc_file": self._generate_poc(url, form_url, payload, name),
                            "score": 7.5
                        }
                        self.vulnerabilities.append(vuln)
                        self._save_vuln_to_db(vuln)
                        logger.warning(f"XSS vulnerability: {vuln['details']}")
                except aiohttp.ClientError as e:
                    logger.debug(f"Failed to test form input {name} at {url}: {e}")

    def _is_xss_vulnerable(self, html: str, payload: str) -> bool:
        """Check if response is vulnerable to XSS."""
        decoded_html = html.decode('utf-8', errors='ignore') if isinstance(html, bytes) else html
        # Check for payload reflection
        if payload in decoded_html:
            return True
        # Check for URL-encoded payload
        encoded_payload = html.escape(payload)
        if encoded_payload in decoded_html:
            return True
        # Check for partial matches (e.g., attribute injection)
        payload_patterns = [
            re.escape(payload),
            re.escape(payload.lower()),
            re.escape(payload.replace("'", "\"")),
            re.escape(payload.replace("\"", "'"))
        ]
        for pattern in payload_patterns:
            if re.search(pattern, decoded_html, re.IGNORECASE):
                return True
        return False

    def _generate_poc(self, url: str, test_url: str, payload: str, parameter: str) -> str:
        """Generate a PoC HTML file."""
        try:
            logger.debug(f"Generating PoC for test_url: {test_url}, payload: {payload}, parameter: {parameter}")
            self.poc_count += 1
            parsed = urlparse(test_url)
            path = parsed.path.replace('/', '_').strip('_')
            safe_test_url = f"{parsed.netloc}_{path}" if path else parsed.netloc
            safe_test_url = ''.join(c if c in string.ascii_letters + string.digits + '_-' else '_' for c in safe_test_url)
            safe_test_url = safe_test_url[:50]  # Truncate to avoid long filenames
            poc_filename = f"poc_{self.poc_count}_{safe_test_url}.html"
            poc_path = self.output_folder / poc_filename

            safe_url = html.escape(url)
            safe_test_url_html = html.escape(test_url)
            safe_payload = html.escape(payload)
            safe_parameter = html.escape(parameter)

            poc_content = f"""
            <html>
            <head>
                <title>XSS PoC - {safe_test_url_html}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; }}
                    .warning {{ color: red; font-weight: bold; }}
                    #result {{ margin-top: 20px; padding: 10px; border: 1px solid #ccc; }}
                </style>
            </head>
            <body>
                <h2>XSS Proof of Concept</h2>
                <p><strong>Target URL:</strong> {safe_url}</p>
                <p><strong>Test URL:</strong> {safe_test_url_html}</p>
                <p><strong>Parameter:</strong> {safe_parameter}</p>
                <p><strong>Payload:</strong> {safe_payload}</p>
                <p class="warning">Warning: For authorized testing only. Obtain permission before use.</p>
                <button onclick="testXSS()">Test XSS</button>
                <div id="result">Result: Not tested</div>
                <script>
                    async function testXSS() {{
                        const resultDiv = document.getElementById('result');
                        try {{
                            const response = await fetch('{safe_test_url_html}', {{
                                method: 'GET',
                                credentials: 'include'
                            }});
                            const text = await response.text();
                            resultDiv.innerText = `Result: Status ${response.status} - Check browser console for alert`;
                        }} catch (e) {{
                            resultDiv.innerText = `Result: Error - ${e.message}`;
                        }}
                    }}
                </script>
            </body>
            </html>
            """

            if self.encrypt_reports:
                poc_content = self._encrypt_content(poc_content)
                with poc_path.open("wb") as f:
                    f.write(poc_content)
            else:
                with poc_path.open("w", encoding="utf-8") as f:
                    f.write(poc_content)

            logger.info(f"Generated PoC: {poc_path}")
            if HAS_FASTAPI:
                logger.info(f"PoC available at: http://127.0.0.1:{self.poc_server_port}/poc/{self.poc_count}")
            return str(poc_path)
        except Exception as e:
            logger.error(f"Failed to generate PoC for {test_url}: {e}", exc_info=self.verbose)
            return ""

    def _save_vuln_to_db(self, vuln: Dict) -> None:
        """Save vulnerability to SQLite database."""
        try:
            self.db_conn.execute(
                """
                INSERT INTO scans (timestamp, url, parameter, payload, severity, details, poc_file, score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    vuln["timestamp"],
                    vuln["url"],
                    vuln["parameter"],
                    vuln["payload"],
                    vuln["severity"],
                    vuln["details"],
                    vuln.get("poc_file", ""),
                    vuln.get("score", 0.0)
                )
            )
            self.db_conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Failed to save vulnerability to database: {e}")

    def generate_reports(self) -> None:
        """Generate reports in specified formats."""
        try:
            formats = self.output_format.split(",") if self.output_format != "all" else ["txt", "json", "html", "pdf"]
            for fmt in formats:
                try:
                    if fmt == "txt":
                        self.generate_txt_report()
                    elif fmt == "json":
                        self.generate_json_report()
                    elif fmt == "html":
                        self.generate_html_report()
                    elif fmt == "pdf" and HAS_REPORTLAB:
                        self.generate_pdf_report()
                except Exception as e:
                    logger.error(f"Failed to generate {fmt} report: {e}")
            logger.info("Reports generated successfully")
        except Exception as e:
            logger.error(f"Failed to generate reports: {e}")

    def generate_txt_report(self) -> None:
        """Generate text report."""
        file_path = self.output_folder / "report.txt"
        content = (
            "=== XSS Vulnerability Scan Report ===\n"
            f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Target URLs: {', '.join(self.urls)}\n"
            f"Pages Scanned: {self.pages_scanned}\n"
            f"Inputs Scanned: {self.inputs_scanned}\n"
            f"Vulnerable Inputs: {len(self.vulnerabilities)}\n"
            f"Severity Breakdown: Critical={sum(1 for v in self.vulnerabilities if v['severity'] == 'Critical')}, "
            f"High={sum(1 for v in self.vulnerabilities if v['severity'] == 'High')}, "
            f"Medium={sum(1 for v in self.vulnerabilities if v['severity'] == 'Medium')}\n"
        )
        if self.vulnerabilities:
            content += "\nVulnerable Inputs:\n"
            for v in self.vulnerabilities:
                content += (
                    f"Page: {v['url']}\n"
                    f"Parameter: {v['parameter']}\n"
                    f"Payload: {v['payload']}\n"
                    f"Severity: {v['severity']}\n"
                    f"Score: {v['score']:.1f}\n"
                    f"Details: {v['details']}\n"
                    f"PoC File: {v.get('poc_file', 'N/A')}\n"
                    f"Recommendation: Sanitize and validate all user inputs.\n\n"
                )
        else:
            content += "\nNo XSS vulnerabilities found.\n"

        if self.encrypt_reports:
            content = self._encrypt_content(content)
        try:
            with file_path.open("wb" if self.encrypt_reports else "w", encoding=None if self.encrypt_reports else "utf-8") as f:
                f.write(content)
            logger.info(f"Text report saved to: {file_path}")
        except IOError as e:
            logger.error(f"Failed to save text report: {e}")

    def generate_json_report(self) -> None:
        """Generate JSON report."""
        file_path = self.output_folder / "report.json"
        report = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "urls": self.urls,
            "pages_scanned": self.pages_scanned,
            "inputs_scanned": self.inputs_scanned,
            "vulnerabilities": self.vulnerabilities
        }
        content = json.dumps(report, indent=2)
        if self.encrypt_reports:
            content = self._encrypt_content(content)
        try:
            with file_path.open("wb" if self.encrypt_reports else "w", encoding=None if self.encrypt_reports else "utf-8") as f:
                f.write(content)
            logger.info(f"JSON report saved to: {file_path}")
        except (IOError, TypeError) as e:
            logger.error(f"Failed to save JSON report: {e}")

    def generate_html_report(self) -> None:
        """Generate HTML report."""
        file_path = self.output_folder / "report.html"
        content = f"""
        <html>
        <head><title>XSS Vulnerability Scan Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            table {{ border-collapse: collapse; width: 100%; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #f2f2f2; }}
            h1, h2 {{ color: #333; }}
        </style>
        </head>
        <body>
        <h1>XSS Vulnerability Scan Report</h1>
        <p><b>Timestamp:</b> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p><b>Target URLs:</b> {", ".join(self.urls)}</p>
        <p><b>Pages Scanned:</b> {self.pages_scanned}</p>
        <p><b>Inputs Scanned:</b> {self.inputs_scanned}</p>
        <p><b>Vulnerable Inputs:</b> {len(self.vulnerabilities)}</p>
        <h2>Severity Breakdown</h2>
        <p>Critical: {sum(1 for v in self.vulnerabilities if v["severity"] == "Critical")} | High: {sum(1 for v in self.vulnerabilities if v["severity"] == "High")} | Medium: {sum(1 for v in self.vulnerabilities if v["severity"] == "Medium")}</p>
        <h2>Vulnerable Inputs</h2>
        <table>
        <tr><th>Page URL</th><th>Parameter</th><th>Payload</th><th>Severity</th><th>Score</th><th>Details</th><th>PoC File</th></tr>
        """
        for v in self.vulnerabilities:
            content += f"""
            <tr>
            <td>{v['url']}</td><td>{v['parameter']}</td><td>{html.escape(v['payload'])}</td><td>{v['severity']}</td><td>{v['score']:.1f}</td><td>{v['details']}</td><td>{v.get('poc_file', 'N/A')}</td>
            </tr>
            """
        content += """
        </table>
        <p><b>Recommendation:</b> Sanitize and validate all user inputs.</p>
        </body></html>
        """
        if self.encrypt_reports:
            content = self._encrypt_content(content)
        try:
            with file_path.open("wb" if self.encrypt_reports else "w", encoding=None if self.encrypt_reports else "utf-8") as f:
                f.write(content)
            logger.info(f"HTML report saved to: {file_path}")
        except IOError as e:
            logger.error(f"Failed to save HTML report: {e}")

    def generate_pdf_report(self) -> None:
        """Generate PDF report."""
        file_path = self.output_folder / "report.pdf"
        try:
            doc = SimpleDocTemplate(str(file_path), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []

            story.append(Paragraph("XSS Vulnerability Scan Report", styles['Title']))
            story.append(Spacer(1, 12))
            story.append(Paragraph(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
            story.append(Paragraph(f"Target URLs: {', '.join(self.urls)}", styles['Normal']))
            story.append(Paragraph(f"Pages Scanned: {self.pages_scanned}", styles['Normal']))
            story.append(Paragraph(f"Inputs Scanned: {self.inputs_scanned}", styles['Normal']))
            story.append(Paragraph(f"Vulnerable Inputs: {len(self.vulnerabilities)}", styles['Normal']))
            story.append(Spacer(1, 12))

            data = [["Page URL", "Parameter", "Payload", "Severity", "Score", "Details", "PoC File"]]
            for v in self.vulnerabilities:
                data.append([
                    v["url"], v["parameter"], v["payload"], v["severity"], f"{v['score']:.1f}", v["details"], v.get("poc_file", "N/A")
                ])
            table = Table(data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(table)
            story.append(Spacer(1, 12))
            story.append(Paragraph("Recommendation: Sanitize and validate all user inputs.", styles['Normal']))

            doc.build(story)
            logger.info(f"PDF report saved to: {file_path}")
        except Exception as e:
            logger.error(f"Failed to save PDF report: {e}")

    def _encrypt_content(self, content: str) -> bytes:
        """Encrypt content with Fernet."""
        try:
            key = sha256(self.encryption_key.encode()).digest()
            fernet_key = base64.urlsafe_b64encode(key)
            cipher = Fernet(fernet_key)
            return cipher.encrypt(content.encode())
        except Exception as e:
            logger.error(f"Failed to encrypt content: {e}")
            raise

    def _decrypt_content(self, content: bytes) -> str:
        """Decrypt content with Fernet."""
        try:
            key = sha256(self.encryption_key.encode()).digest()
            fernet_key = base64.urlsafe_b64encode(key)
            cipher = Fernet(fernet_key)
            return cipher.decrypt(content).decode()
        except Exception as e:
            logger.error(f"Failed to decrypt content: {e}")
            raise

    def _send_email_notification(self) -> None:
        """Send scan results via email."""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.smtp_user
            msg['To'] = self.email
            msg['Subject'] = "XSS Scan Report"
            body = (
                f"XSS Vulnerability Scan Report\n"
                f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Target URLs: {', '.join(self.urls)}\n"
                f"Inputs Scanned: {self.inputs_scanned}\n"
                f"Vulnerabilities Found: {len(self.vulnerabilities)}\n"
                f"See attached report for details."
            )
            msg.attach(MIMEText(body, 'plain'))

            with (self.output_folder / "report.json").open("rb" if self.encrypt_reports else "r") as f:
                attachment = MIMEText(f.read(), 'plain')
                attachment.add_header('Content-Disposition', 'attachment', filename="report.json")
                msg.attach(attachment)

            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_pass)
                server.send_message(msg)
            logger.info(f"Sent email notification to {self.email}")
        except Exception as e:
            logger.error(f"Failed to send email notification: {e}")

class XSSScannerGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Ultimate XSS Scanner")
        self.scanner = None
        self.progress = None
        self.result_text = None
        self.setup_gui()

    def setup_gui(self) -> None:
        """Setup GUI elements."""
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # URLs input
        ttk.Label(main_frame, text="Target URLs (comma-separated):").grid(row=0, column=1, sticky=tk.W, pady=2)
        self.urls_entry = ttk.Entry(main_frame, width=50)
        self.urls_entry.grid(row=0, column=2, columnspan=2, sticky=tk.W, pady=2)

        # URL file
        ttk.Label(main_frame, text="URL File:").grid(row=1, column=1, sticky=tk.W, pady=2)
        self.url_file_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=self.url_file_var, width=50).grid(row=1, column=2, sticky=tk.W, pady=2)
        ttk.Button(main_frame, text="Browse", command=self.browse_url_file).grid(row=1, column=3, sticky=tk.W, pady=2)

        # Scan profile
        ttk.Label(main_frame, text="Scan Profile:").grid(row=2, column=1, sticky=tk.W, pady=2)
        self.profile_var = tk.StringVar(value="quick")
        ttk.Combobox(main_frame, textvariable=self.profile_var, values=["quick", "deep", "stealth"], state="readonly").grid(row=2, column=2, sticky=tk.W, pady=2)

        # Max depth
        ttk.Label(main_frame, text="Max Crawl Depth:").grid(row=3, column=1, sticky=tk.W, pady=2)
        self.max_depth_var = tk.StringVar(value="3")
        ttk.Entry(main_frame, textvariable=self.max_depth_var, width=10).grid(row=3, column=2, sticky=tk.W, pady=2)

        # Parallel tasks
        ttk.Label(main_frame, text="Parallel Tasks:").grid(row=4, column=1, sticky=tk.W, pady=2)
        self.parallel_var = tk.StringVar(value="5")
        ttk.Entry(main_frame, textvariable=self.parallel_var, width=10).grid(row=4, column=2, sticky=tk.W, pady=2)

        # Output format
        ttk.Label(main_frame, text="Output Format:").grid(row=5, column=1, sticky=tk.W, pady=2)
        self.output_format_var = tk.StringVar(value="all")
        ttk.Combobox(main_frame, textvariable=self.output_format_var, values=["all", "txt", "json", "html", "pdf"], state="readonly").grid(row=5, column=2, sticky=tk.W, pady=2)

        # Delay
        ttk.Label(main_frame, text="Delay (seconds):").grid(row=6, column=1, sticky=tk.W, pady=2)
        self.delay_var = tk.StringVar(value="1.0")
        ttk.Entry(main_frame, textvariable=self.delay_var, width=10).grid(row=6, column=2, sticky=tk.W, pady=2)

        # Proxy
        ttk.Label(main_frame, text="Proxy (e.g., http://proxy:8080):").grid(row=7, column=1, sticky=tk.W, pady=2)
        self.proxy_entry = ttk.Entry(main_frame, width=50)
        self.proxy_entry.grid(row=7, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Login URL
        ttk.Label(main_frame, text="Login URL (optional):").grid(row=8, column=1, sticky=tk.W, pady=2)
        self.login_url_entry = ttk.Entry(main_frame, width=50)
        self.login_url_entry.grid(row=8, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Credentials
        ttk.Label(main_frame, text="Credentials (JSON):").grid(row=9, column=1, sticky=tk.W, pady=2)
        self.credentials_entry = ttk.Entry(main_frame, width=50)
        self.credentials_entry.grid(row=9, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Cookies
        ttk.Label(main_frame, text="Cookies (JSON):").grid(row=10, column=1, sticky=tk.W, pady=2)
        self.cookies_entry = ttk.Entry(main_frame, width=50)
        self.cookies_entry.grid(row=10, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Headers
        ttk.Label(main_frame, text="Custom Headers (JSON):").grid(row=11, column=1, sticky=tk.W, pady=2)
        self.headers_entry = ttk.Entry(main_frame, width=50)
        self.headers_entry.grid(row=11, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Email
        ttk.Label(main_frame, text="Email for Notifications:").grid(row=12, column=1, sticky=tk.W, pady=2)
        self.email_entry = ttk.Entry(main_frame, width=50)
        self.email_entry.grid(row=12, column=2, columnspan=2, sticky=tk.W, pady=2)

        # SMTP Settings
        ttk.Label(main_frame, text="SMTP Server:").grid(row=13, column=1, sticky=tk.W, pady=2)
        self.smtp_server_entry = ttk.Entry(main_frame, width=50)
        self.smtp_server_entry.grid(row=13, column=2, columnspan=2, sticky=tk.W, pady=2)
        ttk.Label(main_frame, text="SMTP Port:").grid(row=14, column=1, sticky=tk.W, pady=2)
        self.smtp_port_var = tk.StringVar(value="587")
        ttk.Entry(main_frame, textvariable=self.smtp_port_var, width=10).grid(row=14, column=2, sticky=tk.W, pady=2)
        ttk.Label(main_frame, text="SMTP User:").grid(row=15, column=1, sticky=tk.W, pady=2)
        self.smtp_user_entry = ttk.Entry(main_frame, width=50)
        self.smtp_user_entry.grid(row=15, column=2, columnspan=2, sticky=tk.W, pady=2)
        ttk.Label(main_frame, text="SMTP Password:").grid(row=16, column=1, sticky=tk.W, pady=2)
        self.smtp_pass_entry = ttk.Entry(main_frame, width=50, show="*")
        self.smtp_pass_entry.grid(row=16, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Options
        self.verbose_var = tk.BooleanVar()
        self.use_js_var = tk.BooleanVar()
        self.encrypt_reports_var = tk.BooleanVar()
        ttk.Checkbutton(main_frame, text="Verbose Logging", variable=self.verbose_var).grid(row=17, column=2, sticky=tk.W, pady=2)
        ttk.Checkbutton(main_frame, text="Enable JavaScript Rendering", variable=self.use_js_var, state="normal" if HAS_PLAYWRIGHT else "disabled").grid(row=18, column=2, sticky=tk.W, pady=2)
        ttk.Checkbutton(main_frame, text="Encrypt Reports", variable=self.encrypt_reports_var).grid(row=19, column=2, sticky=tk.W, pady=2)

        # Encryption key
        ttk.Label(main_frame, text="Encryption Key (optional):").grid(row=20, column=1, sticky=tk.W, pady=2)
        self.encryption_key_entry = ttk.Entry(main_frame, width=50)
        self.encryption_key_entry.grid(row=20, column=2, columnspan=2, sticky=tk.W, pady=2)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode="indeterminate")
        self.progress.grid(row=21, column=1, columnspan=3, sticky=(tk.W, tk.E), pady=5)

        # Result display
        ttk.Label(main_frame, text="Scan Results:").grid(row=22, column=1, sticky=tk.W, pady=2)
        self.result_text = tk.Text(main_frame, height=10, width=60)
        self.result_text.grid(row=22, column=2, columnspan=2, sticky=(tk.W, tk.E), pady=2)
        scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.result_text.yview)
        scrollbar.grid(row=22, column=4, sticky=(tk.N, tk.S))
        self.result_text['yscrollcommand'] = scrollbar.set

        # Buttons
        ttk.Button(main_frame, text="Start Scan", command=self.start_scan).grid(row=23, column=2, sticky=tk.W, pady=5)
        ttk.Button(main_frame, text="Export Results", command=self.export_results).grid(row=23, column=3, sticky=tk.W, pady=5)

    def browse_url_file(self) -> None:
        """Browse for URL file."""
        try:
            file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if file_path:
                self.url_file_var.set(file_path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to browse file: {e}")

    def export_results(self) -> None:
        """Export scan results to file."""
        if not self.scanner or not self.scanner.vulnerabilities:
            messagebox.showwarning("Warning", "No results to export")
            return
        file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(self.scanner.vulnerabilities, f, indent=2)
                messagebox.showinfo("Success", f"Results exported to {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export results: {e}")

    def start_scan(self) -> None:
        """Start the scan from GUI."""
        try:
            max_depth = int(self.max_depth_var.get())
            delay = float(self.delay_var.get())
            parallel = int(self.parallel_var.get())
            smtp_port = int(self.smtp_port_var.get())
            if max_depth < 0 or delay < 0 or parallel < 1 or smtp_port < 0:
                messagebox.showerror("Error", "Invalid numeric inputs")
                return
            credentials = self.credentials_entry.get()
            cookies = self.cookies_entry.get()
            headers = self.headers_entry.get()
            if credentials:
                json.loads(credentials)
            if cookies:
                json.loads(cookies)
            if headers:
                json.loads(headers)
            args = argparse.Namespace(
                url=self.urls_entry.get(),
                urls=self.urls_entry.get(),
                url_file=self.url_file_var.get(),
                max_depth=max_depth,
                output_format=self.output_format_var.get(),
                delay=delay,
                proxy=self.proxy_entry.get(),
                login_url=self.login_url_entry.get(),
                credentials=credentials,
                cookies=cookies,
                headers=headers,
                verbose=self.verbose_var.get(),
                gui=True,
                use_js=self.use_js_var.get(),
                encrypt_reports=self.encrypt_reports_var.get(),
                encryption_key=self.encryption_key_entry.get(),
                parallel=parallel,
                profile=self.profile_var.get(),
                email=self.email_entry.get(),
                smtp_server=self.smtp_server_entry.get(),
                smtp_port=smtp_port,
                smtp_user=self.smtp_user_entry.get(),
                smtp_pass=self.smtp_pass_entry.get()
            )
            if not any([args.url, args.urls, args.url_file]):
                messagebox.showerror("Error", "Please provide URLs or a URL file")
                return

            self.progress.start()
            self.result_text.delete(1.0, tk.END)
            self.root.update()

            self.scanner = XSSScanner(args)
            asyncio.run(self.scanner.scan())

            self.progress.stop()

            # Display results
            self.result_text.insert(tk.END, f"Inputs Scanned: {self.scanner.inputs_scanned}\n")
            self.result_text.insert(tk.END, f"Vulnerabilities Found: {len(self.scanner.vulnerabilities)}\n")
            for v in self.scanner.vulnerabilities:
                self.result_text.insert(tk.END, (
                    f"\nPage: {v['url']}\n"
                    f"Parameter: {v['parameter']}\n"
                    f"Payload: {v['payload']}\n"
                    f"Severity: {v['severity']}\n"
                    f"Score: {v['score']:.1f}\n"
                    f"Details: {v['details']}\n"
                    f"PoC File: {v.get('poc_file', 'N/A')}\n"
                ))
            messagebox.showinfo(
                "Success",
                f"Scan completed: {self.scanner.inputs_scanned} inputs scanned, {len(self.scanner.vulnerabilities)} vulnerabilities found"
            )
        except ValueError as e:
            self.progress.stop()
            messagebox.showerror("Error", f"Invalid input: {e}")
        except Exception as e:
            self.progress.stop()
            messagebox.showerror("Error", f"Scan failed: {e}")

def check_tkinter() -> None:
    """Check if tkinter is available."""
    try:
        import tkinter
        return True
    except ImportError:
        logger.warning("tkinter is not available. GUI mode will not work. Install python3-tk.")
        return False

def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Ultimate XSS Vulnerability Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n"
               "  Scan a single URL:\n"
               "    python3 xss-scanner-ultimate.py --url https://example.com --use-js --profile deep\n"
               "  Scan multiple URLs with authentication and email:\n"
               "    python3 xss-scanner-ultimate.py --urls https://example.com,https://test.com --login-url https://example.com/login --credentials '{\"username\": \"user\", \"password\": \"pass\"}' --email user@example.com --smtp-server smtp.gmail.com --smtp-port 587 --smtp-user user@gmail.com --smtp-pass pass\n"
               "  Run in GUI mode:\n"
               "    python3 xss-scanner-ultimate.py --gui"
    )
    parser.add_argument("--url", help="Single URL to scan")
    parser.add_argument("--urls", help="Comma-separated list of URLs")
    parser.add_argument("--url-file", help="File containing URLs (one per line)")
    parser.add_argument("--max-depth", type=int, default=3, help="Maximum crawl depth")
    parser.add_argument("--output-format", default="all", help="Output format: txt, json, html, pdf, or all")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between requests in seconds")
    parser.add_argument("--proxy", help="Proxy URL (e.g., http://proxy:8080)")
    parser.add_argument("--login-url", help="Login URL for authenticated pages")
    parser.add_argument("--credentials", help="Login credentials as JSON")
    parser.add_argument("--cookies", help="Cookies as JSON")
    parser.add_argument("--headers", help="Custom headers as JSON")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument("--gui", action="store_true", help="Launch GUI interface")
    parser.add_argument("--use-js", action="store_true", help="Enable JavaScript rendering")
    parser.add_argument("--encrypt-reports", action="store_true", help="Encrypt reports")
    parser.add_argument("--encryption-key", help="Encryption key for reports")
    parser.add_argument("--parallel", type=int, default=5, help="Number of parallel tasks")
    parser.add_argument("--profile", default="quick", help="Scan profile: quick, deep, stealth")
    parser.add_argument("--email", help="Email for notifications")
    parser.add_argument("--smtp-server", help="SMTP server for notifications")
    parser.add_argument("--smtp-port", type=int, default=587, help="SMTP port")
    parser.add_argument("--smtp-user", help="SMTP username")
    parser.add_argument("--smtp-pass", help="SMTP password")

    try:
        args = parser.parse_args()
        if not any([args.url, args.urls, args.url_file]) and not args.gui:
            parser.error("At least one of --url, --urls, or --url-file is required unless --gui is specified")
        if args.gui:
            if not check_tkinter():
                sys.exit(1)
            root = tk.Tk()
            app = XSSScannerGUI(root)
            root.mainloop()
        else:
            scanner = XSSScanner(args)
            asyncio.run(scanner.scan())
    except KeyboardInterrupt:
        logger.error("Scan interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Failed to start scan: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
