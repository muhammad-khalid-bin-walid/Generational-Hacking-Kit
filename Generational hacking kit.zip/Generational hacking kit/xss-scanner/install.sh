# install.sh
#!/bin/bash
set -e
LOG_FILE="csrf_scanner_setup.log"
exec 3>&1 1>>${LOG_FILE} 2>&1
echo "Starting installation process for xss-scanner-ultimate.py" >&3
if ! command -v python3.13 &>/dev/null; then
    echo "Error: Python 3.13 is required." >&3
    exit 1
fi
echo "Creating virtual environment..."
python3.13 -m venv venv
source venv/bin/activate
echo "Upgrading pip..."
pip install --upgrade pip
echo "Installing required dependencies..."
pip install requests beautifulsoup4 lxml validators pyyaml
echo "Installing optional dependencies..."
pip install aiohttp aiohttp[speedups] playwright tqdm rich cryptography reportlab python-Levenshtein aiohttp-socks uvicorn fastapi
if [[ "$1" == "--include-greenlet" ]]; then
    echo "Installing greenlet..."
    pip install greenlet
fi
echo "Verifying installed packages..."
pip list
if command -v playwright &>/dev/null; then
    echo "Installing Playwright browsers..."
    python -m playwright install --with-deps
else
    echo "Warning: Playwright not installed." >&3
fi
if python3.13 -c "import tkinter" &>/dev/null; then
    echo "tkinter is available."
else
    echo "Warning: tkinter is not available. Install python3-tk." >&3
fi
echo "Installation completed successfully." >&3
echo "Activate with: source venv/bin/activate" >&3
