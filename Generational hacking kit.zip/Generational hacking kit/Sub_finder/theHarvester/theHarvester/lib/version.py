VERSION = '4.8.0'


def version() -> str:
    return VERSION
