import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import argparse
import sys
from typing import Set, List, Dict
import json
import os
import csv
from datetime import datetime
import time
import logging
import logging.handlers
from playwright.sync_api import sync_playwright
import random
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import threading
import concurrent.futures
import re
import fnmatch
from robotexclusionrulesparser import RobotExclusionRulesParser
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sqlite3
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import xml.etree.ElementTree as ET

# Configure logging with rotation
log_handler = logging.handlers.RotatingFileHandler('scanner.log', maxBytes=10*1024*1024, backupCount=5)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[log_handler, logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

class ReverseTabnabbingScanner:
    def __init__(self, args):
        self.args = args
        self.urls = self.parse_target_urls(args)
        self.output_folder = self.setup_output_folder()
        self.session = requests.Session()
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]
        self.proxies = self.parse_proxies(args.proxy)
        self.vulnerable_links = []
        self.robots_parser = RobotExclusionRulesParser()
        self.db_conn = self.setup_database() if args.db else None

    def setup_output_folder(self) -> str:
        """Create a timestamped output folder."""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_folder = f"scan_results_{timestamp}"
        os.makedirs(output_folder, exist_ok=True)
        logger.info(f"Created output folder: {output_folder}")
        return output_folder

    def setup_database(self) -> sqlite3.Connection:
        """Setup SQLite database for scan history."""
        db_path = os.path.join(self.output_folder, 'scans.db')
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                url TEXT,
                page_url TEXT,
                link_index INTEGER,
                href TEXT,
                rel TEXT,
                html TEXT,
                is_external BOOLEAN,
                severity TEXT
            )
        ''')
        conn.commit()
        logger.info(f"Initialized SQLite database: {db_path}")
        return conn

    def parse_proxies(self, proxy: str) -> List[str]:
        """Parse proxy list from string or file."""
        if not proxy:
            return []
        if os.path.isfile(proxy):
            try:
                with open(proxy, 'r', encoding='utf-8') as f:
                    return [line.strip() for line in f if line.strip()]
            except IOError as e:
                logger.error(f"Failed to read proxy file {proxy}: {e}")
                sys.exit(1)
        return [proxy]

    def parse_target_urls(self, args) -> Set[str]:
        """Parse target URLs from file, command-line, or wildcards."""
        urls = set()
        
        # Single URL
        if args.url:
            urls.add(args.url)
        
        # Multiple URLs
        if args.urls:
            for url in args.urls.split(','):
                url = url.strip()
                if url:
                    urls.add(url)
        
        # URLs from file
        if args.url_file:
            try:
                with open(args.url_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        url = line.strip()
                        if url:
                            urls.add(url)
            except IOError as e:
                logger.error(f"Failed to read URL file {args.url_file}: {e}")
                sys.exit(1)

        # Handle wildcard patterns
        validated_urls = set()
        url_pattern = re.compile(r'^https?://[^\s/$.?#].[^\s]*$')
        for url in urls:
            if '*' in url:
                try:
                    # Example: Resolve https://*.example.com
                    domain = url.split('://')[1].replace('*', '')
                    response = requests.get(f"https://dns.google/resolve?name={domain}&type=A", timeout=10)
                    if response.status_code == 200:
                        for record in response.json().get('Answer', []):
                            if record.get('type') == 1:  # A record
                                validated_urls.add(f"https://{record['data']}")
                except Exception as e:
                    logger.warning(f"Failed to resolve wildcard URL {url}: {e}")
                continue
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            if url_pattern.match(url):
                validated_urls.add(url)
            else:
                logger.warning(f"Invalid URL skipped: {url}")

        if not validated_urls:
            logger.error("No valid URLs provided")
            sys.exit(1)

        logger.info(f"Target URLs: {', '.join(validated_urls)}")
        return validated_urls

    def authenticate(self, login_url: str, credentials: Dict):
        """Handle authentication, including OAuth tokens."""
        if login_url and credentials:
            try:
                if 'token' in credentials:
                    self.session.headers.update({'Authorization': f"Bearer {credentials['token']}"})
                    logger.info(f"Authenticated with OAuth token at {login_url}")
                else:
                    response = self.session.post(login_url, data=credentials, timeout=10)
                    response.raise_for_status()
                    logger.info(f"Authenticated successfully at {login_url}")
            except requests.RequestException as e:
                logger.error(f"Authentication failed at {login_url}: {e}")
                sys.exit(1)

    def fetch_robots_txt(self, base_url: str):
        """Fetch and parse robots.txt for the base URL."""
        try:
            robots_url = urljoin(base_url, '/robots.txt')
            response = self.session.get(robots_url, timeout=5)
            if response.status_code == 200:
                self.robots_parser.parse(response.text)
                logger.info(f"Fetched robots.txt from {robots_url}")
            else:
                logger.warning(f"No robots.txt found at {robots_url}")
        except Exception as e:
            logger.warning(f"Failed to fetch robots.txt from {robots_url}: {e}")

    def is_url_allowed(self, url: str) -> bool:
        """Check if URL is allowed by robots.txt."""
        return self.robots_parser.is_allowed(self.user_agents[0], url)

    def fetch_page_content(self, url: str, retries: int = 3) -> tuple:
        """Fetch page content using Playwright or requests with retries."""
        if not self.is_url_allowed(url):
            logger.warning(f"URL {url} disallowed by robots.txt")
            return None, 0

        if self.args.use_playwright:
            for attempt in range(retries):
                try:
                    with sync_playwright() as p:
                        browser = p.chromium.launch(headless=True)
                        page = browser.new_page()
                        page.goto(url, timeout=30000)
                        page.wait_for_timeout(int(self.args.wait_time * 1000))
                        content = page.content()
                        browser.close()
                        return content, 200
                except Exception as e:
                    logger.error(f"Playwright attempt {attempt + 1}/{retries} failed for {url}: {e}")
                    if attempt == retries - 1:
                        return None, 0
                    time.sleep(1)
        else:
            for attempt in range(retries):
                try:
                    headers = {'User-Agent': random.choice(self.user_agents)}
                    proxy = random.choice(self.proxies) if self.proxies else None
                    proxies = {'http': proxy, 'https': proxy} if proxy else {}
                    response = self.session.get(url, headers=headers, proxies=proxies, timeout=10)
                    response.raise_for_status()
                    if not response.url.startswith('https'):
                        logger.warning(f"Non-HTTPS URL detected: {response.url}")
                    if not response.headers.get('Content-Security-Policy'):
                        logger.warning(f"No CSP header found on {url}")
                    return response.text, response.status_code
                except requests.RequestException as e:
                    logger.error(f"Request attempt {attempt + 1}/{retries} failed for {url}: {e}")
                    if attempt == retries - 1:
                        return None, 0
                    time.sleep(1)
        return None, 0

    def check_xss_potential(self, href: str) -> bool:
        """Check for potential XSS in link URLs."""
        xss_patterns = [r'javascript:', r'on\w+\s*=', r'<script', r'alert\(']
        return any(re.search(pattern, href, re.IGNORECASE) for pattern in xss_patterns)

    def scan_page(self, url: str, visited: Set[str], base_domain: str, current_depth: int = 0) -> List[Dict]:
        """Scan a page for reverse tabnabbing vulnerabilities."""
        if current_depth > self.args.max_depth:
            return []

        vulnerable_links = []
        content, status_code = self.fetch_page_content(url)
        if not content:
            return vulnerable_links

        try:
            soup = BeautifulSoup(content, 'lxml')
            links = soup.find_all('a', attrs={'target': '_blank'})

            for index, link in enumerate(links, 1):
                href = link.get('href', '(no href)')
                rel = link.get('rel', [])
                if isinstance(rel, str):
                    rel = rel.split()
                is_vulnerable = 'noopener' not in rel or 'noreferrer' not in rel
                severity = 'High' if is_vulnerable and urlparse(href).netloc != base_domain else 'Medium'
                xss_potential = self.check_xss_potential(href)

                if is_vulnerable:
                    link_data = {
                        'page_url': url,
                        'link_index': index,
                        'href': href,
                        'rel': ' '.join(rel) if rel else '(none)',
                        'html': str(link),
                        'is_external': urlparse(href).netloc != base_domain if href.startswith('http') else False,
                        'severity': severity,
                        'xss_potential': xss_potential
                    }
                    vulnerable_links.append(link_data)
                    if self.db_conn:
                        cursor = self.db_conn.cursor()
                        cursor.execute('''
                            INSERT INTO scans (timestamp, url, page_url, link_index, href, rel, html, is_external, severity)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            url, link_data['page_url'], link_data['link_index'], link_data['href'],
                            link_data['rel'], link_data['html'], link_data['is_external'], link_data['severity']
                        ))
                        self.db_conn.commit()

            if current_depth < self.args.max_depth:
                next_urls = []
                for link in soup.find_all('a', href=True):
                    next_url = urljoin(url, link['href'])
                    parsed_url = urlparse(next_url)
                    if parsed_url.netloc == base_domain and next_url not in visited:
                        if self.args.exclude_patterns:
                            if any(fnmatch.fnmatch(next_url, pattern) for pattern in self.args.exclude_patterns):
                                continue
                        visited.add(next_url)
                        next_urls.append(next_url)

                with concurrent.futures.ThreadPoolExecutor(max_workers=self.args.max_workers) as executor:
                    future_to_url = {executor.submit(self.scan_page, u, visited, base_domain, current_depth + 1): u for u in next_urls}
                    for future in concurrent.futures.as_completed(future_to_url):
                        vulnerable_links.extend(future.result())
                        logger.info(f"Crawled: {future_to_url[future]} (Depth: {current_depth + 1})")
                        time.sleep(self.args.delay)

        except Exception as e:
            logger.error(f"Error parsing {url}: {e}")

        return vulnerable_links

    def send_email_notification(self, report_text: str):
        """Send email notification with scan results."""
        if not self.args.email:
            return
        try:
            msg = MIMEMultipart()
            msg['From'] = self.args.email_from
            msg['To'] = self.args.email
            msg['Subject'] = 'Reverse Tabnabbing Scan Report'
            msg.attach(MIMEText(report_text, 'plain'))

            with smtplib.SMTP(self.args.smtp_server, self.args.smtp_port) as server:
                if self.args.smtp_user and self.args.smtp_password:
                    server.starttls()
                    server.login(self.args.smtp_user, self.args.smtp_password)
                server.send_message(msg)
            logger.info(f"Email notification sent to {self.args.email}")
        except Exception as e:
            logger.error(f"Failed to send email notification: {e}")

    def generate_junit_report(self):
        """Generate JUnit XML report for CI/CD."""
        if not self.args.junit:
            return
        testsuite = ET.Element('testsuite', name='ReverseTabnabbingScan', tests=str(len(self.vulnerable_links)))
        for link in self.vulnerable_links:
            testcase = ET.SubElement(testsuite, 'testcase', name=f"Link_{link['link_index']}_{link['page_url']}")
            failure = ET.SubElement(testcase, 'failure', type=link['severity'])
            failure.text = f"Vulnerable link: {link['href']} on {link['page_url']}. Rel: {link['rel']}"
        
        tree = ET.ElementTree(testsuite)
        junit_file = os.path.join(self.output_folder, 'junit_report.xml')
        tree.write(junit_file)
        logger.info(f"JUnit report saved to: {junit_file}")

    def generate_pdf_report(self, report_text: str):
        """Generate PDF report."""
        pdf_file = os.path.join(self.output_folder, 'output.pdf')
        c = canvas.Canvas(pdf_file, pagesize=letter)
        c.setFont("Helvetica", 12)
        y = 750
        for line in report_text.split('\n'):
            if y < 50:
                c.showPage()
                c.setFont("Helvetica", 12)
                y = 750
            c.drawString(50, y, line)
            y -= 15
        c.save()
        logger.info(f"PDF report saved to: {pdf_file}")

    def generate_report(self):
        """Generate and save reports in multiple formats."""
        total_pages_scanned = len(self.visited)
        total_vulnerable_links = len(self.vulnerable_links)
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Summary statistics
        severity_counts = {'High': 0, 'Medium': 0}
        domain_counts = {}
        for link in self.vulnerable_links:
            severity_counts[link['severity']] += 1
            domain = urlparse(link['page_url']).netloc
            domain_counts[domain] = domain_counts.get(domain, 0) + 1

        # Text report
        report_text = [
            "=== Reverse Tabnabbing Vulnerability Scan Report ===",
            f"Timestamp: {timestamp}",
            f"Target URLs: {', '.join(self.urls)}",
            f"Total pages scanned: {total_pages_scanned}",
            f"Total vulnerable links found: {total_vulnerable_links}",
            f"Severity Breakdown: High={severity_counts['High']}, Medium={severity_counts['Medium']}",
            f"Domains Affected: {', '.join(f'{d} ({c})' for d, c in domain_counts.items())}",
            ""
        ]
        if total_vulnerable_links > 0:
            report_text.append("Vulnerable Links Details:")
            for link in self.vulnerable_links:
                report_text.extend([
                    f"\nPage: {link['page_url']}",
                    f"Link {link['link_index']}:",
                    f"- URL: {link['href']}",
                    f"- Rel Attribute: {link['rel']}",
                    f"- HTML: {link['html']}",
                    f"- External Link: {'Yes' if link['is_external'] else 'No'}",
                    f"- Severity: {link['severity']}",
                    f"- XSS Potential: {'Yes' if link['xss_potential'] else 'No'}",
                    ""
                ])
            report_text.append("Recommendation: Add rel=\"noopener noreferrer\" to all target=\"_blank\" links.")
        else:
            report_text.append("No vulnerable links found. All target=\"_blank\" links are secure.")

        # Save text report
        txt_file = os.path.join(self.output_folder, 'output.txt')
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_text))
        logger.info(f"Text report saved to: {txt_file}")

        # Save summary report
        summary_file = os.path.join(self.output_folder, 'summary.txt')
        summary_text = [
            f"Timestamp: {timestamp}",
            f"Total URLs Scanned: {len(self.urls)}",
            f"Total Pages Scanned: {total_pages_scanned}",
            f"Total Vulnerable Links: {total_vulnerable_links}",
            f"Severity: High={severity_counts['High']}, Medium={severity_counts['Medium']}"
        ]
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(summary_text))
        logger.info(f"Summary report saved to: {summary_file}")

        # JSON report
        json_file = os.path.join(self.output_folder, 'output.json')
        report_json = {
            'timestamp': timestamp,
            'target_urls': list(self.urls),
            'total_pages_scanned': total_pages_scanned,
            'total_vulnerable_links': total_vulnerable_links,
            'severity_counts': severity_counts,
            'domain_counts': domain_counts,
            'vulnerable_links': self.vulnerable_links
        }
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(report_json, f, indent=2)
        logger.info(f"JSON report saved to: {json_file}")

        # CSV report
        csv_file = os.path.join(self.output_folder, 'output.csv')
        with open(csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['page_url', 'link_index', 'href', 'rel', 'html', 'is_external', 'severity', 'xss_potential'])
            writer.writeheader()
            writer.writerows(self.vulnerable_links)
        logger.info(f"CSV report saved to: {csv_file}")

        # HTML report
        html_file = os.path.join(self.output_folder, 'output.html')
        html_content = [
            '<html><head><title>Reverse Tabnabbing Scan Report</title>',
            '<style>body{font-family:Arial;padding:20px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background-color:#f2f2f2}tr:nth-child(even){background-color:#f9f9f9}.high{background-color:#ffcccc}.medium{background-color:#fff3cd}</style>',
            '</head><body>',
            '<h1>Reverse Tabnabbing Vulnerability Scan Report</h1>',
            f'<p><strong>Timestamp:</strong> {timestamp}</p>',
            f'<p><strong>Target URLs:</strong> {", ".join(self.urls)}</p>',
            f'<p><strong>Total Pages Scanned:</strong> {total_pages_scanned}</p>',
            f'<p><strong>Total Vulnerable Links Found:</strong> {total_vulnerable_links}</p>',
            f'<p><strong>Severity Breakdown:</strong> High={severity_counts["High"]}, Medium={severity_counts["Medium"]}</p>'
        ]
        if total_vulnerable_links > 0:
            html_content.append('<h2>Vulnerable Links Details</h2><table><tr><th>Page URL</th><th>Link Index</th><th>URL</th><th>Rel Attribute</th><th>HTML</th><th>External</th><th>Severity</th><th>XSS Potential</th></tr>')
            for link in self.vulnerable_links:
                html_content.append(
                    f'<tr class="{link["severity"].lower()}"><td>{link["page_url"]}</td><td>{link["link_index"]}</td><td>{link["href"]}</td>'
                    f'<td>{link["rel"]}</td><td>{link["html"].replace("<", "<").replace(">", ">")}</td>'
                    f'<td>{"Yes" if link["is_external"] else "No"}</td><td>{link["severity"]}</td><td>{"Yes" if link["xss_potential"] else "No"}</td></tr>'
                )
            html_content.append('</table><p><strong>Recommendation:</strong> Add rel="noopener noreferrer" to all target="_blank" links.</p>')
        else:
            html_content.append('<p>No vulnerable links found. All target="_blank" links are secure.</p>')
        html_content.append('</body></html>')
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(html_content))
        logger.info(f"HTML report saved to: {html_file}")

        # PDF report
        self.generate_pdf_report('\n'.join(report_text))

        # JUnit report
        self.generate_junit_report()

        # Email notification
        self.send_email_notification('\n'.join(report_text))

        # Print summary to console
        print('\n'.join(report_text))
        return 1 if total_vulnerable_links > 0 else 0

    def run(self):
        """Run the scanner for all target URLs."""
        if not self.args.no_consent:
            consent = input("Do you have permission to scan the specified URLs? (y/n): ").strip().lower()
            if consent != 'y':
                logger.error("Scan aborted: Permission not confirmed")
                sys.exit(1)

        self.authenticate(self.args.login_url, self.args.credentials)
        for url in self.urls:
            base_domain = urlparse(url).netloc
            self.visited = {url}
            self.fetch_robots_txt(f"https://{base_domain}")
            self.vulnerable_links.extend(self.scan_page(url, self.visited, base_domain))
        exit_code = self.generate_report()
        if self.db_conn:
            self.db_conn.close()
        return exit_code

class ScannerGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Ultimate Reverse Tabnabbing Scanner")
        self.root.geometry("900x700")

        # Progress bar
        self.progress = ttk.Progressbar(self.root, length=400, mode='indeterminate')
        self.progress.pack(pady=5)

        # URL input
        tk.Label(self.root, text="Target URLs (one per line or comma-separated, supports wildcards):").pack(pady=5)
        self.url_text = scrolledtext.ScrolledText(self.root, height=5, width=80)
        self.url_text.pack()

        # File upload
        tk.Label(self.root, text="Or upload a URL file:").pack(pady=5)
        self.file_entry = tk.Entry(self.root, width=50)
        self.file_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(self.root, text="Browse", command=self.browse_file).pack(side=tk.LEFT)

        # Max depth and workers
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Label(frame, text="Max Crawl Depth:").pack(side=tk.LEFT)
        self.depth_entry = tk.Entry(frame, width=10)
        self.depth_entry.insert(0, "3")
        self.depth_entry.pack(side=tk.LEFT, padx=5)
        tk.Label(frame, text="Max Workers:").pack(side=tk.LEFT)
        self.workers_entry = tk.Entry(frame, width=10)
        self.workers_entry.insert(0, "5")
        self.workers_entry.pack(side=tk.LEFT, padx=5)

        # Output format
        tk.Label(self.root, text="Output Format:").pack(pady=5)
        self.format_var = tk.StringVar(value="all")
        formats = [('Text', 'txt'), ('JSON', 'json'), ('CSV', 'csv'), ('HTML', 'html'), ('All', 'all')]
        for text, value in formats:
            tk.Radiobutton(self.root, text=text, variable=self.format_var, value=value).pack()

        # Playwright and wait time
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        self.playwright_var = tk.BooleanVar()
        tk.Checkbutton(frame, text="Use Playwright for dynamic content", variable=self.playwright_var).pack(side=tk.LEFT)
        tk.Label(frame, text="Wait Time (s):").pack(side=tk.LEFT)
        self.wait_entry = tk.Entry(frame, width=10)
        self.wait_entry.insert(0, "2.0")
        self.wait_entry.pack(side=tk.LEFT, padx=5)

        # Delay and exclude patterns
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Label(frame, text="Delay between requests (s):").pack(side=tk.LEFT)
        self.delay_entry = tk.Entry(frame, width=10)
        self.delay_entry.insert(0, "1.0")
        self.delay_entry.pack(side=tk.LEFT, padx=5)
        tk.Label(frame, text="Exclude Patterns (comma-separated):").pack(side=tk.LEFT)
        self.exclude_entry = tk.Entry(frame, width=30)
        self.exclude_entry.pack(side=tk.LEFT, padx=5)

        # Proxy
        tk.Label(self.root, text="Proxy (e.g., http://proxy:8080 or proxy file):").pack(pady=5)
        self.proxy_entry = tk.Entry(self.root, width=50)
        self.proxy_entry.pack()

        # Login URL and credentials
        tk.Label(self.root, text="Login URL (optional):").pack(pady=5)
        self.login_entry = tk.Entry(self.root, width=50)
        self.login_entry.pack()
        tk.Label(self.root, text="Credentials (JSON, e.g., {\"username\": \"user\", \"password\": \"pass\"} or {\"token\": \"xyz\"}):").pack(pady=5)
        self.credentials_entry = tk.Entry(self.root, width=50)
        self.credentials_entry.pack()

        # Email notification
        tk.Label(self.root, text="Email for Notification (optional):").pack(pady=5)
        self.email_entry = tk.Entry(self.root, width=50)
        self.email_entry.pack()

        # Save/load config
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Button(frame, text="Save Config", command=self.save_config).pack(side=tk.LEFT, padx=5)
        tk.Button(frame, text="Load Config", command=self.load_config).pack(side=tk.LEFT, padx=5)

        # Output display
        self.output_text = scrolledtext.ScrolledText(self.root, height=20, width=80)
        self.output_text.pack(pady=10)

        # Scan button
        tk.Button(self.root, text="Start Scan", command=self.start_scan).pack(pady=10)

    def browse_file(self):
        """Open file dialog for URL file."""
        file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file_path:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, file_path)

    def save_config(self):
        """Save current configuration to a JSON file."""
        config = {
            'urls': self.url_text.get("1.0", tk.END).strip(),
            'url_file': self.file_entry.get(),
            'max_depth': self.depth_entry.get(),
            'max_workers': self.workers_entry.get(),
            'output_format': self.format_var.get(),
            'use_playwright': self.playwright_var.get(),
            'wait_time': self.wait_entry.get(),
            'delay': self.delay_entry.get(),
            'exclude_patterns': self.exclude_entry.get(),
            'proxy': self.proxy_entry.get(),
            'login_url': self.login_entry.get(),
            'credentials': self.credentials_entry.get(),
            'email': self.email_entry.get()
        }
        file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if file_path:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2)
            messagebox.showinfo("Success", f"Configuration saved to {file_path}")

    def load_config(self):
        """Load configuration from a JSON file."""
        file_path = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                self.url_text.delete("1.0", tk.END)
                self.url_text.insert("1.0", config.get('urls', ''))
                self.file_entry.delete(0, tk.END)
                self.file_entry.insert(0, config.get('url_file', ''))
                self.depth_entry.delete(0, tk.END)
                self.depth_entry.insert(0, config.get('max_depth', '3'))
                self.workers_entry.delete(0, tk.END)
                self.workers_entry.insert(0, config.get('max_workers', '5'))
                self.format_var.set(config.get('output_format', 'all'))
                self.playwright_var.set(config.get('use_playwright', False))
                self.wait_entry.delete(0, tk.END)
                self.wait_entry.insert(0, config.get('wait_time', '2.0'))
                self.delay_entry.delete(0, tk.END)
                self.delay_entry.insert(0, config.get('delay', '1.0'))
                self.exclude_entry.delete(0, tk.END)
                self.exclude_entry.insert(0, config.get('exclude_patterns', ''))
                self.proxy_entry.delete(0, tk.END)
                self.proxy_entry.insert(0, config.get('proxy', ''))
                self.login_entry.delete(0, tk.END)
                self.login_entry.insert(0, config.get('login_url', ''))
                self.credentials_entry.delete(0, tk.END)
                self.credentials_entry.insert(0, config.get('credentials', ''))
                self.email_entry.delete(0, tk.END)
                self.email_entry.insert(0, config.get('email', ''))
                messagebox.showinfo("Success", f"Configuration loaded from {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load configuration: {e}")

    def start_scan(self):
        """Start the scan in a separate thread."""
        urls_input = self.url_text.get("1.0", tk.END).strip()
        url_file = self.file_entry.get()
        if not urls_input and not url_file:
            messagebox.showerror("Error", "Please provide URLs or a URL file")
            return

        self.progress.start()
        args = argparse.Namespace(
            url=None,
            urls=urls_input.replace('\n', ',') if urls_input else None,
            url_file=url_file or None,
            max_depth=int(self.depth_entry.get() or 3),
            max_workers=int(self.workers_entry.get() or 5),
            output_format=self.format_var.get(),
            use_playwright=self.playwright_var.get(),
            wait_time=float(self.wait_entry.get() or 2.0),
            delay=float(self.delay_entry.get() or 1.0),
            exclude_patterns=self.exclude_entry.get().split(',') if self.exclude_entry.get() else [],
            proxy=self.proxy_entry.get() or None,
            login_url=self.login_entry.get() or None,
            credentials=json.loads(self.credentials_entry.get()) if self.credentials_entry.get() else {},
            email=self.email_entry.get() or None,
            email_from='scanner@example.com',
            smtp_server='smtp.gmail.com',
            smtp_port=587,
            smtp_user=None,
            smtp_password=None,
            db=True,
            junit=True,
            verbose=False,
            no_consent=False
        )

        sys.stdout = TextRedirector(self.output_text)
        def run_scan():
            try:
                scanner = ReverseTabnabbingScanner(args)
                exit_code = scanner.run()
                self.output_text.insert(tk.END, f"\nScan completed with exit code: {exit_code}\n")
            finally:
                self.progress.stop()
                sys.stdout = sys.__stdout__

        threading.Thread(target=run_scan, daemon=True).start()

    def run(self):
        self.root.mainloop()

class TextRedirector:
    def __init__(self, widget):
        self.widget = widget

    def write(self, text):
        self.widget.insert(tk.END, text)
        self.widget.see(tk.END)

    def flush(self):
        pass

def main():
    parser = argparse.ArgumentParser(description="Ultimate Reverse Tabnabbing Vulnerability Scanner")
    parser.add_argument('--url', help="Single URL to scan (e.g., https://example.com)")
    parser.add_argument('--urls', help="Comma-separated list of URLs (e.g., https://example.com,https://test.com)")
    parser.add_argument('--url-file', help="File containing URLs (one per line)")
    parser.add_argument('--max-depth', type=int, default=3, help="Maximum crawl depth (default: 3)")
    parser.add_argument('--max-workers', type=int, default=5, help="Maximum concurrent workers (default: 5)")
    parser.add_argument('--output-format', choices=['txt', 'json', 'csv', 'html', 'all'], default='all',
                        help="Output format: txt, json, csv, html, or all (default: all)")
    parser.add_argument('--use-playwright', action='store_true', help="Use Playwright for dynamic content")
    parser.add_argument('--wait-time', type=float, default=2.0, help="Wait time for dynamic content in seconds (default: 2.0)")
    parser.add_argument('--delay', type=float, default=1.0, help="Delay between requests in seconds (default: 1.0)")
    parser.add_argument('--exclude-patterns', help="Comma-separated URL patterns to exclude (e.g., *login*,*admin*)")
    parser.add_argument('--proxy', help="Proxy URL or file with proxies (e.g., http://proxy:8080)")
    parser.add_argument('--login-url', help="Login URL for authenticated pages")
    parser.add_argument('--credentials', type=json.loads, default={},
                        help="Login credentials as JSON (e.g., '{\"username\": \"user\", \"password\": \"pass\"}' or '{\"token\": \"xyz\"}')")
    parser.add_argument('--email', help="Email address for notification")
    parser.add_argument('--email-from', default='scanner@example.com', help="Sender email address")
    parser.add_argument('--smtp-server', default='smtp.gmail.com', help="SMTP server (default: smtp.gmail.com)")
    parser.add_argument('--smtp-port', type=int, default=587, help="SMTP port (default: 587)")
    parser.add_argument('--smtp-user', help="SMTP username")
    parser.add_argument('--smtp-password', help="SMTP password")
    parser.add_argument('--db', action='store_true', help="Store results in SQLite database")
    parser.add_argument('--junit', action='store_true', help="Generate JUnit XML report")
    parser.add_argument('--verbose', action='store_true', help="Enable verbose logging")
    parser.add_argument('--no-consent', action='store_true', help="Skip consent prompt (for automation)")
    parser.add_argument('--gui', action='store_true', help="Launch GUI interface")
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    if args.exclude_patterns:
        args.exclude_patterns = [p.strip() for p in args.exclude_patterns.split(',') if p.strip()]
    else:
        args.exclude_patterns = []

    if args.gui:
        ScannerGUI().run()
    else:
        if not (args.url or args.urls or args.url_file):
            parser.error("At least one of --url, --urls, or --url-file is required")
        scanner = ReverseTabnabbingScanner(args)
        exit_code = scanner.run()
        sys.exit(exit_code)

if __name__ == '__main__':
    main()
