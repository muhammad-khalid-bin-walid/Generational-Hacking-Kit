import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import argparse
import sys
from typing import Set, List, Dict
import json
import os
import csv
from datetime import datetime
import time
import logging
import logging.handlers
from playwright.sync_api import sync_playwright
import random
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog, PhotoImage
import threading
import concurrent.futures
import re
import fnmatch
import shutil
from robotexclusionrulesparser import RobotExclusionRulesParser
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sqlite3
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
import boto3
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import i18n
import socks
import socket
from tqdm import tqdm
import glob
import yaml

# Configure logging with rotation
log_handler = logging.handlers.RotatingFileHandler('scanner.log', maxBytes=10*1024*1024, backupCount=5)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[log_handler, logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Initialize i18n
TRANSLATIONS_DIR = 'translations'
def load_translations():
    """Load translation files from the translations directory."""
    if not os.path.exists(TRANSLATIONS_DIR):
        logger.warning("Translations directory not found. Falling back to English.")
        return
    try:
        for yaml_file in glob.glob(os.path.join(TRANSLATIONS_DIR, '*.yml')):
            locale = os.path.splitext(os.path.basename(yaml_file))[0]
            with open(yaml_file, 'r', encoding='utf-8') as f:
                translations = yaml.safe_load(f)
            i18n.translations[locale] = translations
        i18n.set('locale', 'en')
        i18n.set('fallback', 'en')
        logger.info("Translations loaded successfully.")
    except Exception as e:
        logger.error(f"Failed to load translations: {e}")
        i18n.set('locale', 'en')

load_translations()

class ReverseTabnabbingScanner:
    def __init__(self, args):
        self.args = args
        self.sitemap_urls = self.parse_sitemap(args.sitemap) if args.sitemap else set()  # Initialize sitemap_urls first
        self.urls = self.parse_target_urls(args)  # Then parse target URLs
        self.output_folders = {}  # Map domains to their output folders
        self.setup_output_folders()
        self.session = requests.Session()
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]
        self.proxies = self.parse_proxies(args.proxy)
        self.vulnerable_links = []
        self.robots_parser = RobotExclusionRulesParser()
        self.db_conn = None  # Initialized per domain in setup_output_folders
        self.cache = {} if args.cache else None
        self.combined_summary = []  # For multi-domain summary
        self.visited = set()

    def setup_output_folders(self):
        """Create output folders named after site domains."""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        for url in self.urls:
            domain = urlparse(url).netloc.replace('www.', '').replace(':', '_').replace('/', '_')
            if not domain:
                logger.error(i18n.t('invalid_domain', url=url))
                sys.exit(1)
            base_folder = f"results_{domain}"
            output_folder = base_folder
            suffix = 1

            if self.args.combine_results and len(self.urls) > 1:
                output_folder = f"results_combined_{timestamp}"
                if output_folder not in self.output_folders.values():
                    self.output_folders['combined'] = output_folder
                self.output_folders[domain] = os.path.join(output_folder, domain)
            else:
                while os.path.exists(output_folder) and not self.args.overwrite:
                    output_folder = f"{base_folder}_{suffix}"
                    suffix += 1
                if os.path.exists(output_folder) and self.args.overwrite:
                    backup_folder = f"{output_folder}.bak_{timestamp}"
                    shutil.move(output_folder, backup_folder)
                    logger.info(i18n.t('backup_folder', folder=output_folder, backup=backup_folder))
                self.output_folders[domain] = output_folder

            os.makedirs(self.output_folders[domain], exist_ok=True)
            logger.info(i18n.t('setup_output_folder', folder=self.output_folders[domain]))

            # Setup SQLite database per domain
            db_path = os.path.join(self.output_folders[domain], 'scans.db')
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    url TEXT,
                    page_url TEXT,
                    link_index INTEGER,
                    href TEXT,
                    rel TEXT,
                    html TEXT,
                    is_external BOOLEAN,
                    severity TEXT,
                    xss_potential BOOLEAN,
                    broken BOOLEAN
                )
            ''')
            conn.commit()
            if self.args.db:
                self.db_conn = conn
            else:
                conn.close()

    def parse_proxies(self, proxy: str) -> List[str]:
        """Parse proxy list from string or file."""
        if not proxy:
            return []
        if os.path.isfile(proxy):
            try:
                with open(proxy, 'r', encoding='utf-8') as f:
                    return [line.strip() for line in f if line.strip()]
            except IOError as e:
                logger.error(i18n.t('parse_proxies_error', file=proxy, error=str(e)))
                sys.exit(1)
        return [proxy]

    def parse_sitemap(self, sitemap_url: str) -> Set[str]:
        """Parse sitemap to extract URLs."""
        try:
            response = self.session.get(sitemap_url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml-xml')
            urls = {loc.text for loc in soup.find_all('loc') if loc.text}
            logger.info(i18n.t('parse_sitemap', url=sitemap_url, count=len(urls)))
            return urls
        except Exception as e:
            logger.error(i18n.t('parse_sitemap_error', url=sitemap_url, error=str(e)))
            return set()

    def parse_target_urls(self, args) -> Set[str]:
        """Parse target URLs from file, command-line, wildcards, or sitemap."""
        urls = set()
        deny_list = {'facebook.com', 'google.com', 'twitter.com'}  # Example deny list
        
        # Single URL
        if args.url:
            urls.add(args.url)
        
        # Multiple URLs
        if args.urls:
            for url in args.urls.split(','):
                url = url.strip()
                if url:
                    urls.add(url)
        
        # URLs from file
        if args.url_file:
            try:
                with open(args.url_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        url = line.strip()
                        if url:
                            urls.add(url)
            except IOError as e:
                logger.error(i18n.t('parse_url_file_error', file=args.url_file, error=str(e)))
                sys.exit(1)

        # Sitemap URLs
        urls.update(self.sitemap_urls)

        # Handle wildcard patterns
        validated_urls = set()
        url_pattern = re.compile(r'^https?://[^\s/$.?#].[^\s]*$')
        for url in urls:
            parsed_domain = urlparse(url).netloc
            if parsed_domain in deny_list:
                logger.warning(i18n.t('url_denied', url=url))
                continue
            if '*' in url:
                try:
                    domain = url.split('://')[1].replace('*', '')
                    response = requests.get(f"https://dns.google/resolve?name={domain}&type=A", timeout=10)
                    if response.status_code == 200:
                        for record in response.json().get('Answer', []):
                            if record.get('type') == 1:  # A record
                                validated_urls.add(f"https://{record['data']}")
                except Exception as e:
                    logger.warning(i18n.t('wildcard_url_error', url=url, error=str(e)))
                continue
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            if url_pattern.match(url):
                validated_urls.add(url)
            else:
                logger.warning(i18n.t('invalid_url', url=url))

        if not validated_urls:
            logger.error(i18n.t('no_valid_urls'))
            sys.exit(1)

        logger.info(i18n.t('target_urls', urls=', '.join(validated_urls)))
        return validated_urls

    def authenticate(self, login_url: str, credentials: Dict, cookies: Dict):
        """Handle authentication, including OAuth tokens and cookies."""
        if cookies:
            self.session.cookies.update(cookies)
            logger.info(i18n.t('auth_cookies'))
        if login_url and credentials:
            try:
                if 'token' in credentials:
                    self.session.headers.update({'Authorization': f"Bearer {credentials['token']}"})
                    logger.info(i18n.t('auth_oauth', url=login_url))
                else:
                    response = self.session.post(login_url, data=credentials, timeout=10)
                    response.raise_for_status()
                    logger.info(i18n.t('auth_success', url=login_url))
            except requests.RequestException as e:
                logger.error(i18n.t('auth_failed', url=login_url, error=str(e)))
                sys.exit(1)

    def fetch_robots_txt(self, base_url: str):
        """Fetch and parse robots.txt for the base URL."""
        try:
            robots_url = urljoin(base_url, '/robots.txt')
            response = self.session.get(robots_url, timeout=5)
            if response.status_code == 200:
                self.robots_parser.parse(response.text)
                logger.info(i18n.t('fetch_robots', url=robots_url))
            else:
                logger.warning(i18n.t('no_robots', url=robots_url))
        except Exception as e:
            logger.warning(i18n.t('fetch_robots_error', url=robots_url, error=str(e)))

    def is_url_allowed(self, url: str) -> bool:
        """Check if URL is allowed by robots.txt."""
        return self.robots_parser.is_allowed(self.user_agents[0], url)

    def setup_tor(self):
        """Setup Tor proxy for anonymous scanning."""
        socks.setdefaultproxy(socks.PROXY_TYPE_SOCKS5, '127.0.0.1', 9050)
        socket.socket = socks.socksocket
        logger.info(i18n.t('tor_enabled'))

    def fetch_page_content(self, url: str, retries: int = 3) -> tuple:
        """Fetch page content using Playwright or requests with retries."""
        if not self.is_url_allowed(url):
            logger.warning(i18n.t('url_disallowed', url=url))
            return None, 0

        if self.args.tor:
            self.setup_tor()

        if self.cache and url in self.cache:
            logger.info(i18n.t('cache_hit', url=url))
            return self.cache[url], 200

        if self.args.use_playwright:
            for attempt in range(retries):
                try:
                    with sync_playwright() as p:
                        browser = p.chromium.launch(headless=True)
                        page = browser.new_page()
                        page.goto(url, timeout=30000)
                        page.wait_for_timeout(int(self.args.wait_time * 1000))
                        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                        time.sleep(1)  # Wait for scroll-triggered content
                        content = page.content()
                        browser.close()
                        if self.cache is not None:
                            self.cache[url] = content
                        return content, 200
                except Exception as e:
                    logger.error(i18n.t('playwright_failed', attempt=attempt+1, retries=retries, url=url, error=str(e)))
                    if attempt == retries - 1:
                        return None, 0
                    time.sleep(1)
        else:
            for attempt in range(retries):
                try:
                    headers = {'User-Agent': random.choice(self.user_agents)}
                    proxy = random.choice(self.proxies) if self.proxies else None
                    proxies = {'http': proxy, 'https': proxy} if proxy else {}
                    response = self.session.get(url, headers=headers, proxies=proxies, timeout=10)
                    response.raise_for_status()
                    if not response.url.startswith('https'):
                        logger.warning(i18n.t('non_https', url=response.url))
                    if not response.headers.get('Content-Security-Policy'):
                        logger.warning(i18n.t('no_csp', url=url))
                    if not response.headers.get('Referrer-Policy'):
                        logger.warning(i18n.t('no_referrer_policy', url=url))
                    if self.cache is not None:
                        self.cache[url] = response.text
                    return response.text, response.status_code
                except requests.RequestException as e:
                    logger.error(i18n.t('request_failed', attempt=attempt+1, retries=retries, url=url, error=str(e)))
                    if attempt == retries - 1:
                        return None, 0
                    time.sleep(1)
        return None, 0

    def check_xss_potential(self, href: str) -> bool:
        """Check for potential XSS in link URLs."""
        xss_patterns = [r'javascript:', r'on\w+\s*=', r'<script', r'alert\(']
        return any(re.search(pattern, href, re.IGNORECASE) for pattern in xss_patterns)

    def check_broken_link(self, href: str) -> bool:
        """Check if a link is broken."""
        try:
            response = self.session.head(href, timeout=5, allow_redirects=True)
            return response.status_code >= 400
        except requests.RequestException:
            return True

    def scan_page(self, url: str, base_domain: str, current_depth: int = 0) -> List[Dict]:
        """Scan a page for reverse tabnabbing vulnerabilities."""
        if current_depth > self.args.max_depth:
            return []

        vulnerable_links = []
        content, status_code = self.fetch_page_content(url)
        if not content:
            return vulnerable_links

        try:
            soup = BeautifulSoup(content, 'lxml')
            links = soup.find_all('a', attrs={'target': '_blank'})

            for index, link in enumerate(links, 1):
                href = link.get('href', '(no href)')
                rel = link.get('rel', [])
                if isinstance(rel, str):
                    rel = rel.split()
                is_vulnerable = 'noopener' not in rel or 'noreferrer' not in rel
                severity = 'High' if is_vulnerable and urlparse(href).netloc != base_domain else 'Medium'
                xss_potential = self.check_xss_potential(href)
                broken = self.check_broken_link(href) if href.startswith('http') else False

                if is_vulnerable:
                    link_data = {
                        'page_url': url,
                        'link_index': index,
                        'href': href,
                        'rel': ' '.join(rel) if rel else '(none)',
                        'html': str(link),
                        'is_external': urlparse(href).netloc != base_domain if href.startswith('http') else False,
                        'severity': severity,
                        'xss_potential': xss_potential,
                        'broken': broken
                    }
                    vulnerable_links.append(link_data)
                    if self.db_conn:
                        cursor = self.db_conn.cursor()
                        cursor.execute('''
                            INSERT INTO scans (timestamp, url, page_url, link_index, href, rel, html, is_external, severity, xss_potential, broken)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            url, link_data['page_url'], link_data['link_index'], link_data['href'],
                            link_data['rel'], link_data['html'], link_data['is_external'], link_data['severity'],
                            link_data['xss_potential'], link_data['broken']
                        ))
                        self.db_conn.commit()

            if current_depth < self.args.max_depth:
                next_urls = []
                for link in soup.find_all('a', href=True):
                    next_url = urljoin(url, link['href'])
                    parsed_url = urlparse(next_url)
                    if parsed_url.netloc == base_domain and next_url not in self.visited:
                        if self.args.exclude_patterns:
                            if any(fnmatch.fnmatch(next_url, pattern) for pattern in self.args.exclude_patterns):
                                continue
                        self.visited.add(next_url)
                        next_urls.append(next_url)

                with concurrent.futures.ThreadPoolExecutor(max_workers=self.args.max_workers) as executor:
                    future_to_url = {executor.submit(self.scan_page, u, base_domain, current_depth + 1): u for u in next_urls}
                    for future in concurrent.futures.as_completed(future_to_url):
                        vulnerable_links.extend(future.result())
                        logger.info(i18n.t('crawled', url=future_to_url[future], depth=current_depth + 1))
                        time.sleep(self.args.delay)

        except Exception as e:
            logger.error(i18n.t('parse_error', url=url, error=str(e)))

        return vulnerable_links

    def send_email_notification(self, report_text: str, output_folder: str):
        """Send email notification with scan results."""
        if not self.args.email:
            return
        try:
            msg = MIMEMultipart()
            msg['From'] = self.args.email_from
            msg['To'] = self.args.email
            msg['Subject'] = i18n.t('email_subject')
            msg.attach(MIMEText(report_text, 'plain'))

            with smtplib.SMTP(self.args.smtp_server, self.args.smtp_port) as server:
                if self.args.smtp_user and self.args.smtp_password:
                    server.starttls()
                    server.login(self.args.smtp_user, self.args.smtp_password)
                server.send_message(msg)
            logger.info(i18n.t('email_sent', email=self.args.email))
        except Exception as e:
            logger.error(i18n.t('email_failed', error=str(e)))

    def send_webhook_notification(self, report_text: str, output_folder: str):
        """Send webhook notification with scan results."""
        if not self.args.webhook:
            return
        try:
            payload = {'text': report_text}
            response = requests.post(self.args.webhook, json=payload, timeout=10)
            response.raise_for_status()
            logger.info(i18n.t('webhook_sent', webhook=self.args.webhook))
        except Exception as e:
            logger.error(i18n.t('webhook_failed', error=str(e)))

    def upload_to_cloud(self, output_folder: str):
        """Upload reports to S3 or Google Drive."""
        if not self.args.cloud:
            return
        try:
            if self.args.cloud.startswith('s3://'):
                bucket, prefix = self.args.cloud.replace('s3://', '').split('/', 1)
                s3 = boto3.client('s3')
                for file in os.listdir(output_folder):
                    file_path = os.path.join(output_folder, file)
                    s3.upload_file(file_path, bucket, f"{prefix}/{file}")
                logger.info(i18n.t('cloud_upload_s3', bucket=bucket))
            elif self.args.cloud.startswith('gdrive://'):
                folder_id = self.args.cloud.replace('gdrive://', '')
                creds = Credentials.from_authorized_user_file(self.args.google_credentials)
                service = build('drive', 'v3', credentials=creds)
                for file in os.listdir(output_folder):
                    file_path = os.path.join(output_folder, file)
                    file_metadata = {'name': file, 'parents': [folder_id]}
                    media = MediaFileUpload(file_path)
                    service.files().create(body=file_metadata, media_body=media, fields='id').execute()
                logger.info(i18n.t('cloud_upload_gdrive', folder=folder_id))
        except Exception as e:
            logger.error(i18n.t('cloud_upload_failed', error=str(e)))

    def generate_junit_report(self, output_folder: str):
        """Generate JUnit XML report for CI/CD."""
        if not self.args.junit:
            return
        testsuite = ET.Element('testsuite', name='ReverseTabnabbingScan', tests=str(len(self.vulnerable_links)))
        for link in self.vulnerable_links:
            testcase = ET.SubElement(testsuite, 'testcase', name=f"Link_{link['link_index']}_{link['page_url']}")
            failure = ET.SubElement(testcase, 'failure', type=link['severity'])
            failure.text = i18n.t('junit_failure', href=link['href'], page_url=link['page_url'], rel=link['rel'])
        
        tree = ET.ElementTree(testsuite)
        junit_file = os.path.join(output_folder, 'junit_report.xml')
        tree.write(junit_file)
        logger.info(i18n.t('junit_saved', file=junit_file))

    def generate_pdf_report(self, report_text: str, output_folder: str):
        """Generate PDF report."""
        pdf_file = os.path.join(output_folder, 'output.pdf')
        c = canvas.Canvas(pdf_file, pagesize=letter)
        c.setFont("Helvetica", 12)
        y = 750
        for line in report_text.split('\n'):
            if y < 50:
                c.showPage()
                c.setFont("Helvetica", 12)
                y = 750
            c.drawString(50, y, line)
            y -= 15
        c.save()
        logger.info(i18n.t('pdf_saved', file=pdf_file))

    def generate_vulnerability_graph(self, severity_counts: Dict, domain_counts: Dict, output_folder: str):
        """Generate a graph of vulnerabilities."""
        plt.figure(figsize=(10, 6))
        plt.subplot(1, 2, 1)
        plt.bar(severity_counts.keys(), severity_counts.values(), color=['red', 'yellow'])
        plt.title(i18n.t('graph_severity_title'))
        plt.xlabel(i18n.t('graph_severity_xlabel'))
        plt.ylabel(i18n.t('graph_count_ylabel'))

        plt.subplot(1, 2, 2)
        domains = list(domain_counts.keys())
        counts = list(domain_counts.values())
        plt.bar(domains, counts, color='blue')
        plt.title(i18n.t('graph_domain_title'))
        plt.xlabel(i18n.t('graph_domain_xlabel'))
        plt.ylabel(i18n.t('graph_count_ylabel'))
        plt.xticks(rotation=45, ha='right')

        plt.tight_layout()
        graph_file = os.path.join(output_folder, 'graph.png')
        plt.savefig(graph_file)
        plt.close()
        logger.info(i18n.t('graph_saved', file=graph_file))

    def generate_report(self, domain: str, output_folder: str):
        """Generate and save reports in multiple formats for a domain."""
        total_pages_scanned = len(self.visited)
        total_vulnerable_links = len(self.vulnerable_links)
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Summary statistics
        severity_counts = {'High': 0, 'Medium': 0}
        domain_counts = {}
        for link in self.vulnerable_links:
            severity_counts[link['severity']] += 1
            link_domain = urlparse(link['page_url']).netloc
            domain_counts[link_domain] = domain_counts.get(link_domain, 0) + 1

        # Text report
        report_text = [
            i18n.t('report_title'),
            i18n.t('report_timestamp', timestamp=timestamp),
            i18n.t('report_target_urls', urls=', '.join(self.urls)),
            i18n.t('report_pages_scanned', count=total_pages_scanned),
            i18n.t('report_vulnerable_links', count=total_vulnerable_links),
            i18n.t('report_severity_breakdown', high=severity_counts['High'], medium=severity_counts['Medium']),
            i18n.t('report_domains_affected', domains=', '.join(f'{d} ({c})' for d, c in domain_counts.items())),
            ""
        ]
        if total_vulnerable_links > 0:
            report_text.append(i18n.t('report_vulnerable_details'))
            for link in self.vulnerable_links:
                report_text.extend([
                    f"\n{i18n.t('report_page', url=link['page_url'])}",
                    i18n.t('report_link', index=link['link_index']),
                    i18n.t('report_url', url=link['href']),
                    i18n.t('report_rel', rel=link['rel']),
                    i18n.t('report_html', html=link['html']),
                    i18n.t('report_external', external='Yes' if link['is_external'] else 'No'),
                    i18n.t('report_severity', severity=link['severity']),
                    i18n.t('report_xss', xss='Yes' if link['xss_potential'] else 'No'),
                    i18n.t('report_broken', broken='Yes' if link['broken'] else 'No'),
                    ""
                ])
            report_text.append(i18n.t('report_recommendation'))
        else:
            report_text.append(i18n.t('report_no_vulnerabilities'))

        # Save text report
        txt_file = os.path.join(output_folder, 'output.txt')
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_text))
        logger.info(i18n.t('txt_saved', file=txt_file))

        # Save summary report
        summary_file = os.path.join(output_folder, 'summary.txt')
        summary_text = [
            i18n.t('summary_timestamp', timestamp=timestamp),
            i18n.t('summary_urls_scanned', count=len(self.urls)),
            i18n.t('summary_pages_scanned', count=total_pages_scanned),
            i18n.t('summary_vulnerable_links', count=total_vulnerable_links),
            i18n.t('summary_severity', high=severity_counts['High'], medium=severity_counts['Medium'])
        ]
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(summary_text))
        logger.info(i18n.t('summary_saved', file=summary_file))

        # Append to combined summary
        self.combined_summary.append(f"\nDomain: {domain}\n" + '\n'.join(summary_text))

        # JSON report
        json_file = os.path.join(output_folder, 'output.json')
        report_json = {
            'timestamp': timestamp,
            'target_urls': list(self.urls),
            'total_pages_scanned': total_pages_scanned,
            'total_vulnerable_links': total_vulnerable_links,
            'severity_counts': severity_counts,
            'domain_counts': domain_counts,
            'vulnerable_links': self.vulnerable_links
        }
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(report_json, f, indent=2)
        logger.info(i18n.t('json_saved', file=json_file))

        # CSV report
        csv_file = os.path.join(output_folder, 'output.csv')
        with open(csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['page_url', 'link_index', 'href', 'rel', 'html', 'is_external', 'severity', 'xss_potential', 'broken'])
            writer.writeheader()
            writer.writerows(self.vulnerable_links)
        logger.info(i18n.t('csv_saved', file=csv_file))

        # HTML report
        html_file = os.path.join(output_folder, 'output.html')
        html_content = [
            '<html><head><title>{}</title>'.format(i18n.t('html_title')),
            '<style>body{font-family:Arial;padding:20px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background-color:#f2f2f2}tr:nth-child(even){background-color:#f9f9f9}.high{background-color:#ffcccc}.medium{background-color:#fff3cd}</style>',
            '</head><body>',
            '<h1>{}</h1>'.format(i18n.t('html_title')),
            '<p><strong>{}</strong> {}</p>'.format(i18n.t('html_timestamp'), timestamp),
            '<p><strong>{}</strong> {}</p>'.format(i18n.t('html_target_urls'), ", ".join(self.urls)),
            '<p><strong>{}</strong> {}</p>'.format(i18n.t('html_pages_scanned'), total_pages_scanned),
            '<p><strong>{}</strong> {}</p>'.format(i18n.t('html_vulnerable_links'), total_vulnerable_links),
            '<p><strong>{}</strong> High={}, Medium={}</p>'.format(i18n.t('html_severity_breakdown'), severity_counts['High'], severity_counts['Medium'])
        ]
        if total_vulnerable_links > 0:
            html_content.append('<h2>{}</h2><table><tr><th>{}</th><th>{}</th><th>{}</th><th>{}</th><th>{}</th><th>{}</th><th>{}</th><th>{}</th><th>{}</th></tr>'.format(
                i18n.t('html_vulnerable_details'), i18n.t('html_page_url'), i18n.t('html_link_index'), i18n.t('html_url'),
                i18n.t('html_rel'), i18n.t('html_html'), i18n.t('html_external'), i18n.t('html_severity'), i18n.t('html_xss'), i18n.t('html_broken')
            ))
            for link in self.vulnerable_links:
                html_content.append(
                    f'<tr class="{link["severity"].lower()}"><td>{link["page_url"]}</td><td>{link["link_index"]}</td><td>{link["href"]}</td>'
                    f'<td>{link["rel"]}</td><td>{link["html"].replace("<", "<").replace(">", ">")}</td>'
                    f'<td>{"Yes" if link["is_external"] else "No"}</td><td>{link["severity"]}</td><td>{"Yes" if link["xss_potential"] else "No"}</td><td>{"Yes" if link["broken"] else "No"}</td></tr>'
                )
            html_content.append('</table><p><strong>{}</strong> {}</p>'.format(i18n.t('html_recommendation'), i18n.t('report_recommendation')))
        else:
            html_content.append('<p>{}</p>'.format(i18n.t('html_no_vulnerabilities')))
        html_content.append('</body></html>')
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(html_content))
        logger.info(i18n.t('html_saved', file=html_file))

        # PDF report
        self.generate_pdf_report('\n'.join(report_text), output_folder)

        # JUnit report
        self.generate_junit_report(output_folder)

        # Vulnerability graph
        self.generate_vulnerability_graph(severity_counts, domain_counts, output_folder)

        # Email notification
        self.send_email_notification('\n'.join(report_text), output_folder)

        # Webhook notification
        self.send_webhook_notification('\n'.join(report_text), output_folder)

        # Cloud upload
        self.upload_to_cloud(output_folder)

        # Print summary to console
        print('\n'.join(report_text))
        return total_vulnerable_links

    def generate_combined_summary(self):
        """Generate a combined summary for all domains."""
        if len(self.urls) > 1:
            combined_file = os.path.join(self.output_folders.get('combined', self.output_folders[list(self.output_folders.keys())[0]]), 'combined_summary.txt')
            with open(combined_file, 'w', encoding='utf-8') as f:
                f.write(i18n.t('combined_summary_title') + '\n')
                f.write('\n'.join(self.combined_summary))
            logger.info(i18n.t('combined_summary_saved', file=combined_file))

    def run(self):
        """Run the scanner for all target URLs."""
        if not self.args.no_consent:
            consent = input(i18n.t('consent_prompt')).strip().lower()
            if consent != 'y':
                logger.error(i18n.t('consent_aborted'))
                sys.exit(1)

        i18n.set('locale', self.args.language)
        self.authenticate(self.args.login_url, self.args.credentials, self.args.cookies)
        exit_code = 0

        for url in tqdm(self.urls, desc=i18n.t('progress_scanning'), unit='url'):
            base_domain = urlparse(url).netloc
            self.visited = {url}
            self.vulnerable_links = []  # Reset for each domain
            self.fetch_robots_txt(f"https://{base_domain}")
            self.vulnerable_links.extend(self.scan_page(url, base_domain))
            output_folder = self.output_folders[base_domain]
            total_vulnerable = self.generate_report(base_domain, output_folder)
            if total_vulnerable > 0:
                exit_code = 1

        self.generate_combined_summary()
        if self.db_conn:
            self.db_conn.close()
        return exit_code

class ScannerGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(i18n.t('gui_title'))
        self.root.geometry("900x700")
        self.theme = 'light'
        self.apply_theme()

        # Progress bar
        self.progress = ttk.Progressbar(self.root, length=400, mode='indeterminate')
        self.progress.pack(pady=5)

        # Theme toggle
        tk.Button(self.root, text=i18n.t('gui_toggle_theme'), command=self.toggle_theme).pack(pady=5)

        # Language selector
        tk.Label(self.root, text=i18n.t('gui_language')).pack(pady=5)
        self.language_var = tk.StringVar(value='en')
        tk.OptionMenu(self.root, self.language_var, 'en', 'es', 'fr', command=self.update_language).pack()

        # URL input
        tk.Label(self.root, text=i18n.t('gui_urls')).pack(pady=5)
        self.url_text = scrolledtext.ScrolledText(self.root, height=5, width=80)
        self.url_text.pack()

        # File upload
        tk.Label(self.root, text=i18n.t('gui_url_file')).pack(pady=5)
        self.file_entry = tk.Entry(self.root, width=50)
        self.file_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(self.root, text=i18n.t('gui_browse'), command=self.browse_file).pack(side=tk.LEFT)

        # Sitemap
        tk.Label(self.root, text=i18n.t('gui_sitemap')).pack(pady=5)
        self.sitemap_entry = tk.Entry(self.root, width=50)
        self.sitemap_entry.pack()

        # Max depth and workers
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Label(frame, text=i18n.t('gui_max_depth')).pack(side=tk.LEFT)
        self.depth_entry = tk.Entry(frame, width=10)
        self.depth_entry.insert(0, "3")
        self.depth_entry.pack(side=tk.LEFT, padx=5)
        tk.Label(frame, text=i18n.t('gui_max_workers')).pack(side=tk.LEFT)
        self.workers_entry = tk.Entry(frame, width=10)
        self.workers_entry.insert(0, "5")
        self.workers_entry.pack(side=tk.LEFT, padx=5)

        # Output format
        tk.Label(self.root, text=i18n.t('gui_output_format')).pack(pady=5)
        self.format_var = tk.StringVar(value="all")
        formats = [('Text', 'txt'), ('JSON', 'json'), ('CSV', 'csv'), ('HTML', 'html'), ('All', 'all')]
        for text, value in formats:
            tk.Radiobutton(self.root, text=text, variable=self.format_var, value=value).pack()

        # Playwright and wait time
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        self.playwright_var = tk.BooleanVar()
        tk.Checkbutton(frame, text=i18n.t('gui_use_playwright'), variable=self.playwright_var).pack(side=tk.LEFT)
        tk.Label(frame, text=i18n.t('gui_wait_time')).pack(side=tk.LEFT)
        self.wait_entry = tk.Entry(frame, width=10)
        self.wait_entry.insert(0, "2.0")
        self.wait_entry.pack(side=tk.LEFT, padx=5)

        # Delay and exclude patterns
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Label(frame, text=i18n.t('gui_delay')).pack(side=tk.LEFT)
        self.delay_entry = tk.Entry(frame, width=10)
        self.delay_entry.insert(0, "1.0")
        self.delay_entry.pack(side=tk.LEFT, padx=5)
        tk.Label(frame, text=i18n.t('gui_exclude_patterns')).pack(side=tk.LEFT)
        self.exclude_entry = tk.Entry(frame, width=30)
        self.exclude_entry.pack(side=tk.LEFT, padx=5)

        # Proxy and Tor
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Label(frame, text=i18n.t('gui_proxy')).pack(side=tk.LEFT)
        self.proxy_entry = tk.Entry(frame, width=30)
        self.proxy_entry.pack(side=tk.LEFT, padx=5)
        self.tor_var = tk.BooleanVar()
        tk.Checkbutton(frame, text=i18n.t('gui_use_tor'), variable=self.tor_var).pack(side=tk.LEFT)

        # Login URL, credentials, and cookies
        tk.Label(self.root, text=i18n.t('gui_login_url')).pack(pady=5)
        self.login_entry = tk.Entry(self.root, width=50)
        self.login_entry.pack()
        tk.Label(self.root, text=i18n.t('gui_credentials')).pack(pady=5)
        self.credentials_entry = tk.Entry(self.root, width=50)
        self.credentials_entry.pack()
        tk.Label(self.root, text=i18n.t('gui_cookies')).pack(pady=5)
        self.cookies_entry = tk.Entry(self.root, width=50)
        self.cookies_entry.pack()

        # Email and webhook
        tk.Label(self.root, text=i18n.t('gui_email')).pack(pady=5)
        self.email_entry = tk.Entry(self.root, width=50)
        self.email_entry.pack()
        tk.Label(self.root, text=i18n.t('gui_webhook')).pack(pady=5)
        self.webhook_entry = tk.Entry(self.root, width=50)
        self.webhook_entry.pack()

        # Cloud upload
        tk.Label(self.root, text=i18n.t('gui_cloud')).pack(pady=5)
        self.cloud_entry = tk.Entry(self.root, width=50)
        self.cloud_entry.pack()

        # Overwrite and combine results
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        self.overwrite_var = tk.BooleanVar()
        tk.Checkbutton(frame, text=i18n.t('gui_overwrite'), variable=self.overwrite_var).pack(side=tk.LEFT)
        self.combine_var = tk.BooleanVar()
        tk.Checkbutton(frame, text=i18n.t('gui_combine_results'), variable=self.combine_var).pack(side=tk.LEFT)

        # Save/load config
        frame = tk.Frame(self.root)
        frame.pack(pady=5)
        tk.Button(frame, text=i18n.t('gui_save_config'), command=self.save_config).pack(side=tk.LEFT, padx=5)
        tk.Button(frame, text=i18n.t('gui_load_config'), command=self.load_config).pack(side=tk.LEFT, padx=5)

        # Output display
        self.output_text = scrolledtext.ScrolledText(self.root, height=15, width=80)
        self.output_text.pack(pady=10)

        # Graph display
        self.graph_label = tk.Label(self.root)
        self.graph_label.pack()

        # Scan button
        tk.Button(self.root, text=i18n.t('gui_start_scan'), command=self.start_scan).pack(pady=10)

    def apply_theme(self):
        """Apply light or dark theme."""
        if self.theme == 'light':
            self.root.configure(bg='white')
        else:
            self.root.configure(bg='#333333')

    def toggle_theme(self):
        """Toggle between light and dark theme."""
        self.theme = 'dark' if self.theme == 'light' else 'light'
        self.apply_theme()

    def update_language(self, lang):
        """Update GUI language."""
        i18n.set('locale', lang)
        self.root.title(i18n.t('gui_title'))
        messagebox.showinfo(i18n.t('gui_language_updated'), i18n.t('gui_language_restart'))

    def browse_file(self):
        """Open file dialog for URL file."""
        file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file_path:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, file_path)

    def save_config(self):
        """Save current configuration to a JSON file."""
        config = {
            'urls': self.url_text.get("1.0", tk.END).strip(),
            'url_file': self.file_entry.get(),
            'sitemap': self.sitemap_entry.get(),
            'max_depth': self.depth_entry.get(),
            'max_workers': self.workers_entry.get(),
            'output_format': self.format_var.get(),
            'use_playwright': self.playwright_var.get(),
            'wait_time': self.wait_entry.get(),
            'delay': self.delay_entry.get(),
            'exclude_patterns': self.exclude_entry.get(),
            'proxy': self.proxy_entry.get(),
            'tor': self.tor_var.get(),
            'login_url': self.login_entry.get(),
            'credentials': self.credentials_entry.get(),
            'cookies': self.cookies_entry.get(),
            'email': self.email_entry.get(),
            'webhook': self.webhook_entry.get(),
            'cloud': self.cloud_entry.get(),
            'overwrite': self.overwrite_var.get(),
            'combine_results': self.combine_var.get(),
            'language': self.language_var.get()
        }
        file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if file_path:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2)
            messagebox.showinfo(i18n.t('gui_save_success'), i18n.t('gui_config_saved', file=file_path))

    def load_config(self):
        """Load configuration from a JSON file."""
        file_path = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                self.url_text.delete("1.0", tk.END)
                self.url_text.insert("1.0", config.get('urls', ''))
                self.file_entry.delete(0, tk.END)
                self.file_entry.insert(0, config.get('url_file', ''))
                self.sitemap_entry.delete(0, tk.END)
                self.sitemap_entry.insert(0, config.get('sitemap', ''))
                self.depth_entry.delete(0, tk.END)
                self.depth_entry.insert(0, config.get('max_depth', '3'))
                self.workers_entry.delete(0, tk.END)
                self.workers_entry.insert(0, config.get('max_workers', '5'))
                self.format_var.set(config.get('output_format', 'all'))
                self.playwright_var.set(config.get('use_playwright', False))
                self.wait_entry.delete(0, tk.END)
                self.wait_entry.insert(0, config.get('wait_time', '2.0'))
                self.delay_entry.delete(0, tk.END)
                self.delay_entry.insert(0, config.get('delay', '1.0'))
                self.exclude_entry.delete(0, tk.END)
                self.exclude_entry.insert(0, config.get('exclude_patterns', ''))
                self.proxy_entry.delete(0, tk.END)
                self.proxy_entry.insert(0, config.get('proxy', ''))
                self.tor_var.set(config.get('tor', False))
                self.login_entry.delete(0, tk.END)
                self.login_entry.insert(0, config.get('login_url', ''))
                self.credentials_entry.delete(0, tk.END)
                self.credentials_entry.insert(0, config.get('credentials', ''))
                self.cookies_entry.delete(0, tk.END)
                self.cookies_entry.insert(0, config.get('cookies', ''))
                self.email_entry.delete(0, tk.END)
                self.email_entry.insert(0, config.get('email', ''))
                self.webhook_entry.delete(0, tk.END)
                self.webhook_entry.insert(0, config.get('webhook', ''))
                self.cloud_entry.delete(0, tk.END)
                self.cloud_entry.insert(0, config.get('cloud', ''))
                self.overwrite_var.set(config.get('overwrite', False))
                self.combine_var.set(config.get('combine_results', False))
                self.language_var.set(config.get('language', 'en'))
                messagebox.showinfo(i18n.t('gui_load_success'), i18n.t('gui_config_loaded', file=file_path))
            except Exception as e:
                messagebox.showerror(i18n.t('gui_load_error'), i18n.t('gui_config_load_failed', error=str(e)))

    def start_scan(self):
        """Start the scan in a separate thread."""
        urls_input = self.url_text.get("1.0", tk.END).strip()
        url_file = self.file_entry.get()
        sitemap = self.sitemap_entry.get()
        if not urls_input and not url_file and not sitemap:
            messagebox.showerror(i18n.t('gui_error'), i18n.t('gui_no_urls'))
            return

        self.progress.start()
        args = argparse.Namespace(
            url=None,
            urls=urls_input.replace('\n', ',') if urls_input else None,
            url_file=url_file or None,
            sitemap=sitemap or None,
            max_depth=int(self.depth_entry.get() or 3),
            max_workers=int(self.workers_entry.get() or 5),
            output_format=self.format_var.get(),
            use_playwright=self.playwright_var.get(),
            wait_time=float(self.wait_entry.get() or 2.0),
            delay=float(self.delay_entry.get() or 1.0),
            exclude_patterns=self.exclude_entry.get().split(',') if self.exclude_entry.get() else [],
            proxy=self.proxy_entry.get() or None,
            tor=self.tor_var.get(),
            login_url=self.login_entry.get() or None,
            credentials=json.loads(self.credentials_entry.get()) if self.credentials_entry.get() else {},
            cookies=json.loads(self.cookies_entry.get()) if self.cookies_entry.get() else {},
            email=self.email_entry.get() or None,
            email_from='scanner@example.com',
            smtp_server='smtp.gmail.com',
            smtp_port=587,
            smtp_user=None,
            smtp_password=None,
            webhook=self.webhook_entry.get() or None,
            cloud=self.cloud_entry.get() or None,
            google_credentials='credentials.json',
            db=True,
            junit=True,
            cache=True,
            overwrite=self.overwrite_var.get(),
            combine_results=self.combine_var.get(),
            verbose=False,
            no_consent=False,
            language=self.language_var.get()
        )

        sys.stdout = TextRedirector(self.output_text)
        def run_scan():
            try:
                scanner = ReverseTabnabbingScanner(args)
                exit_code = scanner.run()
                self.output_text.insert(tk.END, i18n.t('gui_scan_completed', code=exit_code) + '\n')
                graph_file = os.path.join(list(scanner.output_folders.values())[0], 'graph.png')
                if os.path.exists(graph_file):
                    img = PhotoImage(file=graph_file)
                    self.graph_label.configure(image=img)
                    self.graph_label.image = img
            finally:
                self.progress.stop()
                sys.stdout = sys.__stdout__

        threading.Thread(target=run_scan, daemon=True).start()

    def run(self):
        self.root.mainloop()

class TextRedirector:
    def __init__(self, widget):
        self.widget = widget

    def write(self, text):
        self.widget.insert(tk.END, text)
        self.widget.see(tk.END)

    def flush(self):
        pass

def main():
    parser = argparse.ArgumentParser(description=i18n.t('cli_description'))
    parser.add_argument('--url', help=i18n.t('cli_url'))
    parser.add_argument('--urls', help=i18n.t('cli_urls'))
    parser.add_argument('--url-file', help=i18n.t('cli_url_file'))
    parser.add_argument('--sitemap', help=i18n.t('cli_sitemap'))
    parser.add_argument('--max-depth', type=int, default=3, help=i18n.t('cli_max_depth'))
    parser.add_argument('--max-workers', type=int, default=5, help=i18n.t('cli_max_workers'))
    parser.add_argument('--output-format', choices=['txt', 'json', 'csv', 'html', 'all'], default='all',
                        help=i18n.t('cli_output_format'))
    parser.add_argument('--use-playwright', action='store_true', help=i18n.t('cli_use_playwright'))
    parser.add_argument('--wait-time', type=float, default=2.0, help=i18n.t('cli_wait_time'))
    parser.add_argument('--delay', type=float, default=1.0, help=i18n.t('cli_delay'))
    parser.add_argument('--exclude-patterns', help=i18n.t('cli_exclude_patterns'))
    parser.add_argument('--proxy', help=i18n.t('cli_proxy'))
    parser.add_argument('--tor', action='store_true', help=i18n.t('cli_tor'))
    parser.add_argument('--login-url', help=i18n.t('cli_login_url'))
    parser.add_argument('--credentials', type=json.loads, default={},
                        help=i18n.t('cli_credentials'))
    parser.add_argument('--cookies', type=json.loads, default={},
                        help=i18n.t('cli_cookies'))
    parser.add_argument('--email', help=i18n.t('cli_email'))
    parser.add_argument('--email-from', default='scanner@example.com', help=i18n.t('cli_email_from'))
    parser.add_argument('--smtp-server', default='smtp.gmail.com', help=i18n.t('cli_smtp_server'))
    parser.add_argument('--smtp-port', type=int, default=587, help=i18n.t('cli_smtp_port'))
    parser.add_argument('--smtp-user', help=i18n.t('cli_smtp_user'))
    parser.add_argument('--smtp-password', help=i18n.t('cli_smtp_password'))
    parser.add_argument('--webhook', help=i18n.t('cli_webhook'))
    parser.add_argument('--cloud', help=i18n.t('cli_cloud'))
    parser.add_argument('--google-credentials', default='credentials.json', help=i18n.t('cli_google_credentials'))
    parser.add_argument('--db', action='store_true', help=i18n.t('cli_db'))
    parser.add_argument('--junit', action='store_true', help=i18n.t('cli_junit'))
    parser.add_argument('--cache', action='store_true', help=i18n.t('cli_cache'))
    parser.add_argument('--overwrite', action='store_true', help=i18n.t('cli_overwrite'))
    parser.add_argument('--combine-results', action='store_true', help=i18n.t('cli_combine_results'))
    parser.add_argument('--verbose', action='store_true', help=i18n.t('cli_verbose'))
    parser.add_argument('--no-consent', action='store_true', help=i18n.t('cli_no_consent'))
    parser.add_argument('--language', choices=['en', 'es', 'fr'], default='en', help=i18n.t('cli_language'))
    parser.add_argument('--gui', action='store_true', help=i18n.t('cli_gui'))
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    if args.exclude_patterns:
        args.exclude_patterns = [p.strip() for p in args.exclude_patterns.split(',') if p.strip()]
    else:
        args.exclude_patterns = []

    if args.gui:
        ScannerGUI().run()
    else:
        if not (args.url or args.urls or args.url_file or args.sitemap):
            parser.error(i18n.t('cli_no_urls_error'))
        scanner = ReverseTabnabbingScanner(args)
        exit_code = scanner.run()
        sys.exit(exit_code)

if __name__ == '__main__':
    main()
