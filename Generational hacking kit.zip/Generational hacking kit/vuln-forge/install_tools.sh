#!/bin/bash

# Exit on any error
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Logging setup
LOG_FILE="vulnforge_install_$(date +%Y%m%d_%H%M%S).log"
exec 3>&1  # Save stdout for logging
log() {
    echo -e "$1" | tee -a "$LOG_FILE" >&3
}
error_exit() {
    log "${RED}Error: $1${NC}" >&2
    exit 1
}
info() {
    log "${GREEN}$1${NC}"
}
warning() {
    log "${YELLOW}$1${NC}"
}
debug() {
    [ "$DEBUG" = "true" ] && log "${CYAN}Debug: $1${NC}"
}

# Parse command-line arguments
SKIP_VENV=false
PYTHON_BIN=${VULNFORGE_PYTHON:-python3}
DEBUG=false
while [[ $# -gt 0 ]]; do
    case $1 in
        --skip-venv)
            SKIP_VENV=true
            shift
            ;;
        --python)
            PYTHON_BIN="$2"
            shift 2
            ;;
        --debug)
            DEBUG=true
            shift
            ;;
        --help)
            echo "Usage: $0 [--skip-venv] [--python <python-binary>] [--debug]"
            echo "  --skip-venv: Skip virtual environment creation"
            echo "  --python: Specify Python binary (default: python3)"
            echo "  --debug: Enable debug logging"
            exit 0
            ;;
        *)
            error_exit "Unknown option: $1"
            ;;
    esac
done

# Check for write permissions in current directory
info "Checking write permissions..."
if ! touch test_write 2>/dev/null; then
    error_exit "No write permissions in current directory. Run in a writable directory."
fi
rm -f test_write

# Check disk space (at least 500 MB recommended)
info "Checking disk space..."
DISK_SPACE=$(df -m . 2>/dev/null | awk 'NR==2 {print $4}' || echo 1000)
if [ "$DISK_SPACE" -lt 500 ]; then
    warning "Low disk space (${DISK_SPACE} MB available). Recommend at least 500 MB."
fi

# Check for required tools
info "Checking for required tools..."
command -v "$PYTHON_BIN" >/dev/null 2>&1 || error_exit "$PYTHON_BIN is required but not installed. Install Python 3.8+."
command -v "${PYTHON_BIN%3} -m pip" >/dev/null 2>&1 || error_exit "pip for $PYTHON_BIN is required but not installed. Install it with Python."

# Check Python version (requires 3.8+)
info "Checking Python version..."
PYTHON_VERSION=$($PYTHON_BIN --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "0.0.0")
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d'.' -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d'.' -f2)
if [ "$PYTHON_MAJOR" -lt 3 ] || { [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]; }; then
    error_exit "$PYTHON_BIN 3.8 or higher is required. Found $PYTHON_VERSION. Upgrade Python."
fi
info "$PYTHON_BIN version: $PYTHON_VERSION"

# Check system resources
info "Checking system resources..."
if command -v nproc >/dev/null 2>&1; then
    CPU_CORES=$(nproc)
elif command -v sysctl >/dev/null 2>&1; then
    CPU_CORES=$(sysctl -n hw.ncpu 2>/dev/null || echo 4)
else
    CPU_CORES=4
    warning "Could not detect CPU cores. Assuming 4 cores."
fi

if command -v free >/dev/null 2>&1; then
    MEMORY_MB=$(free -m 2>/dev/null | awk '/^Mem:/{print $2}')
elif command -v vm_stat >/dev/null 2>&1 && command -v sysctl >/dev/null 2>&1; then
    MEMORY_MB=$(( $(sysctl -n hw.memsize 2>/dev/null || echo 4194304) / 1024 / 1024 ))
else
    MEMORY_MB=4096
    warning "Could not detect memory. Assuming 4 GB."
fi

info "System: $CPU_CORES CPU cores, $MEMORY_MB MB RAM"
if [ "$MEMORY_MB" -lt 1024 ]; then
    warning "Low memory detected (${MEMORY_MB} MB). Consider reducing concurrency in config.yaml."
fi

# Create requirements.txt if not present
info "Creating requirements.txt..."
if [ ! -f requirements.txt ]; then
    cat > requirements.txt << EOL
PyYAML>=6.0.1,<7.0
requests>=2.31.0,<3.0
aiohttp>=3.9.5,<4.0
rich>=13.7.1,<14.0
tenacity>=8.5.0,<9.0
psutil>=6.0.0,<7.0
pygtrie>=2.5.0,<3.0; python_version >= '3.8'
EOL
fi

# Create virtual environment
if [ "$SKIP_VENV" = "false" ]; then
    info "Setting up Python virtual environment..."
    if [ -d vulnforge_env ]; then
        warning "Virtual environment already exists at vulnforge_env."
        read -p "Delete and recreate? [y/N]: " confirm
        if [[ "$confirm" =~ ^[Yy]$ ]]; then
            rm -rf vulnforge_env
        else
            info "Skipping virtual environment creation."
            SKIP_VENV=true
        fi
    fi
    if [ "$SKIP_VENV" = "false" ]; then
        $PYTHON_BIN -m venv vulnforge_env || error_exit "Failed to create virtual environment. Ensure venv module is available (e.g., apt install python3-venv)."
    fi
fi

# Activate virtual environment
if [ "$SKIP_VENV" = "false" ]; then
    info "Activating virtual environment..."
    if [ -f vulnforge_env/bin/activate ]; then
        source vulnforge_env/bin/activate || error_exit "Failed to activate virtual environment. Check Python installation."
    else
        error_exit "Virtual environment activation script not found. Virtual environment creation may have failed."
    fi
fi

# Upgrade pip and install dependencies
info "Installing dependencies..."
pip install --upgrade pip --no-cache-dir || error_exit "Failed to upgrade pip. Check network connectivity."
pip install -r requirements.txt --no-cache-dir || {
    warning "Failed to install some dependencies. Retrying with core dependencies..."
    pip install PyYAML requests aiohttp rich tenacity psutil --no-cache-dir || error_exit "Failed to install core dependencies. Check network or pip configuration."
    warning "Optional dependency pygtrie skipped. Trie-based AI analysis will be disabled."
}

# Verify Python scripts
info "Verifying Python scripts..."
for script in vulnforge.py template_generator.py; do
    if [ ! -f "$script" ]; then
        warning "$script not found. Some functionality may be limited."
    fi
done

# Create sample files
info "Creating sample files..."
if [ -f vulnforge.py ]; then
    python vulnforge.py --create-samples || warning "Failed to create sample files for vulnforge.py. Check script and Python environment."
fi
if [ -f template_generator.py ]; then
    python template_generator.py --create-samples || warning "Failed to create sample files for template_generator.py. Check script and Python environment."
fi

# Create README.md
info "Creating README.md..."
cat > README.md << EOL
# VulnForge

VulnForge is a high-performance vulnerability scanner with dynamic template generation and AI-driven analysis.

## Prerequisites
- **Python**: 3.8 or higher (Detected: $PYTHON_VERSION)
- **System**: $CPU_CORES CPU cores, $MEMORY_MB MB RAM, $DISK_SPACE MB disk space
- **Tools**: python3, pip3, venv
- **Optional**: NVD API key (https://nvd.nist.gov/developers/request-an-api-key)

## Installation
1. Run \`./install.sh\` to set up the environment.
   - Options: \`--skip-venv\`, \`--python <binary>\`, \`--debug\`
2. Activate the virtual environment:
   \`\`\`bash
   source vulnforge_env/bin/activate
   \`\`\`

## Usage
- **Generate templates**:
  \`\`\`bash
  python template_generator.py -o templates.yaml -c config.yaml -cve CVE-2023-1234
  \`\`\`
- **Run scanner**:
  \`\`\`bash
  python vulnforge.py -t templates.yaml -i targets.txt -o results.json --concurrency $((CPU_CORES * 2))
  \`\`\`
- **Create sample files**:
  \`\`\`bash
  python vulnforge.py --create-samples
  python template_generator.py --create-samples
  \`\`\`
- **Verbose mode**: Add \`--verbose\` to commands

## Configuration
- **config.yaml**: Set NVD API key, rate limits, batch size, etc.
- **Environment Variables**:
  - \`VULNFORGE_PYTHON\`: Python binary (default: python3)
  - \`NVD_API_KEY\`: NVD API key
  - Others: See config.yaml

## Troubleshooting
- **Dependency issues**: Run \`pip install -r requirements.txt\` manually.
- **Low memory/disk**: Free up space ($DISK_SPACE MB available) or reduce concurrency.
- **Network errors**: Check connectivity or retry with \`--debug\`.
- **Logs**: Check $LOG_FILE for details.

## Notes
- **Concurrency**: Recommended: $((CPU_CORES * 2)) (based on $CPU_CORES cores).
- **Memory**: At least 1 GB recommended ($MEMORY_MB MB detected).
- **Disk Space**: Ensure 500 MB free ($DISK_SPACE MB detected).
- **Optional Dependencies**: Install pygtrie for trie-based AI analysis.

For issues, check logs in $LOG_FILE or open an issue on the repository.
EOL

# Verify installation
info "Verifying installation..."
DEPENDENCIES="yaml requests aiohttp rich tenacity psutil"
if python -c "import $DEPENDENCIES" 2>/dev/null; then
    info "Core dependencies verified."
else
    warning "Some core dependencies may not be installed correctly. Run 'pip install -r requirements.txt' manually."
fi
if python -c "import pygtrie" 2>/dev/null; then
    info "Optional dependency pygtrie verified."
else
    warning "pygtrie not installed. Trie-based AI analysis will be disabled."
fi

# Create sample .gitignore
info "Creating .gitignore..."
cat > .gitignore << EOL
vulnforge_env/
*.log
*.pyc
__pycache__/
results.json
EOL

info "VulnForge setup complete!"
log "${YELLOW}To use VulnForge, activate the virtual environment:${NC}"
log "${YELLOW}source vulnforge_env/bin/activate${NC}"
log "${YELLOW}Then run: python vulnforge.py --help${NC}"
log "${YELLOW}Recommended concurrency: $((CPU_CORES * 2))${NC}"
log "${YELLOW}Disk space: $DISK_SPACE MB available, Memory: $MEMORY_MB MB${NC}"
log "${YELLOW}Logs saved to: $LOG_FILE${NC}"

# Ensure virtual environment is not deactivated in script
if [ "$SKIP_VENV" = "false" ]; then
    log "${CYAN}Virtual environment is active. Run 'deactivate' to exit when done.${NC}"
fi
