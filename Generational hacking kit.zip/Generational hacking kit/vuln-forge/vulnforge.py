#!/usr/bin/env python3

import argparse
import yaml
import json
import re
import asyncio
import aiohttp
import logging
import sys
import os
import time
import psutil
from typing import List, Dict, Any, Optional
from urllib.parse import urljoin, urlparse
from datetime import datetime
from rich.console import Console
from rich.progress import Progress
from functools import lru_cache
from collections import defaultdict
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from aiohttp import ClientSession, TCPConnector

try:
    import pygtrie as trie
    TRIE_AVAILABLE = True
except ImportError:
    TRIE_AVAILABLE = False
    trie = None

# Configure logging and rich console
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
console = Console()

class VulnForge:
    """A high-performance, asynchronous vulnerability scanner."""

    def __init__(
        self,
        templates: str,
        targets: str,
        output: str,
        config: str,
        concurrency: Optional[int] = None,
        verbose: bool = False
    ):
        """Initialize VulnForge with optimized settings."""
        self.templates_file = templates
        self.targets_file = targets
        self.output_file = output
        self.config_file = config
        self.verbose = verbose
        self.concurrency = concurrency or max(10, psutil.cpu_count() * 2)
        self.templates: List[Dict[str, Any]] = []
        self.results: List[Dict[str, Any]] = []
        self.config = self.load_config()
        self.session_timeout = aiohttp.ClientTimeout(total=self.config.get('timeout', 10))
        self.rate_limiters = defaultdict(lambda: asyncio.Semaphore(self.config.get('rate_limit', 5)))
        self.global_semaphore = asyncio.Semaphore(self.config.get('global_rate_limit', 100))
        self.start_time = time.time()
        self.request_count = 0
        self.compiled_regexes: Dict[str, Any] = {}
        self.keyword_trie = self.setup_keyword_matching()
        self.batch_size = self.config.get('batch_size', 1000)

    def load_config(self) -> Dict[str, Any]:
        """Load and validate configuration from file or defaults."""
        defaults = {
            'retry_attempts': int(os.getenv('VF_RETRY_ATTEMPTS', 3)),
            'rate_limit': int(os.getenv('VF_RATE_LIMIT', 5)),
            'global_rate_limit': int(os.getenv('VF_GLOBAL_RATE_LIMIT', 100)),
            'batch_size': int(os.getenv('VF_BATCH_SIZE', 1000)),
            'timeout': int(os.getenv('VF_TIMEOUT', 10)),
        }
        try:
            if not os.path.exists(self.config_file):
                logger.warning(f"Config file {self.config_file} not found. Using defaults.")
                return defaults
            with open(self.config_file, 'r') as f:
                config = yaml.safe_load(f) or {}
            # Merge defaults with loaded config
            defaults.update(config)
            # Validate config values
            if defaults['rate_limit'] <= 0 or defaults['global_rate_limit'] <= 0:
                raise ValueError("Rate limits must be positive")
            if defaults['batch_size'] <= 0:
                raise ValueError("Batch size must be positive")
            if defaults['timeout'] <= 0:
                raise ValueError("Timeout must be positive")
            return defaults
        except (yaml.YAMLError, ValueError) as e:
            logger.error(f"Invalid config in {self.config_file}: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            sys.exit(1)

    def setup_keyword_matching(self) -> Any:
        """Setup keyword matching with trie or fallback to dictionary."""
        keywords = {'error': -0.2, 'script': 0.3, 'alert': 0.3, 'redirect': 0.2, 'invalid': -0.1}
        if TRIE_AVAILABLE:
            keyword_trie = trie.Trie()
            for keyword, weight in keywords.items():
                keyword_trie[keyword] = weight
            return keyword_trie
        else:
            logger.warning("pygtrie not installed. Falling back to dictionary-based matching.")
            return keywords

    def load_templates(self) -> None:
        """Load and parse templates with streaming and validation."""
        try:
            if not os.path.exists(self.templates_file):
                raise FileNotFoundError(f"Template file {self.templates_file} not found")
            with open(self.templates_file, 'r') as f:
                templates_data = yaml.safe_load(f)
            if not templates_data or 'templates' not in templates_data:
                raise ValueError("No templates found in file")
            self.templates = templates_data['templates']
            for template in self.templates:
                if not template.get('id') or not template.get('requests'):
                    raise ValueError(f"Invalid template: {template.get('id', 'unknown')}")
                for request in template.get('requests', []):
                    for matcher in request.get('matchers', []):
                        if matcher['type'] == 'regex':
                            matcher['compiled_regex'] = [
                                re.compile(pattern, re.IGNORECASE) for pattern in matcher['regex']
                            ]
            console.print(f"[green]Loaded {len(self.templates)} templates[/green]")
        except (yaml.YAMLError, ValueError) as e:
            logger.error(f"Invalid templates in {self.templates_file}: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Failed to load templates: {e}")
            sys.exit(1)

    def load_targets(self) -> List[str]:
        """Load and validate targets with generator."""
        try:
            if not os.path.exists(self.targets_file):
                raise FileNotFoundError(f"Targets file {self.targets_file} not found")
            validated_targets = []
            def target_generator():
                with open(self.targets_file, 'r') as f:
                    for line in f:
                        target = line.strip()
                        if target:
                            if not re.match(r'^https?://', target):
                                target = f'http://{target}'
                            parsed = urlparse(target)
                            if parsed.scheme and parsed.netloc:
                                yield target
                            else:
                                logger.warning(f"Invalid URL skipped: {target}")
            validated_targets = list(target_generator())
            if not validated_targets:
                raise ValueError("No valid targets found")
            console.print(f"[green]Loaded {len(validated_targets)} valid targets[/green]")
            return validated_targets
        except Exception as e:
            logger.error(f"Failed to load targets: {e}")
            sys.exit(1)

    @lru_cache(maxsize=1000)
    def generate_dynamic_template(self, cve_id: str) -> Optional[Dict[str, Any]]:
        """Generate a dynamic template for a given CVE (mock implementation)."""
        logger.warning(
            f"Dynamic template for {cve_id} uses mock data. "
            "Integrate with template_generator.py or CVE database for production."
        )
        mock_cve_data = {
            'CVE-2023-1234': {
                'description': 'Cross-site scripting (XSS) vulnerability in user input field.',
                'pattern': r'<script>alert\(.*?\)</script>',
                'payload': '<script>alert("vulnforge")</script>',
                'method': 'GET',
                'path': '/search?q={{payload}}'
            }
        }
        if cve_id not in mock_cve_data:
            logger.warning(f"No data for {cve_id}.")
            return None
        cve = mock_cve_data[cve_id]
        template = {
            'id': f'dynamic-{cve_id}',
            'info': {
                'name': f'{cve_id} XSS Vulnerability',
                'severity': 'medium',
                'description': cve['description']
            },
            'requests': [{
                'method': cve['method'],
                'path': cve['path'],
                'payloads': {'payload': cve['payload']},
                'matchers': [{
                    'type': 'regex',
                    'condition': 'and',
                    'regex': [cve['pattern']],
                    'compiled_regex': [re.compile(cve['pattern'], re.IGNORECASE)]
                }]
            }]
        }
        return template

    def sanitize_payload(self, payload: str) -> str:
        """Sanitize payloads to prevent injection risks."""
        # Basic sanitization: replace dangerous characters
        dangerous_chars = {'<': '&lt;', '>': '&gt;', '&': '&amp;'}
        for char, escape in dangerous_chars.items():
            payload = payload.replace(char, escape)
        return payload

    def ai_analyze_response(self, response_text: str, template: Dict[str, Any]) -> float:
        """Analyze response using AI-driven scoring."""
        try:
            score = 0.0
            response_lower = response_text.lower()[:10000]  # Limit analysis size
            # Keyword matching
            if TRIE_AVAILABLE:
                for prefix, weight in self.keywordмотря: pass
                if prefix in response_lower:
                    score += weight
            else:
                for keyword, weight in self.keyword_trie.items():
                    if keyword in response_lower:
                        score += weight
            # Regex matching
            for matcher in template['requests'][0].get('matchers', []):
                if matcher['type'] == 'regex':
                    for compiled_regex in matcher.get('compiled_regex', []):
                        if compiled_regex.search(response_text):
                            score += 0.5
            return min(max(score, 0.0), 1.0)
        except Exception as e:
            logger.error(f"AI analysis failed for template {template.get('id', 'unknown')}: {e}")
            return 0.0

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError))
    )
    async def scan_target(
        self, session: ClientSession, target: str, template: Dict[str, Any], domain: str
    ) -> Optional[Dict[str, Any]]:
        """Scan a single target with rate limiting and adaptive throttling."""
        try:
            async with self.global_semaphore, self.rate_limiters[domain]:
                request = template['requests'][0]
                method = request.get('method', 'GET').upper()
                path = request.get('path', '/')
                payloads = request.get('payloads', {})

                for key, value in payloads.items():
                    sanitized_value = self.sanitize_payload(value)
                    path = path.replace(f'{{{{{key}}}}}', sanitized_value)
                url = urljoin(target, path)

                async with session.request(method, url, allow_redirects=False) as response:
                    self.request_count += 1
                    if response.status == 429:  # Too Many Requests
                        logger.warning(f"Rate limit hit for {domain}. Pausing...")
                        await asyncio.sleep(5)  # Adaptive backoff
                        raise aiohttp.ClientError("Rate limit exceeded")
                    # Stream response to handle large bodies
                    response_text = ""
                    async for chunk in response.content.iter_chunked(1024):
                        response_text += chunk.decode('utf-8', errors='ignore')
                        if len(response_text) > 10000:
                            response_text = response_text[:10000]
                            break
                    ai_score = self.ai_analyze_response(response_text, template)

                    if ai_score > 0.5:
                        result = {
                            'timestamp': datetime.utcnow().isoformat(),
                            'target': target,
                            'url': url,
                            'template_id': template['id'],
                            'severity': template['info']['severity'],
                            'description': template['info']['description'],
                            'ai_confidence': ai_score,
                            'status_code': response.status
                        }
                        if self.verbose:
                            console.print(
                                f"[cyan]Debug: Scanned {url} (Status: {response.status}, Score: {ai_score:.2f})[/cyan]"
                            )
                        return result
                    return None
        except aiohttp.ClientError as e:
            logger.error(f"Network error scanning {target} with template {template.get('id', 'unknown')}: {e}")
            return None
        except Exception as e:
            logger.error(f"Error scanning {target} with template {template.get('id', 'unknown')}: {e}")
            return None

    async def run_batch(self, session: ClientSession, targets: List[str], templates: List[Dict[str, Any]]) -> None:
        """Run scans for a batch of targets."""
        tasks = []
        for target in targets:
            domain = urlparse(target).netloc
            for template in templates:
                tasks.append(self.scan_target(session, target, template, domain))
                if len(tasks) >= self.concurrency:
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    self.results.extend([r for r in results if isinstance(r, dict)])
                    tasks = []
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            self.results.extend([r for r in results if isinstance(r, dict)])

    async def run_scans(self, targets: List[str]) -> None:
        """Run asynchronous scans with batch processing."""
        connector = TCPConnector(limit_per_host=100, limit=0)
        async with ClientSession(timeout=self.session_timeout, connector=connector) as session:
            with Progress(console=console) as progress:
                total_tasks = len(targets) * len(self.templates)
                task_id = progress.add_task("[cyan]Scanning targets...", total=total_tasks)
                completed_tasks = 0
                for i in range(0, len(targets), self.batch_size):
                    batch = targets[i:i + self.batch_size]
                    await self.run_batch(session, batch, self.templates)
                    completed_tasks += len(batch) * len(self.templates)
                    progress.update(task_id, advance=len(batch) * len(self.templates))
                # Ensure progress bar reflects completion
                progress.update(task_id, completed=total_tasks)

    def log_performance_metrics(self) -> None:
        """Log performance metrics."""
        duration = time.time() - self.start_time
        rps = self.request_count / duration if duration > 0 else 0
        memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB
        console.print(f"[cyan]Performance Metrics:[/cyan]")
        console.print(f"[cyan]  Duration: {duration:.2f} seconds[/cyan]")
        console.print(f"[cyan]  Requests: {self.request_count} ({rps:.2f} req/s)[/cyan]")
        console.print(f"[cyan]  Memory Usage: {memory:.2f} MB[/cyan]")
        console.print(f"[cyan]  Vulnerabilities Found: {len(self.results)}[/cyan]")

    def save_results(self) -> None:
        """Save scan results with error handling."""
        try:
            os.makedirs(os.path.dirname(self.output_file) or '.', exist_ok=True)
            with open(self.output_file, 'w') as f:
                json.dump(self.results, f, indent=2)
            console.print(f"[green]Results saved to {self.output_file}[/green]")
        except Exception as e:
            logger.error(f"Failed to save results: {e}")
            sys.exit(1)

    def run(self) -> None:
        """Run the vulnerability scan."""
        try:
            self.load_templates()
            targets = self.load_targets()
            dynamic_template = self.generate_dynamic_template('CVE-2023-1234')
            if dynamic_template:
                self.templates.append(dynamic_template)
                console.print("[green]Added dynamic template for CVE-2023-1234[/green]")
            asyncio.run(self.run_scans(targets))
            self.save_results()
            self.log_performance_metrics()
        except KeyboardInterrupt:
            console.print("[yellow]Scan interrupted. Saving partial results...[/yellow]")
            self.save_results()
            sys.exit(0)
        except Exception as e:
            logger.error(f"Scan failed: {e}")
            sys.exit(1)

def create_sample_template_file(filename: str) -> None:
    """Create a sample YAML template file."""
    try:
        sample_template = {
            'templates': [
                {
                    'id': 'xss-001',
                    'info': {
                        'name': 'Reflected XSS',
                        'severity': 'high',
                        'description': 'Checks for reflected XSS via query parameter.'
                    },
                    'requests': [
                        {
                            'method': 'GET',
                            'path': '/search?q={{payload}}',
                            'payloads': {
                                'payload': '<script>alert("test")</script>'
                            },
                            'matchers': [
                                {
                                    'type': 'regex',
                                    'condition': 'and',
                                    'regex': [r'<script>alert\(.*?\)</script>']
                                }
                            ]
                        }
                    ]
                },
                {
                    'id': 'open-redirect-001',
                    'info': {
                        'name': 'Open Redirect',
                        'severity': 'medium',
                        'description': 'Checks for open redirect vulnerabilities.'
                    },
                    'requests': [
                        {
                            'method': 'GET',
                            'path': '/redirect?url={{payload}}',
                            'payloads': {
                                'payload': 'https://evil.com'
                            },
                            'matchers': [
                                {
                                    'type': 'regex',
                                    'condition': 'and',
                                    'regex': [r'https://evil\.com']
                                }
                            ]
                        }
                    ]
                },
                {
                    'id': 'rce-001',
                    'info': {
                        'name': 'Remote Code Execution',
                        'severity': 'critical',
                        'description': 'Checks for RCE via command injection.'
                    },
                    'requests': [
                        {
                            'method': 'GET',
                            'path': '/admin?cmd={{payload}}',
                            'payloads': {
                                'payload': 'id;whoami'
                            },
                            'matchers': [
                                {
                                    'type': 'regex',
                                    'condition': 'and',
                                    'regex': [r'uid=\d+\(.*?\) gid=\d+\(.*?\)']
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        with open(filename, 'w') as f:
            yaml.safe_dump(sample_template, f)
        console.print(f"[green]Created sample template file: {filename}[/green]")
    except Exception as e:
        logger.error(f"Failed to create sample template file: {e}")
        sys.exit(1)

def create_sample_targets_file(filename: str) -> None:
    """Create a sample targets file."""
    try:
        sample_targets = [
            'http://example.com',
            'http://test.com',
            'http://vulnerable.app',
            'http://demo.testfire.net'
        ]
        with open(filename, 'w') as f:
            f.write('\n'.join(sample_targets))
        console.print(f"[green]Created sample targets file: {filename}[/green]")
    except Exception as e:
        logger.error(f"Failed to create sample targets file: {e}")
        sys.exit(1)

def create_sample_config_file(filename: str) -> None:
    """Create a sample config file."""
    try:
        sample_config = {
            'retry_attempts': 3,
            'rate_limit': 5,
            'global_rate_limit': 100,
            'batch_size': 1000,
            'timeout': 10,
            'nvd_api_key': 'YOUR_NVD_API_KEY'
        }
        with open(filename, 'w') as f:
            yaml.safe_dump(sample_config, f)
        console.print(f"[green]Created sample config file: {filename}[/green]")
    except Exception as e:
        logger.error(f"Failed to create sample config file: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="VulnForge: Optimized vulnerability scanner")
    parser.add_argument('-t', '--templates', default='templates.yaml', help='Path to templates file')
    parser.add_argument('-i', '--input', default='targets.txt', help='Path to targets file')
    parser.add_argument('-o', '--output', default='results.json', help='Path to output file')
    parser.add_argument('-c', '--config', default='config.yaml', help='Path to config file')
    parser.add_argument('--concurrency', type=int, help='Number of concurrent scans (default: auto)')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--create-samples', action='store_true', help='Create sample files')
    args = parser.parse_args()

    if args.create_samples:
        create_sample_template_file('templates.yaml')
        create_sample_targets_file('targets.txt')
        create_sample_config_file('config.yaml')
        console.print("[cyan]Sample files created. Run: python vulnforge.py -t templates.yaml -i targets.txt -o results.json[/cyan]")
        return

    scanner = VulnForge(
        templates=args.templates,
        targets=args.input,
        output=args.output,
        config=args.config,
        concurrency=args.concurrency,
        verbose=args.verbose
    )
    scanner.run()

if __name__ == '__main__':
    main()
