#!/usr/bin/env python3

import argparse
import yaml
import json
import re
import asyncio
import aiohttp
import os
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging
from rich.console import Console
from rich.progress import Progress
import sys
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from functools import lru_cache
from aiohttp import ClientSession, ClientTimeout

# Configure logging and rich console
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
console = Console()

class TemplateGenerator:
    """Generates vulnerability scanning templates from CVE data."""

    def __init__(
        self,
        output: str,
        config: str,
        cve_ids: Optional[List[str]] = None,
        verbose: bool = False
    ):
        """Initialize TemplateGenerator with optimized settings."""
        self.output_file = output
        self.config_file = config
        self.cve_ids = cve_ids if cve_ids else []
        self.verbose = verbose
        self.templates: List[Dict[str, Any]] = []
        self.config = self.load_config()
        self.start_time = time.time()
        self.api_call_count = 0
        self.api_failures = 0
        self.template_configs = self.load_template_configs()
        self.mock_data = self.load_mock_data()

    def load_config(self) -> Dict[str, Any]:
        """Load and validate configuration."""
        defaults = {
            'nvd_api_key': os.getenv('NVD_API_KEY', None),
            'api_timeout': int(os.getenv('VF_API_TIMEOUT', 10)),
            'retry_attempts': int(os.getenv('VF_RETRY_ATTEMPTS', 3)),
            'rate_limit': int(os.getenv('VF_RATE_LIMIT', 5)),
            'log_level': os.getenv('VF_LOG_LEVEL', 'INFO'),
            'mock_data_file': os.getenv('VF_MOCK_DATA_FILE', 'mock_cve_data.yaml'),
            'template_config_file': os.getenv('VF_TEMPLATE_CONFIG_FILE', 'template_configs.yaml')
        }
        try:
            if not os.path.exists(self.config_file):
                logger.warning(f"Config file {self.config_file} not found. Using defaults.")
                return defaults
            with open(self.config_file, 'r') as f:
                config = yaml.safe_load(f) or {}
            defaults.update(config)
            # Validate config
            if defaults['api_timeout'] <= 0:
                raise ValueError("API timeout must be positive")
            if defaults['retry_attempts'] < 0:
                raise ValueError("Retry attempts must be non-negative")
            if defaults['rate_limit'] <= 0:
                raise ValueError("Rate limit must be positive")
            # Set log level
            logging.getLogger().setLevel(getattr(logging, defaults['log_level'].upper(), logging.INFO))
            return defaults
        except (yaml.YAMLError, ValueError) as e:
            logger.error(f"Invalid config in {self.config_file}: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            sys.exit(1)

    def load_mock_data(self) -> Dict[str, Any]:
        """Load mock CVE data from file or use defaults."""
        mock_file = self.config.get('mock_data_file', 'mock_cve_data.yaml')
        default_mock_data = {
            'CVE-2023-1234': {
                'description': 'Cross-site scripting (XSS) vulnerability in user input field.',
                'cvss_score': 6.1,
                'published_date': '2023-01-15',
                'references': ['https://example.com/advisory'],
                'vulnerability_type': 'XSS'
            },
            'CVE-2023-5678': {
                'description': 'Open redirect vulnerability in login page.',
                'cvss_score': 5.4,
                'published_date': '2023-02-20',
                'references': ['https://example.com/advisory2'],
                'vulnerability_type': 'Open Redirect'
            },
            'CVE-2023-9012': {
                'description': 'SQL injection vulnerability in search endpoint.',
                'cvss_score': 7.5,
                'published_date': '2023-03-10',
                'references': ['https://example.com/advisory3'],
                'vulnerability_type': 'SQL Injection'
            },
            'CVE-2023-3456': {
                'description': 'Remote code execution in admin panel.',
                'cvss_score': 8.8,
                'published_date': '2023-04-05',
                'references': ['https://example.com/advisory4'],
                'vulnerability_type': 'RCE'
            },
            'CVE-2023-7890': {
                'description': 'Server-side request forgery in API endpoint.',
                'cvss_score': 7.2,
                'published_date': '2023-05-01',
                'references': ['https://example.com/advisory5'],
                'vulnerability_type': 'SSRF'
            }
        }
        try:
            if os.path.exists(mock_file):
                with open(mock_file, 'r') as f:
                    mock_data = yaml.safe_load(f) or {}
                console.print(f"[green]Loaded mock data from {mock_file}[/green]")
                return mock_data
            return default_mock_data
        except Exception as e:
            logger.warning(f"Failed to load mock data from {mock_file}: {e}. Using defaults.")
            return default_mock_data

    def load_template_configs(self) -> Dict[str, Any]:
        """Load template configurations."""
        template_file = self.config.get('template_config_file', 'template_configs.yaml')
        default_configs = {
            'xss': {
                'name': '{cve_id} Cross-Site Scripting',
                'payloads': ['<script>alert("vulnforge")</script>', '"><script>alert(1)</script>'],
                'path': '/search?q={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'<script>alert\(.*?\)</script>'],
                    'condition': 'or'
                }
            },
            'open redirect': {
                'name': '{cve_id} Open Redirect',
                'payloads': ['https://evil.com', '//evil.com'],
                'path': '/redirect?url={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'https?://evil\.com'],
                    'condition': 'or'
                }
            },
            'sql injection': {
                'name': '{cve_id} SQL Injection',
                'payloads': ["' OR '1'='1", "1' OR 1=1 --"],
                'path': '/search?q={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'(?i)error in your SQL syntax|mysql_fetch'],
                    'condition': 'or'
                }
            },
            'rce': {
                'name': '{cve_id} Remote Code Execution',
                'payloads': ['id;whoami', 'ping -c 1 127.0.0.1'],
                'path': '/admin?cmd={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'uid=\d+\(.*?\) gid=\d+\(.*?\)|PING'],
                    'condition': 'or'
                }
            },
            'ssrf': {
                'name': '{cve_id} Server-Side Request Forgery',
                'payloads': ['http://169.254.169.254/latest/meta-data/', 'http://localhost:8080'],
                'path': '/api/fetch?url={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'instance-id|ami-id'],
                    'condition': 'or'
                }
            }
        }
        try:
            if os.path.exists(template_file):
                with open(template_file, 'r') as f:
                    configs = yaml.safe_load(f) or {}
                console.print(f"[green]Loaded template configs from {template_file}[/green]")
                return configs
            return default_configs
        except Exception as e:
            logger.warning(f"Failed to load template configs from {template_file}: {e}. Using defaults.")
            return default_configs

    @lru_cache(maxsize=1000)
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError))
    )
    async def fetch_cve_data(self, cve_id: str, session: ClientSession) -> Optional[Dict[str, Any]]:
        """Fetch CVE data asynchronously with caching."""
        self.api_call_count += 1
        api_key = self.config.get('nvd_api_key')
        if api_key:
            try:
                url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?cveId={cve_id}"
                headers = {'apiKey': api_key}
                async with session.get(url, headers=headers) as response:
                    if response.status == 429:
                        logger.warning(f"Rate limit hit for {cve_id}. Pausing...")
                        await asyncio.sleep(5)
                        raise aiohttp.ClientError("Rate limit exceeded")
                    response.raise_for_status()
                    cve_item = (await response.json()).get('vulnerabilities', [{}])[0].get('cve', {})
                    return {
                        'description': cve_item.get('descriptions', [{}])[0].get('value', ''),
                        'cvss_score': cve_item.get('metrics', {}).get('cvssMetricV31', [{}])[0].get('cvssData', {}).get('baseScore', 0.0),
                        'published_date': cve_item.get('published', ''),
                        'references': [ref['url'] for ref in cve_item.get('references', [])],
                        'vulnerability_type': self.infer_vuln_type(cve_item.get('descriptions', [{}])[0].get('value', ''))
                    }
            except Exception as e:
                logger.warning(f"NVD API failed for {cve_id}: {e}. Falling back to mock data.")
                self.api_failures += 1

        return self.mock_data.get(cve_id, None)

    def infer_vuln_type(self, description: str) -> str:
        """Infer vulnerability type from description."""
        description = description.lower()
        if 'cross-site scripting' in description or 'xss' in description:
            return 'XSS'
        elif 'open redirect' in description:
            return 'Open Redirect'
        elif 'sql injection' in description:
            return 'SQL Injection'
        elif 'remote code execution' in description or 'rce' in description:
            return 'RCE'
        elif 'server-side request forgery' in description or 'ssrf' in description:
            return 'SSRF'
        return 'Unknown'

    def sanitize_payload(self, payload: str) -> str:
        """Sanitize payloads to prevent unsafe template generation."""
        dangerous_chars = {'<': '&lt;', '>': '&gt;', '&': '&amp;'}
        for char, escape in dangerous_chars.items():
            payload = payload.replace(char, escape)
        return payload

    def generate_template(self, cve_id: str, cve_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Generate a template with optimized matchers."""
        try:
            vuln_type = cve_data['vulnerability_type'].lower()
            description = cve_data['description']
            severity = self.map_cvss_to_severity(cve_data['cvss_score'])

            config = self.template_configs.get(vuln_type, None)
            if not config:
                logger.warning(f"Unsupported vulnerability type: {vuln_type}")
                return None

            # Sanitize payloads
            sanitized_payloads = [self.sanitize_payload(p) for p in config['payloads']]

            template = {
                'id': f'dynamic-{cve_id.lower()}',
                'info': {
                    'name': config['name'].format(cve_id=cve_id),
                    'severity': severity,
                    'description': f"{description} (Generated from {cve_id})",
                    'references': cve_data['references'],
                    'tags': [vuln_type, cve_id]
                },
                'requests': [
                    {
                        'method': config['method'],
                        'path': config['path'],
                        'payloads': {f'payload_{i}': p for i, p in enumerate(sanitized_payloads)},
                        'matchers': [
                            {
                                **config['matcher'],
                                'compiled_regex': [re.compile(r, re.IGNORECASE) for r in config['matcher']['regex']]
                            }
                        ]
                    }
                ]
            }
            if self.verbose:
                console.print(f"[cyan]Debug: Generated template for {cve_id} (Type: {vuln_type})[/cyan]")
            return template
        except Exception as e:
            logger.error(f"Failed to generate template for {cve_id}: {e}")
            return None

    def map_cvss_to_severity(self, cvss_score: float) -> str:
        """Map CVSS score to severity level."""
        try:
            cvss_score = float(cvss_score)
            if cvss_score >= 9.0:
                return 'critical'
            elif cvss_score >= 7.0:
                return 'high'
            elif cvss_score >= 4.0:
                return 'medium'
            else:
                return 'low'
        except (TypeError, ValueError):
            logger.warning("Invalid CVSS score. Defaulting to low severity.")
            return 'low'

    async def fetch_all_cve_data(self, cve_ids: List[str]) -> List[Dict[str, Any]]:
        """Fetch CVE data for all IDs concurrently."""
        async with ClientSession(timeout=ClientTimeout(total=self.config['api_timeout'])) as session:
            rate_limiter = asyncio.Semaphore(self.config['rate_limit'])
            async def fetch_with_limit(cve_id: str) -> Dict[str, Any]:
                async with rate_limiter:
                    data37 = await self.fetch_cve_data(cve_id, session)
                    return {'cve_id': cve_id, 'data': data}
            tasks = [fetch_with_limit(cve_id) for cve_id in cve_ids]
            return await asyncio.gather(*tasks, return_exceptions=True)

    def generate_templates(self) -> None:
        """Generate templates with batch processing and progress tracking."""
        try:
            if not self.cve_ids:
                self.cve_ids = list(self.mock_data.keys())
                console.print("[yellow]No CVE IDs provided, using default CVEs[/yellow]")
            
            # Validate CVE IDs
            valid_cve_ids = []
            cve_pattern = re.compile(r'^CVE-\d{4}-\d{4,}$')
            for cve_id in self.cve_ids:
                if cve_pattern.match(cve_id):
                    valid_cve_ids.append(cve_id)
                else:
                    logger.warning(f"Invalid CVE ID format: {cve_id}")

            if not valid_cve_ids:
                raise ValueError("No valid CVE IDs provided")

            # Fetch CVE data concurrently
            with Progress(console=console) as progress:
                task_id = progress.add_task("[cyan]Fetching CVE data...", total=len(valid_cve_ids))
                loop = asyncio.get_event_loop()
                cve_data_list = loop.run_until_complete(self.fetch_all_cve_data(valid_cve_ids))
                progress.update(task_id, completed=len(valid_cve_ids))

            # Generate templates
            with Progress(console=console) as progress:
                task_id = progress.add_task("[cyan]Generating templates...", total=len(cve_data_list))
                for item in cve_data_list:
                    if isinstance(item, dict) and item['data']:
                        template = self.generate_template(item['cve_id'], item['data'])
                        if template:
                            self.templates.append(template)
                            console.print(f"[green]Generated template for {item['cve_id']}[/green]")
                    progress.advance(task_id)
        except Exception as e:
            logger.error(f"Template generation failed: {e}")
            sys.exit(1)

    def save_templates(self) -> None:
        """Save templates with error handling."""
        try:
            if not self.templates:
                raise ValueError("No templates to save")
            os.makedirs(os.path.dirname(self.output_file) or '.', exist_ok=True)
            # Check if output file is writable
            test_file = os.path.join(os.path.dirname(self.output_file) or '.', '.test_write')
            with open(test_file, 'w') as f:
                f.write('')
            os.remove(test_file)
            output_data = {'templates': self.templates}
            with open(self.output_file, 'w') as f:
                yaml.safe_dump(output_data, f, default_flow_style=False, sort_keys=False)
            console.print(f"[green]Saved {len(self.templates)} templates to {self.output_file}[/green]")
        except Exception as e:
            logger.error(f"Failed to save templates: {e}")
            sys.exit(1)

    def log_performance_metrics(self) -> None:
        """Log detailed performance metrics."""
        duration = time.time() - self.start_time
        console.print(f"[cyan]Template Generation Metrics:[/cyan]")
        console.print(f"[cyan]  Duration: {duration:.2f} seconds[/cyan]")
        console.print(f"[cyan]  Templates Generated: {len(self.templates)}[/cyan]")
        console.print(f"[cyan]  API Calls Made: {self.api_call_count}[/cyan]")
        console.print(f"[cyan]  API Failures: {self.api_failures}[/息

        console.print(f"[cyan]  API Failure Rate: {(self.api_failures / self.api_call_count * 100):.2f}%[/cyan]" if self.api_call_count > 0 else "[cyan]  API Failure Rate: 0.00%[/cyan]")

    def run(self) -> None:
        """Run the template generation process."""
        try:
            self.generate_templates()
            self.save_templates()
            self.log_performance_metrics()
        except KeyboardInterrupt:
            console.print("[yellow]Template generation interrupted.[/yellow]")
            sys.exit(0)
        except Exception as e:
            logger.error(f"Template generation failed: {e}")
            sys.exit(1)

def create_sample_config_file(filename: str) -> None:
    """Create a sample config file."""
    try:
        sample_config = {
            'nvd_api_key': 'YOUR_NVD_API_KEY',
            'api_timeout': 10,
            'retry_attempts': 3,
            'rate_limit': 5,
            'log_level': 'INFO',
            'mock_data_file': 'mock_cve_data.yaml',
            'template_config_file': 'template_configs.yaml'
        }
        with open(filename, 'w') as f:
            yaml.safe_dump(sample_config, f)
        console.print(f"[green]Created sample config file: {filename}[/green]")
    except Exception as e:
        logger.error(f"Failed to create sample config file: {e}")
        sys.exit(1)

def create_sample_mock_data_file(filename: str) -> None:
    """Create a sample mock CVE data file."""
    try:
        mock_data = {
            'CVE-2023-1234': {
                'description': 'Cross-site scripting (XSS) vulnerability in user input field.',
                'cvss_score': 6.1,
                'published_date': '2023-01-15',
                'references': ['https://example.com/advisory'],
                'vulnerability_type': 'XSS'
            },
            'CVE-2023-5678': {
                'description': 'Open redirect vulnerability in login page.',
                'cvss_score': 5.4,
                'published_date': '2023-02-20',
                'references': ['https://example.com/advisory2'],
                'vulnerability_type': 'Open Redirect'
            }
        }
        with open(filename, 'w') as f:
            yaml.safe_dump(mock_data, f)
        console.print(f"[green]Created sample mock data file: {filename}[/green]")
    except Exception as e:
        logger.error(f"Failed to create sample mock data file: {e}")
        sys.exit(1)

def create_sample_template_config_file(filename: str) -> None:
    """Create a sample template config file."""
    try:
        template_configs = {
            'xss': {
                'name': '{cve_id} Cross-Site Scripting',
                'payloads': ['<script>alert("vulnforge")</script>', '"><script>alert(1)</script>'],
                'path': '/search?q={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'<script>alert\(.*?\)</script>'],
                    'condition': 'or'
                }
            },
            'open redirect': {
                'name': '{cve_id} Open Redirect',
                'payloads': ['https://evil.com', '//evil.com'],
                'path': '/redirect?url={{payload}}',
                'method': 'GET',
                'matcher': {
                    'type': 'regex',
                    'regex': [r'https?://evil\.com'],
                    'condition': 'or'
                }
            }
        }
        with open(filename, 'w') as f:
            yaml.safe_dump(template_configs, f)
        console.print(f"[green]Created sample template config file: {filename}[/green]")
    except Exception as e:
        logger.error(f"Failed to create sample template config file: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="VulnForge Template Generator")
    parser.add_argument('-o', '--output', default='templates.yaml', help='Output YAML file for templates')
    parser.add_argument('-c', '--config', default='config.yaml', help='Path to config file')
    parser.add_argument('-cve', '--cves', nargs='*', help='List of CVE IDs to generate templates for')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--create-samples', action='store_true', help='Create sample config and mock data files')
    args = parser.parse_args()

    if args.create_samples:
        create_sample_config_file('config.yaml')
        create_sample_mock_data_file('mock_cve_data.yaml')
        create_sample_template_config_file('template_configs.yaml')
        console.print("[cyan]Sample files created. Run: python template_generator.py -o templates.yaml -c config.yaml -cve CVE-2023-1234[/cyan]")
        return

    generator = TemplateGenerator(args.output, args.config, args.cves, args.verbose)
    generator.run()

if __name__ == '__main__':
    main()
