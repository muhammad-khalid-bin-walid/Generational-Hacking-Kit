#!/bin/bash

# Installation script for best_sub_domain_hunt.sh dependencies
# Includes new tools: dnsenum, cloudscraper, shosubgo, cero, paramspider, nuclei

# Exit on any error
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local color
    case $level in
        "INFO") color="$GREEN" ;;
        "WARNING") color="$YELLOW" ;;
        "ERROR") color="$RED" ;;
        *) color="$NC" ;;
    esac
    echo -e "${color}[$timestamp] [$level] $message${NC}" | tee -a install.log
}

# Check for sudo privileges
if [[ $EUID -ne 0 && ! $(groups | grep -w sudo) ]]; then
    log "ERROR" "This script requires sudo privileges. Please run with sudo or as root."
    exit 1
fi

# Initialize log file
log_file="install.log"
touch "$log_file"
log "INFO" "Starting installation of best_sub_domain_hunt.sh dependencies..."

# Check for package manager
if ! command -v apt &>/dev/null; then
    log "ERROR" "This script requires apt (Ubuntu/Debian/Kali). Other systems are not supported."
    exit 1
fi

# Clean up problematic repositories
clean_repositories() {
    log "INFO" "Checking for problematic APT repositories..."
    local problematic_repos=("insomnia" "konghq")
    for repo in "${problematic_repos[@]}"; do
        if ls /etc/apt/sources.list.d/*"$repo"*.list &>/dev/null; then
            log "WARNING" "Found problematic repository containing '$repo'. Removing..."
            sudo rm -f /etc/apt/sources.list.d/*"$repo"*.list || {
                log "ERROR" "Failed to remove problematic repository files."
                exit 1
            }
        fi
        if grep -i "$repo" /etc/apt/sources.list &>/dev/null; then
            log "WARNING" "Found problematic repository in /etc/apt/sources.list. Removing..."
            sudo sed -i "/$repo/d" /etc/apt/sources.list || {
                log "ERROR" "Failed to clean /etc/apt/sources.list."
                exit 1
            }
        fi
    done
}

# Attempt apt update with retries
update_apt() {
    local retries=3
    local attempt=1
    while [[ $attempt -le $retries ]]; do
        log "INFO" "Running apt update (attempt $attempt/$retries)..."
        if sudo apt update; then
            return 0
        else
            log "WARNING" "apt update failed. Retrying in 5 seconds..."
            sleep 5
            ((attempt++))
        fi
    done
    log "ERROR" "apt update failed after $retries attempts. Check network or repository configuration."
    exit 1
}

# Clean repositories and update APT
clean_repositories
sudo apt clean
update_apt

# Install prerequisites
log "INFO" "Installing prerequisites..."
sudo apt install -y git curl wget python3 python3-pip golang-go jq make seclists || {
    log "ERROR" "Failed to install prerequisites. Check install.log and APT configuration."
    exit 1
}

# Ensure wordlist exists
wordlist="/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-5000.txt"
if [[ ! -f "$wordlist" ]]; then
    log "INFO" "Downloading SecLists wordlist..."
    sudo mkdir -p /usr/share/wordlists/seclists/Discovery/DNS
    sudo wget -O "$wordlist" https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-5000.txt || {
        log "ERROR" "Failed to download SecLists wordlist."
        exit 1
    }
fi

# Ensure resolver file exists
resolvers="/etc/resolv.conf"
if [[ ! -f "$resolvers" ]]; then
    log "INFO" "Creating default resolver file..."
    sudo bash -c 'echo "nameserver 8.8.8.8" > /etc/resolv.conf' || {
        log "ERROR" "Failed to create /etc/resolv.conf."
        exit 1
    }
fi

# Install optional tools
log "INFO" "Installing optional tools (pv, parallel)..."
sudo apt install -y pv parallel || log "WARNING" "Failed to install optional tools (pv, parallel). Continuing without them."

# Function to check if a tool is installed
check_tool() {
    local tool=$1
    if command -v "$tool" &>/dev/null; then
        log "INFO" "$tool is already installed."
        return 0
    else
        return 1
    fi
}

# Function to install Go-based tools
install_go_tool() {
    local tool=$1
    local repo=$2
    local binary=$3
    if ! check_tool "$binary"; then
        log "INFO" "Installing $tool..."
        go install -v "$repo@latest" || {
            log "ERROR" "Failed to install $tool. Ensure Go is configured correctly."
            return 1
        }
        sudo cp ~/go/bin/"$binary" /usr/local/bin/ || {
            log "ERROR" "Failed to move $binary to /usr/local/bin."
            return 1
        }
    fi
}

# Function to install Python-based tools
install_python_tool() {
    local tool=$1
    local repo=$2
    local binary=$3
    if ! check_tool "$binary"; then
        log "INFO" "Installing $tool..."
        git clone "$repo" || {
            log "ERROR" "Failed to clone $tool repository."
            return 1
        }
        cd "$(basename "$repo" .git)"
        sudo pip3 install -r requirements.txt || {
            log "ERROR" "Failed to install $tool dependencies."
            cd ..
            return 1
        }
        sudo ln -s "$(pwd)/$binary" /usr/local/bin/"$binary" || {
            log "ERROR" "Failed to link $binary to /usr/local/bin."
            cd ..
            return 1
        }
        cd ..
    fi
}

# Install required tools
log "INFO" "Installing required tools..."

# 1. subfinder
install_go_tool "subfinder" "github.com/projectdiscovery/subfinder/v2/cmd/subfinder" "subfinder"

# 2. assetfinder
install_go_tool "assetfinder" "github.com/tomnomnom/assetfinder" "assetfinder"

# 3. amass
install_go_tool "amass" "github.com/OWASP/Amass/v3/..." "amass"

# 4. findomain
if ! check_tool "findomain"; then
    log "INFO" "Installing findomain..."
    wget https://github.com/Findomain/Findomain/releases/latest/download/findomain-linux || {
        log "ERROR" "Failed to download findomain."
        exit 1
    }
    chmod +x findomain-linux
    sudo mv findomain-linux /usr/local/bin/findomain || {
        log "ERROR" "Failed to move findomain to /usr/local/bin."
        exit 1
    }
fi

# 5. dnsx
install_go_tool "dnsx" "github.com/projectdiscovery/dnsx/cmd/dnsx" "dnsx"

# 6. sublist3r
install_python_tool "sublist3r" "https://github.com/aboul3la/Sublist3r.git" "sublist3r.py"

# 7. katana
install_go_tool "katana" "github.com/projectdiscovery/katana/cmd/katana" "katana"

# 8. chaos
install_go_tool "chaos" "github.com/projectdiscovery/chaos-client/cmd/chaos" "chaos"

# 9. dnsgen
install_python_tool "dnsgen" "https://github.com/ProjectAnte/dnsgen.git" "dnsgen.py"

# 10. gobuster
install_go_tool "gobuster" "github.com/OJ/gobuster/v3" "gobuster"

# 11. shuffledns
install_go_tool "shuffledns" "github.com/projectdiscovery/shuffledns/cmd/shuffledns" "shuffledns"

# 12. httpx
install_go_tool "httpx" "github.com/projectdiscovery/httpx/cmd/httpx" "httpx"

# 13. dnmasscan
if ! check_tool "dnmasscan"; then
    log "INFO" "Installing dnmasscan..."
    git clone https://github.com/projectdiscovery/dnmasscan.git || {
        log "ERROR" "Failed to clone dnmasscan repository."
        exit 1
    }
    cd dnmasscan
    make || {
        log "ERROR" "Failed to build dnmasscan."
        cd ..
        exit 1
    }
    sudo mv dnmasscan /usr/local/bin/ || {
        log "ERROR" "Failed to move dnmasscan to /usr/local/bin."
        cd ..
        exit 1
    }
    cd ..
fi

# 14. waymore
install_python_tool "waymore" "https://github.com/xnl-h4ck3r/waymore.git" "waymore.py"

# 15. arjun
install_python_tool "arjun" "https://github.com/s0md3v/Arjun.git" "arjun.py"

# 16. gf
if ! check_tool "gf"; then
    log "INFO" "Installing gf..."
    install_go_tool "gf" "github.com/tomnomnom/gf" "gf"
    log "INFO" "Installing gf patterns..."
    git clone https://github.com/1ndianl33t/Gf-Patterns.git ~/.gf || {
        log "ERROR" "Failed to install gf patterns."
        exit 1
    }
fi

# 17. jq
if ! check_tool "jq"; then
    log "INFO" "Installing jq..."
    sudo apt install -y jq || {
        log "ERROR" "Failed to install jq."
        exit 1
    }
fi

# 18. curl
if ! check_tool "curl"; then
    log "INFO" "Installing curl..."
    sudo apt install -y curl || {
        log "ERROR" "Failed to install curl."
        exit 1
    }
fi

# 19. haktrails
install_go_tool "haktrails" "github.com/hakluke/haktrails" "haktrails"

# 20. bbq
install_go_tool "bbq" "github.com/projectdiscovery/bbq" "bbq"

# 21. hakkrawler
install_go_tool "hakkrawler" "github.com/hakluke/hakkrawler" "hakkrawler"

# 22. spiderfoot
install_python_tool "spiderfoot" "https://github.com/smicallef/spiderfoot.git" "sf.py"

# 23. gospider
install_go_tool "gospider" "github.com/jaeles-project/gospider" "gospider"

# 24. theHarvester
install_python_tool "theHarvester" "https://github.com/laramies/theHarvester.git" "theHarvester.py"

# 25. dnsrecon
if ! check_tool "dnsrecon"; then
    log "INFO" "Installing dnsrecon..."
    sudo apt install -y dnsrecon || {
        log "INFO" "Falling back to dnsrecon manual installation..."
        install_python_tool "dnsrecon" "https://github.com/darkoperator/dnsrecon.git" "dnsrecon.py"
    }
fi

# 26. altdns
install_python_tool "altdns" "https://github.com/infosec-au/altdns.git" "altdns.py"

# 27. massdns
if ! check_tool "massdns"; then
    log "INFO" "Installing massdns..."
    git clone https://github.com/blechschmidt/massdns.git || {
        log "ERROR" "Failed to clone massdns repository."
        exit 1
    }
    cd massdns
    make || {
        log "ERROR" "Failed to build massdns."
        cd ..
        exit 1
    }
    sudo mv bin/massdns /usr/local/bin/ || {
        log "ERROR" "Failed to move massdns to /usr/local/bin."
        cd ..
        exit 1
    }
    cd ..
fi

# 28. dnsvalidator
install_python_tool "dnsvalidator" "https://github.com/vortexau/dnsvalidator.git" "dnsvalidator.py"

# New tools
# 29. dnsenum
if ! check_tool "dnsenum"; then
    log "INFO" "Installing dnsenum..."
    sudo apt install -y dnsenum || {
        log "INFO" "Falling back to dnsenum manual installation..."
        git clone https://github.com/fwaeytens/dnsenum.git || {
            log "ERROR" "Failed to clone dnsenum repository."
            exit 1
        }
        cd dnsenum
        chmod +x dnsenum.pl
        sudo ln -s "$(pwd)/dnsenum.pl" /usr/local/bin/dnsenum || {
            log "ERROR" "Failed to link dnsenum to /usr/local/bin."
            cd ..
            exit 1
        }
        cd ..
    }
fi

# 30. cloudscraper
install_python_tool "cloudscraper" "https://github.com/harishsg99/cloudscraper.git" "cloudscraper.py"

# 31. shosubgo
install_go_tool "shosubgo" "github.com/incogbyte/shosubgo" "shosubgo"

# 32. cero
install_go_tool "cero" "github.com/glebarez/cero" "cero"

# 33. paramspider
install_python_tool "paramspider" "https://github.com/devanshbatham/ParamSpider.git" "paramspider.py"

# 34. nuclei
install_go_tool "nuclei" "github.com/projectdiscovery/nuclei/v2/cmd/nuclei" "nuclei"

# Verify installations
log "INFO" "Verifying tool installations..."
failed_tools=0
for tool in subfinder assetfinder amass findomain dnsx sublist3r katana chaos dnsgen gobuster shuffledns httpx dnmasscan waymore arjun gf jq curl haktrails bbq hakkrawler spiderfoot gospider theHarvester dnsrecon altdns massdns dnsvalidator dnsenum cloudscraper shosubgo cero paramspider nuclei; do
    if command -v "$tool" &>/dev/null; then
        log "INFO" "$tool is installed and accessible."
    else
        log "ERROR" "$tool is not installed or not in PATH."
        ((failed_tools++))
    fi
done

# Check for failed installations
if [[ $failed_tools -gt 0 ]]; then
    log "ERROR" "$failed_tools tool(s) failed to install. Check install.log for details."
    exit 1
else
    log "INFO" "All tools installed successfully."
fi

# Post-installation instructions
log "INFO" "Installation complete. Post-installation steps:"
echo -e "${GREEN}1. Configure API keys for tools like subfinder, amass, findomain, chaos, haktrails, theHarvester, and shosubgo for better results."
echo "   - Example for subfinder: echo 'securitytrails: YOUR_API_KEY' > ~/.config/subfinder/config.yaml"
echo "   - Example for shosubgo: export SHODAN_API_KEY='YOUR_API_KEY'"
echo "2. Test the best_sub_domain_hunt.sh script: chmod +x best_sub_domain_hunt.sh && ./best_sub_domain_hunt.sh"
echo "3. Check install.log for any warnings or errors."
echo "4. If issues persist, verify /etc/apt/sources.list and /etc/apt/sources.list.d/ for problematic repositories.${NC}"

log "INFO" "Installation completed successfully at $(date)."
