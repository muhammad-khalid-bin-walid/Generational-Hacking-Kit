#!/bin/bash

# Best Subdomain Hunt Script
# Optimized for speed, reliability, and comprehensive subdomain enumeration
# Includes 6 additional tools: dnsenum, cloudscraper, shosubgo, cero, paramspider, nuclei
# Skips missing tools, supports verbose mode and JSON output

# Exit on critical errors
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
max_jobs=6  # Max concurrent jobs
wordlist="/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-5000.txt"
resolvers="/etc/resolv.conf"
retries=2  # Number of retries for network-dependent tools
start_time=$(date +%s)
declare -a missing_tools  # Array to store missing tools
verbose=false  # Verbose mode flag
json_output=false  # JSON output flag
domain=""

# Logging function
log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local color
    case $level in
        "INFO") color="$GREEN" ;;
        "WARNING") color="$YELLOW" ;;
        "ERROR") color="$RED" ;;
        *) color="$NC" ;;
    esac
    if [[ "$verbose" == "true" || "$level" != "DEBUG" ]]; then
        echo -e "${color}[$timestamp] [$level] $message${NC}" | tee -a "$log_file"
    else
        echo "[$timestamp] [$level] $message" >> "$log_file"
    fi
}

# Usage function
usage() {
    echo "Usage: $0 [-d domain] [-v] [-j]"
    echo "  -d  Specify domain (e.g., example.com)"
    echo "  -v  Enable verbose mode"
    echo "  -j  Output results in JSON format"
    echo "If -d is not provided, you will be prompted for a domain."
    exit 1
}

# Parse command-line arguments
while getopts "d:vj" opt; do
    case $opt in
        d) domain="$OPTARG" ;;
        v) verbose=true ;;
        j) json_output=true ;;
        *) usage ;;
    esac
done

# Check for required tools and identify missing ones
check_tools() {
    local tools=("subfinder" "assetfinder" "amass" "findomain" "dnsx" "sublist3r" "katana" "chaos" "dnsgen" "gobuster" "shuffledns" "httpx" "dnmasscan" "waymore" "arjun" "gf" "jq" "curl" "haktrails" "bbq" "hakkrawler" "spiderfoot" "gospider" "theHarvester" "dnsrecon" "altdns" "massdns" "dnsvalidator" "dnsenum" "cloudscraper" "shosubgo" "cero" "paramspider" "nuclei")
    for tool in "${tools[@]}"; do
        if ! command -v "$tool" &>/dev/null; then
            log "WARNING" "$tool is not installed and will be skipped."
            missing_tools+=("$tool")
        fi
    done
    if [[ ! -f "$wordlist" ]]; then
        log "ERROR" "Wordlist not found at $wordlist."
        exit 1
    fi
    if [[ ! -f "$resolvers" ]]; then
        log "ERROR" "Resolver file not found at $resolvers."
        exit 1
    fi
    # Ensure critical tools are present
    for critical_tool in jq curl; do
        if [[ " ${missing_tools[*]} " =~ " $critical_tool " ]]; then
            log "ERROR" "$critical_tool is a critical dependency and must be installed."
            exit 1
        fi
    done
}

# Check if a tool should be skipped
should_skip_tool() {
    local tool=$1
    for missing_tool in "${missing_tools[@]}"; do
        if [[ "$missing_tool" == "$tool" ]]; then
            return 0
        fi
    done
    return 1
}

# Prompt for domain if not provided
if [[ -z "$domain" ]]; then
    echo "Enter Domain (e.g., example.com):"
    read -r domain
fi

# Validate and sanitize domain input
if [[ -z "$domain" || ! "$domain" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$ ]]; then
    log "ERROR" "Invalid or empty domain. Please enter a valid domain (e.g., example.com)."
    exit 1
fi
domain=$(echo "$domain" | tr '[:upper:]' '[:lower:]') # Normalize to lowercase

# Create a timestamped working directory
timestamp=$(date +%s)
workdir="subenum_$domain_$timestamp"
mkdir -p "$workdir"
cd "$workdir" || { log "ERROR" "Failed to create or access working directory."; exit 1; }

# Initialize log file
log_file="enum_$domain.log"
touch "$log_file"
log "INFO" "Starting subdomain enumeration for $domain..."

# Output files
output_file="subdomains.txt"
live_file="live_subdomains.txt"
temp_file="temp_subdomains.txt"
vuln_dir="vulnerabilities"
json_file="results_$domain.json"
mkdir -p "$vuln_dir"
touch "$temp_file"

# Function to append and filter results
append_results() {
    local tool_name=$1
    local input_file=$2
    if [[ -s "$input_file" ]]; then
        awk "/^[a-zA-Z0-9.-]+\.$domain$/" "$input_file" | sort -u >> "$temp_file"
        log "INFO" "$tool_name found $(wc -l < "$input_file") subdomains."
    else
        log "WARNING" "$tool_name found no subdomains or failed."
    fi
}

# Function to run a tool with retries and concurrency control
run_tool() {
    local tool_name=$1
    local command=$2
    local output_file=$3
    local tool_binary=${4:-$tool_name}  # Optional: specify binary if different from tool_name

    if should_skip_tool "$tool_binary"; then
        log "INFO" "Skipping $tool_name as it is not installed."
        return
    fi

    # Wait for available job slot
    while [[ $(jobs -r | wc -l) -ge $max_jobs ]]; do
        sleep 0.5
    done

    log "INFO" "Running $tool_name..."
    local attempt=1
    local max_attempts=$((retries + 1))
    while [[ $attempt -le $max_attempts ]]; do
        if command -v pv &>/dev/null; then
            if eval "$command" | pv -l -N "$tool_name" > "$output_file" 2>>"$log_file"; then
                return 0
            fi
        else
            if eval "$command" > "$output_file" 2>>"$log_file"; then
                return 0
            fi
        fi
        if [[ $attempt -lt $max_attempts ]]; then
            log "WARNING" "$tool_name failed, retrying ($attempt/$retries)..."
            sleep $((2 ** attempt))  # Exponential backoff
        fi
        ((attempt++))
    done
    log "WARNING" "$tool_name failed after $retries retries."
}

# Check for tools
check_tools

# Validate resolvers
if ! should_skip_tool "dnsvalidator"; then
    log "INFO" "Validating DNS resolvers..."
    run_tool "dnsvalidator" "dnsvalidator -tL \"$resolvers\" -o valid_resolvers.txt" "valid_resolvers.txt"
    if [[ -s valid_resolvers.txt ]]; then
        resolvers="valid_resolvers.txt"
        log "DEBUG" "Using validated resolvers: $(cat valid_resolvers.txt | head -n 3)"
    else
        log "WARNING" "No valid resolvers found, using $resolvers."
    fi
else
    log "INFO" "Skipping dnsvalidator as it is not installed."
fi

# Run subdomain enumeration tools (grouped by type)
echo "[*] Running subdomain enumeration tools..."

# Passive enumeration tools
run_tool "Subfinder" "subfinder -d \"$domain\" -o subfinder.txt -silent" "subfinder.txt"
run_tool "Assetfinder" "assetfinder --subs-only \"$domain\"" "assetfinder.txt"
run_tool "Findomain" "findomain -t \"$domain\" -q" "findomain.txt"
run_tool "crt.sh" "curl -s \"https://crt.sh/?q=%25.$domain&output=json\" | jq -r '.[].name_value' | awk \"/^[a-zA-Z0-9.-]+\\.$domain$/\"" "crtsh.txt"
run_tool "Haktrails" "haktrails subdomains -d \"$domain\" -o haktrails.txt" "haktrails.txt"
run_tool "dnsdumpster" "curl -s -X POST \"https://dnsdumpster.com/\" -d \"csrfmiddlewaretoken=\$(curl -s \"https://dnsdumpster.com/\" | grep csrfmiddlewaretoken | cut -d'\"' -f2)&targetip=$domain\" | awk \"/^[a-zA-Z0-9.-]+\\.$domain$/\"" "dnsdumpster.txt"
run_tool "theHarvester" "theHarvester -d \"$domain\" -b all -f theharvester.json" "theharvester.json"
run_tool "Cloudscraper" "cloudscraper -d \"$domain\" -o cloudscraper.txt" "cloudscraper.txt"
run_tool "Shosubgo" "shosubgo -d \"$domain\" -o shosubgo.txt" "shosubgo.txt"
run_tool "Cero" "cero \"$domain\" -o cero.txt" "cero.txt"

# Active enumeration tools
run_tool "Amass" "amass enum -d \"$domain\" -o amass.txt -silent" "amass.txt"
run_tool "dnsx" "dnsx -d \"$domain\" -silent -o dnsx.txt" "dnsx.txt"
run_tool "dnsrecon" "dnsrecon -d \"$domain\" -t brt -D \"$wordlist\" -f -j dnsrecon.json" "dnsrecon.json"
run_tool "massdns" "massdns -r \"$resolvers\" -w massdns.txt \"$wordlist\"" "massdns.txt"
run_tool "dnsenum" "dnsenum \"$domain\" --enum -f \"$wordlist\" -o dnsenum.txt" "dnsenum.txt"

# Crawler-based tools
run_tool "Katana" "katana -d \"$domain\" -silent -o katana.txt" "katana.txt"
run_tool "Hakkrawler" "hakkrawler -d \"$domain\" -subs -o hakkrawler.txt" "hakkrawler.txt"
run_tool "Gospider" "gospider -s \"https://$domain\" -o gospider_output -q" "gospider_output"

# Wait for parallel tasks
wait

# Process complex outputs in parallel
log "INFO" "Processing complex outputs..."
process_output() {
    local tool_name=$1
    local input_file=$2
    local command=$3
    local tool_binary=${4:-$tool_name}
    if should_skip_tool "$tool_binary"; then
        log "INFO" "Skipping $tool_name output processing as it is not installed."
        return
    fi
    if [[ -s "$input_file" ]]; then
        eval "$command" | awk "/^[a-zA-Z0-9.-]+\.$domain$/" > "${input_file%.*}.txt"
        append_results "$tool_name" "${input_file%.*}.txt"
    else
        log "WARNING" "$tool_name found no subdomains or failed."
    fi
}

# SpiderFoot (sequential due to resource intensity)
if ! should_skip_tool "spiderfoot"; then
    log "INFO" "Running SpiderFoot..."
    spiderfoot -m sfp_dnsresolve,sfp_spider -t "$domain" -o json -f > "spiderfoot.json" 2>>"$log_file" || log "WARNING" "SpiderFoot failed."
    process_output "SpiderFoot" "spiderfoot.json" "jq -r '.[] | select(.type==\"DNS_NAME\") | .data' spiderfoot.json" "spiderfoot" &
fi

# theHarvester
process_output "theHarvester" "theharvester.json" "jq -r '.hosts[]' theharvester.json" "theHarvester" &

# dnsrecon
process_output "dnsrecon" "dnsrecon.json" "jq -r '.[] | select(.type==\"A\") | .name' dnsrecon.json" "dnsrecon" &

# Gospider
if [[ -d "gospider_output" ]]; then
    find "gospider_output" -type f -exec cat {} \; | awk "/^[a-zA-Z0-9.-]+\.$domain$/" > "gospider.txt"
    append_results "Gospider" "gospider.txt"
else
    log "WARNING" "Gospider found no subdomains or failed."
fi

# Wait for output processing
wait

# Append initial results
append_results "Subfinder" "subfinder.txt"
append_results "Assetfinder" "assetfinder.txt"
append_results "Amass" "amass.txt"
append_results "Findomain" "findomain.txt"
append_results "crt.sh" "crtsh.txt"
append_results "dnsx" "dnsx.txt"
append_results "Katana" "katana.txt"
append_results "Haktrails" "haktrails.txt"
append_results "dnsdumpster" "dnsdumpster.txt"
append_results "massdns" "massdns.txt"
append_results "Hakkrawler" "hakkrawler.txt"
append_results "Cloudscraper" "cloudscraper.txt"
append_results "Shosubgo" "shosubgo.txt"
append_results "Cero" "cero.txt"
append_results "dnsenum" "dnsenum.txt"

# Permutation and brute-force tools
run_tool "dnsgen" "cat \"$temp_file\" | dnsgen -" "dnsgen.txt"
run_tool "altdns" "altdns -i \"$temp_file\" -o altdns.txt" "altdns.txt"
run_tool "Gobuster" "gobuster dns -d \"$domain\" -w \"$wordlist\" -q -o gobuster.txt" "gobuster.txt"
run_tool "Shuffledns" "shuffledns -d \"$domain\" -w \"$wordlist\" -r \"$resolvers\" -silent -o shuffledns.txt" "shuffledns"

# Wait for permutation tools
wait

# Append permutation results
append_results "dnsgen" "dnsgen.txt"
append_results "altdns" "altdns.txt"
append_results "Gobuster" "gobuster.txt"
append_results "Shuffledns" "shuffledns.txt"

# Deduplicate subdomains
log "INFO" "Deduplicating subdomains..."
if command -v parallel &>/dev/null; then
    sort -u "$temp_file" | parallel --pipe -N 10000 sort -u > "$output_file"
else
    sort -u "$temp_file" > "$output_file"
fi
log "INFO" "Found $(wc -l < "$output_file") unique subdomains."

# Probe live hosts
if ! should_skip_tool "httpx"; then
    log "INFO" "Running httpx to probe live hosts..."
    if command -v pv &>/dev/null; then
        httpx -l "$output_file" -title -status-code -follow -no-fallback -silent -o "$live_file" | pv -l -N "httpx" > /dev/null 2>>"$log_file" || log "WARNING" "httpx failed."
    else
        httpx -l "$output_file" -title -status-code -follow -no-fallback -silent -o "$live_file" 2>>"$log_file" || log "WARNING" "httpx failed."
    fi
    if [[ -s "$live_file" ]]; then
        log "INFO" "Found $(wc -l < "$live_file") live subdomains."
    else
        log "WARNING" "No live subdomains found by httpx."
    fi
else
    log "INFO" "Skipping httpx as it is not installed."
fi

# Port scanning
run_tool "dnmasscan" "dnmasscan -i \"$output_file\" -o dnmasscan.txt -p 80,443" "dnmasscan.txt"

# Crawl for URLs
run_tool "waymore" "waymore -i \"$domain\" -mode U -oU waymore_urls.txt" "waymore_urls.txt"
if [[ -s "waymore_urls.txt" ]]; then
    log "INFO" "waymore collected $(wc -l < "waymore_urls.txt") URLs."
else
    log "WARNING" "waymore found no URLs or failed."
fi

# Parameter discovery
if ! should_skip_tool "arjun"; then
    log "INFO" "Running Arjun for parameter discovery..."
    if [[ -s "$live_file" ]]; then
        cat "$live_file" | cut -d' ' -f1 | arjun -u - -o "$vuln_dir/arjun_params.json" --stable 2>>"$log_file" || log "WARNING" "Arjun failed."
        if [[ -s "$vuln_dir/arjun_params.json" ]]; then
            log "INFO" "Arjun found parameters. Results saved in $vuln_dir/arjun_params.json."
        else
            log "WARNING" "Arjun found no parameters or failed."
        fi
    else
        log "WARNING" "No live subdomains for Arjun to analyze."
    fi
else
    log "INFO" "Skipping Arjun as it is not installed."
fi

if ! should_skip_tool "paramspider"; then
    log "INFO" "Running ParamSpider for parameter discovery..."
    if [[ -s "$live_file" ]]; then
        paramspider -d "$domain" -o "$vuln_dir/paramspider.txt" 2>>"$log_file" || log "WARNING" "ParamSpider failed."
        if [[ -s "$vuln_dir/paramspider.txt" ]]; then
            log "INFO" "ParamSpider found parameters. Results saved in $vuln_dir/paramspider.txt."
        else
            log "WARNING" "ParamSpider found no parameters or failed."
        fi
    else
        log "WARNING" "No live subdomains for ParamSpider to analyze."
    fi
else
    log "INFO" "Skipping ParamSpider as it is not installed."
fi

# Vulnerability pattern matching
if ! should_skip_tool "gf"; then
    log "INFO" "Running gf for vulnerability patterns..."
    if [[ -s "waymore_urls.txt" ]]; then
        vulnerabilities=("xss" "lfi" "rfi" "sqli" "ssrf" "redirect")
        for vuln in "${vulnerabilities[@]}"; do
            cat "waymore_urls.txt" | gf "$vuln" > "$vuln_dir/gf_$vuln.txt" 2>>"$log_file" || log "WARNING" "gf $vuln failed."
            if [[ -s "$vuln_dir/gf_$vuln.txt" ]]; then
                log "INFO" "gf found potential $vuln patterns. Results saved in $vuln_dir/gf_$vuln.txt."
            else
                log "WARNING" "gf found no $vuln patterns."
            fi
        done
    else
        log "WARNING" "No URLs available for gf to analyze."
    fi
else
    log "INFO" "Skipping gf as it is not installed."
fi

# Automated vulnerability scanning
if ! should_skip_tool "nuclei"; then
    log "INFO" "Running Nuclei for vulnerability scanning..."
    if [[ -s "$live_file" ]]; then
        nuclei -l "$live_file" -t cves/ -t misconfiguration/ -silent -o "$vuln_dir/nuclei_vulns.txt" 2>>"$log_file" || log "WARNING" "Nuclei failed."
        if [[ -s "$vuln_dir/nuclei_vulns.txt" ]]; then
            log "INFO" "Nuclei found vulnerabilities. Results saved in $vuln_dir/nuclei_vulns.txt."
        else
            log "WARNING" "Nuclei found no vulnerabilities or failed."
        fi
    else
        log "WARNING" "No live subdomains for Nuclei to analyze."
    fi
else
    log "INFO" "Skipping Nuclei as it is not installed."
fi

# Generate JSON output if requested
if [[ "$json_output" == "true" ]]; then
    log "INFO" "Generating JSON output..."
    jq -n \
        --arg domain "$domain" \
        --arg runtime "$((end_time - start_time))" \
        --arg subdomains "$(wc -l < "$output_file")" \
        --arg live_subdomains "$(wc -l < "$live_file")" \
        --arg vuln_files "$(ls -1 "$vuln_dir" | wc -l)" \
        --arg skipped_tools "${missing_tools[*]}" \
        --argjson subdomains_list "$(jq -R -s -c 'split("\n") | map(select(. != ""))' "$output_file")" \
        --argjson live_subdomains_list "$(jq -R -s -c 'split("\n") | map(select(. != ""))' "$live_file")" \
        '{
            "domain": $domain,
            "runtime_seconds": $runtime,
            "total_subdomains": $subdomains,
            "total_live_subdomains": $live_subdomains,
            "vulnerability_files": $vuln_files,
            "skipped_tools": ($skipped_tools | split(" ")),
            "subdomains": $subdomains_list,
            "live_subdomains": $live_subdomains_list
        }' > "$json_file"
    log "INFO" "JSON results saved to $json_file"
fi

# Generate summary report
end_time=$(date +%s)
runtime=$((end_time - start_time))
log "INFO" "Generating summary report..."
summary_file="summary_$domain.txt"
{
    echo "Subdomain Enumeration Summary for $domain"
    echo "========================================"
    echo "Date: $(date)"
    echo "Runtime: $runtime seconds"
    echo "Total Unique Subdomains": $(wc -l < "$output_file")
    echo "Total Live Subdomains": $(wc -l < "$live_file")
    echo "Vulnerability Files": $(ls -1 "$vuln_dir" | wc -l)
    echo "Skipped Tools": ${missing_tools[*]:-None}"
    echo "Log File": "$log_file"
    if [[ "$json_output" == "true"]] ]; then
        echo "JSON Output": $json_file"
    fi
    echo "========================================"
} > "$summary_file"

# Cleanup temporary files
log "INFO" "Cleaning up temporary files..."
rm -f subfinder.txt assetfinder.txt amass.txt findomain.txt crtsh.txt dnsx.txt katana.txt haktrails.txt dnsdumpster.txt massdns.txt hakkrawler.txt spiderfoot.json spiderfoot.txt gospider.txt theharvester.json shosubgo.txt cloudscraper.txt cero.txt dnsenum.txt theharvester.txt dnsrecon.json dnsrecon.txt dnsgen.txt altdns.txt gobuster.txt shuffledns.txt dnmasscan.txt temp_subdomains.txt valid_resolvers.txt
rm -rf gospider_output

# Move results to parent directory and clean up
mv "$output_file" "$live_file" "$vuln_dir" "$log_file" "$summary_file" ../
[[ "$json_output" == "true" ]] && mv "$json_file" ../
cd ..
rm -rf "$workdir"

log "INFO" "Subdomain enumeration and vulnerability scanning completed in in $runtime seconds."
echo -e "${GREEN}[*] Results saved in $output_file", $live_file, $vuln_dir/, $log_file, and $summary_file${NC}"
[[ "$json_output" == "true" ]] && echo -e "${GREEN}[*] JSON results saved to to ${json_file}${NC}"
