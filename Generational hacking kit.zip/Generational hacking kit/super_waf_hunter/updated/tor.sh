#!/bin/bash

# Start Tor service
echo "[+] Starting Tor service..."
sudo systemctl start tor

# Wait for Tor to initialize
sleep 5

# Check if Tor is running
if pgrep -x "tor" > /dev/null; then
    echo "[+] Tor is running successfully!"
else
    echo "[!] Tor failed to start. Check logs."
    exit 1
fi

# Verify Tor connection
echo "[+] Checking Tor connection..."
curl --proxy socks5://127.0.0.1:9050 https://check.torproject.org

# Run browser through Tor
echo "[+] Launching browser with proxychains..."
proxychains firefox https://kikman.com

echo "[+] Done!"
