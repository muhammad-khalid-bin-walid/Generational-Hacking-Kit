def tamper(payload):
    """Inject null byte to bypass filters."""
    return payload + "%00"
