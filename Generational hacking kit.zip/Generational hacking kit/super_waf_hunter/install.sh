#!/bin/bash

# SuperWAFScanner Installation Script
# Tested on Ubuntu/Debian and macOS

set -e

echo "Starting SuperWAFScanner installation..."

# Check for supported OS
OS=$(uname -s)
if [[ "$OS" != "Linux" && "$OS" != "Darwin" ]]; then
    echo "Error: Unsupported operating system: $OS"
    exit 1
fi

# Check for sudo (required for Tor installation)
if ! command -v sudo &> /dev/null; then
    echo "Warning: sudo not found. Tor installation may fail if not run as root."
fi

# Install Python 3
if ! command -v python3 &> /dev/null; then
    echo "Installing Python 3..."
    if [[ "$OS" == "Linux" ]]; then
        sudo apt-get update
        sudo apt-get install -y python3 python3-pip
    elif [[ "$OS" == "Darwin" ]]; then
        brew install python3
    fi
else
    echo "Python 3 already installed."
fi

# Install Python dependencies
echo "Installing Python dependencies..."
pip3 install requests aiohttp stem psutil

# Optional Tor installation
read -p "Do you want to install and configure Tor? (y/n): " install_tor
if [[ "$install_tor" == "y" || "$install_tor" == "Y" ]]; then
    if [[ "$OS" == "Linux" ]]; then
        echo "Installing Tor..."
        sudo apt-get install -y tor
        sudo systemctl enable tor
        sudo systemctl start tor
    elif [[ "$OS" == "Darwin" ]]; then
        echo "Installing Tor..."
        brew install tor
        brew services start tor
    fi
    echo "Tor installed and started."
else
    echo "Skipping Tor installation."
fi

# Create directories for plugins and signatures
echo "Setting up directories..."
mkdir -p tamper_plugins signatures
touch signatures/custom_signatures.json
echo "{}" > signatures/custom_signatures.json
echo "Created tamper_plugins and signatures directories."

echo "Installation complete! You can now run SuperWAFScanner."
echo "Example: python3 super_waf_scanner.py -u http://example.com --tor --signatures signatures/custom_signatures.json"
