import aiohttp
import asyncio
import json
import argparse
import time
import random
import re
import os
import importlib.util
from urllib.parse import urlparse, quote
from stem import Signal
from stem.control import Controller
import psutil
import logging
import csv
import numpy as np
from tqdm import tqdm
from jinja2 import Environment, FileSystemLoader
import platform
from concurrent.futures import ThreadPoolExecutor
import validators

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# Comprehensive WAF signatures (same as previous version)
WAF_SIGNATURES = {
    "Cloudflare": {
        "headers": ["cf-ray", "server: cloudflare"],
        "status_codes": [403, 429],
        "patterns": [r"Cloudflare Ray ID", r"Access denied"]
    },
    "Imperva": {
        "headers": ["X-Iinfo"],
        "status_codes": [403, 502],
        "patterns": [r"Request unsuccessful. Incapsula"]
    },
    "AWS WAF": {
        "headers": ["x-amzn-waf-.*"],
        "status_codes": [403, 405],
        "patterns": [r"AWS WAF"]
    },
    "Akamai": {
        "headers": ["x-akamai-transformed", "server: AkamaiGHost"],
        "status_codes": [403],
        "patterns": [r"AkamaiGHost"]
    },
    "Fortinet FortiWeb": {
        "headers": ["x-fortinet-.*"],
        "status_codes": [403, 429],
        "patterns": [r"FortiWeb"]
    },
    "Barracuda": {
        "headers": ["barracuda_.*"],
        "status_codes": [403, 429],
        "patterns": [r"Barracuda"]
    },
    "Sucuri": {
        "headers": ["x-sucuri-id", "server: Sucuri/Cloudproxy"],
        "status_codes": [403],
        "patterns": [r"Sucuri/Cloudproxy"]
    },
    "AppTrana": {
        "headers": ["x-apptrana-.*"],
        "status_codes": [403, 429],
        "patterns": [r"AppTrana"]
    },
    "F5 Advanced WAF": {
        "headers": ["x-f5-.*"],
        "status_codes": [403, 429],
        "patterns": [r"F5 Big-IP"]
    },
    "Reblaze": {
        "headers": ["x-reblaze-.*"],
        "status_codes": [403],
        "patterns": [r"Reblaze"]
    },
    "Fastly": {
        "headers": ["x-fastly-.*"],
        "status_codes": [403, 429],
        "patterns": [r"Fastly"]
    },
    "Citrix AppFirewall": {
        "headers": ["ns_af"],
        "status_codes": [403],
        "patterns": [r"Citrix NetScaler"]
    },
    "Cloudbric": {
        "headers": ["x-cloudbric-.*"],
        "status_codes": [403],
        "patterns": [r"Cloudbric"]
    },
    "Myra Security": {
        "headers": ["x-myra-.*"],
        "status_codes": [403],
        "patterns": [r"Myra Security"]
    },
    "Radware Cloud WAF": {
        "headers": ["x-radware-.*"],
        "status_codes": [403],
        "patterns": [r"Radware"]
    },
    "Prophaze": {
        "headers": ["x-prophaze-.*"],
        "status_codes": [403],
        "patterns": [r"Prophaze"]
    },
    "Aikido Security": {
        "headers": ["x-aikido-.*"],
        "status_codes": [403],
        "patterns": [r"Aikido"]
    },
    "Signal Sciences": {
        "headers": ["x-signalsciences-.*"],
        "status_codes": [403],
        "patterns": [r"Signal Sciences"]
    },
    "Check Point CloudGuard": {
        "headers": ["x-checkpoint-.*"],
        "status_codes": [403],
        "patterns": [r"Check Point"]
    },
    "ModSecurity": {
        "headers": ["mod_security"],
        "status_codes": [403, 406],
        "patterns": [r"ModSecurity"]
    },
    "Coraza": {
        "headers": ["x-coraza-.*"],
        "status_codes": [403],
        "patterns": [r"Coraza"]
    },
    "SafeLine": {
        "headers": ["x-safeline-.*"],
        "status_codes": [403],
        "patterns": [r"SafeLine"]
    },
    "WebKnight": {
        "headers": ["x-webknight-.*"],
        "status_codes": [403],
        "patterns": [r"WebKnight"]
    },
    "Shadow Daemon": {
        "headers": ["x-shadowdaemon-.*"],
        "status_codes": [403],
        "patterns": [r"Shadow Daemon"]
    },
    "Vulture": {
        "headers": ["x-vulture-.*"],
        "status_codes": [403],
        "patterns": [r"Vulture"]
    },
    "IronBee": {
        "headers": ["x-ironbee-.*"],
        "status_codes": [403],
        "patterns": [r"IronBee"]
    },
    "open-appsec": {
        "headers": ["x-openappsec-.*"],
        "status_codes": [403],
        "patterns": [r"open-appsec"]
    }
}

# Built-in tamper scripts
def tamper_random_case(payload):
    """Randomly change case of characters in payload."""
    return ''.join(random.choice([c.upper(), c.lower()]) for c in payload)

def tamper_url_encode(payload):
    """URL encode the payload."""
    return quote(payload)

def tamper_double_encode(payload):
    """Double URL encode the payload."""
    return quote(quote(payload))

def tamper_comment_injection(payload):
    """Inject SQL comments to bypass filters."""
    return payload.replace(" ", "/**/")

def tamper_whitespace(payload):
    """Add random whitespace to payload."""
    return payload.replace(" ", "%20" + " " * random.randint(1, 3))

TAMPER_SCRIPTS = {
    "random_case": tamper_random_case,
    "url_encode": tamper_url_encode,
    "double_encode": tamper_double_encode,
    "comment_injection": tamper_comment_injection,
    "whitespace": tamper_whitespace
}

# Sample CVE database (simulated)
CVE_DATABASE = {
    "Cloudflare": ["CVE-2023-12345: Cloudflare bypass via misconfigured rules"],
    "ModSecurity": ["CVE-2022-67890: ModSecurity rule evasion"],
    "Imperva": ["CVE-2024-56789: Imperva header injection vulnerability"]
}

class SuperWAFScanner:
    def __init__(self, url, proxy=None, proxies=None, use_tor=False, tor_port=9050, threads=4, timeout=15, 
                 signatures_file=None, signature_url=None, verbose=False, interactive=False):
        if not validators.url(url):
            raise ValueError("Invalid URL format")
        self.url = self._normalize_url(url)
        self.proxy = proxy
        self.proxies = proxies.split(",") if proxies else [proxy] if proxy else []
        self.use_tor = use_tor
        self.tor_port = tor_port
        self.threads = threads
        self.timeout = timeout
        self.verbose = verbose
        self.interactive = interactive
        self.signature_url = signature_url
        self.session = None
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "SuperWAFScanner/3.0 (Language=Python; Platform={})".format(platform.system())
        ]
        self.results = {
            "url": self.url,
            "waf_detected": None,
            "bypasses": [],
            "response_times": [],
            "cve_vulnerabilities": [],
            "anomaly_score": 0
        }
        self.waf_signatures = WAF_SIGNATURES
        self.tamper_scripts = TAMPER_SCRIPTS.copy()
        
        if signatures_file and os.path.exists(signatures_file):
            self._load_signatures(signatures_file)
        if signature_url:
            asyncio.run(self._fetch_signatures(signature_url))
        self._load_tamper_plugins()
        if use_tor:
            self._setup_tor()

    def _normalize_url(self, url):
        """Ensure URL starts with http:// or https://."""
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        return url

    def _load_signatures(self, signatures_file):
        """Load WAF signatures from a JSON file."""
        try:
            with open(signatures_file, 'r') as f:
                custom_signatures = json.load(f)
                self._validate_signatures(custom_signatures)
                self.waf_signatures.update(custom_signatures)
            logger.info("Loaded %d custom signatures from %s", len(custom_signatures), signatures_file)
        except Exception as e:
            logger.error("Failed to load signatures: %s", e)

    def _validate_signatures(self, signatures):
        """Validate the format of custom signatures."""
        for waf_name, signature in signatures.items():
            if not isinstance(signature, dict):
                raise ValueError(f"Invalid signature format for {waf_name}")
            if not any(key in signature for key in ["headers", "status_codes", "patterns"]):
                raise ValueError(f"Signature for {waf_name} missing required fields")

    async def _fetch_signatures(self, signature_url):
        """Fetch WAF signatures from a URL."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(signature_url, timeout=self.timeout) as response:
                    if response.status == 200:
                        custom_signatures = await response.json()
                        self._validate_signatures(custom_signatures)
                        self.waf_signatures.update(custom_signatures)
                        logger.info("Fetched %d signatures from %s", len(custom_signatures), signature_url)
                    else:
                        logger.error("Failed to fetch signatures: HTTP %d", response.status)
        except Exception as e:
            logger.error("Failed to fetch signatures: %s", e)

    def _load_tamper_plugins(self):
        """Load tamper scripts from tamper_plugins directory."""
        plugin_dir = "tamper_plugins"
        if not os.path.exists(plugin_dir):
            return
        for filename in os.listdir(plugin_dir):
            if filename.endswith(".py") and filename != "__init__.py":
                module_name = filename[:-3]
                file_path = os.path.join(plugin_dir, filename)
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                if hasattr(module, "tamper"):
                    self.tamper_scripts[module_name] = module.tamper
                    logger.info("Loaded tamper plugin: %s", module_name)

    def _setup_tor(self):
        """Configure Tor proxy."""
        try:
            self.proxy = f'socks5h://127.0.0.1:{self.tor_port}'
            self.proxies = [self.proxy]
            logger.info("Using Tor proxy on port %d", self.tor_port)
            if not asyncio.run(self._check_tor_connection()):
                logger.error("Tor connection failed. Ensure Tor is running.")
                exit(1)
        except Exception as e:
            logger.error("Failed to setup Tor: %s", e)
            exit(1)

    async def _check_tor_connection(self):
        """Check if Tor is configured properly."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://check.torproject.org', timeout=10, proxy=self.proxy) as response:
                    text = await response.text()
                    return 'Congratulations' in text
        except Exception:
            return False

    def _get_proxy(self):
        """Rotate proxies if provided."""
        return random.choice(self.proxies) if self.proxies else None

    async def _send_request(self, url, method='GET', data=None, tamper=None, retries=3):
        """Send asynchronous HTTP request with retries and jitter."""
        if tamper and tamper in self.tamper_scripts:
            url = self.tamper_scripts[tamper](url)
        headers = {'User-Agent': random.choice(self.user_agents)}
        proxy = self._get_proxy()
        for attempt in range(retries):
            try:
                start_time = time.time()
                async with aiohttp.ClientSession() as session:
                    if method == 'GET':
                        async with session.get(url, headers=headers, proxy=proxy, timeout=self.timeout) as response:
                            text = await response.text()
                            end_time = time.time()
                            return response, text, end_time - start_time
                    else:
                        async with session.post(url, data=data, headers=headers, proxy=proxy, timeout=self.timeout) as response:
                            text = await response.text()
                            end_time = time.time()
                            return response, text, end_time - start_time
            except aiohttp.ClientError as e:
                if attempt < retries - 1:
                    wait_time = (2 ** attempt) + random.uniform(0, 0.1)  # Add jitter
                    logger.warning("Request failed, retrying after %ds: %s", wait_time, e)
                    await asyncio.sleep(wait_time)
                else:
                    logger.error("Request failed after %d retries: %s", retries, e)
                    return None, None, 0
        return None, None, 0

    async def detect_waf(self):
        """Detect WAF by sending normal and malicious requests."""
        logger.info("Testing connection to %s", self.url)
        response, text, response_time = await self._send_request(self.url)
        if not response:
            logger.error("Failed to connect to target URL")
            return False

        payloads = {
            "xss": [self.url + "?test=<script>alert('xss')</script>", self.url + "?test=%3Cscript%3Ealert%28%27xss%27%29%3C%2Fscript%3E"],
            "sqli": [self.url + "?id=1 AND 1=1", self.url + "?id=1%20UNION%20SELECT%20NULL--"],
            "lfi": [self.url + "?test=../../etc/passwd", self.url + "?test=..%2F..%2Fetc%2Fpasswd"],
            "rce": [self.url + "?exec=whoami", self.url + "?cmd=cat%20/etc/passwd"]
        }

        if self.interactive:
            print("Select payload types to test (comma-separated: xss,sqli,lfi,rce,all):")
            selected = input().strip().split(",")
            if "all" in selected:
                selected = payloads.keys()
        else:
            selected = payloads.keys()

        tasks = []
        for payload_type in selected:
            if payload_type in payloads:
                tasks.extend([self._send_request(payload) for payload in payloads[payload_type]])

        responses = []
        for future in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Scanning payloads"):
            responses.append(await future)

        self.results["response_times"] = [resp_time for _, _, resp_time in responses if resp_time > 0]
        self._analyze_anomalies()

        for response, text, _ in responses:
            if response:
                for waf_name, signature in self.waf_signatures.items():
                    if self._match_waf(response, text, signature):
                        logger.info("Detected WAF: %s", waf_name)
                        self.results["waf_detected"] = waf_name
                        self.results["cve_vulnerabilities"] = CVE_DATABASE.get(waf_name, [])
                        return True
        logger.info("No WAF detected")
        return False

    def _analyze_anomalies(self):
        """Detect NG-WAFs using response time clustering."""
        if not self.results["response_times"]:
            return
        times = np.array(self.results["response_times"])
        mean_time = np.mean(times)
        std_time = np.std(times)
        self.results["anomaly_score"] = np.sum((times - mean_time) ** 2) / (std_time + 1e-10)
        if self.results["anomaly_score"] > 10:  # Arbitrary threshold
            logger.warning("High anomaly score (%f): Possible NG-WAF detected", self.results["anomaly_score"])

    def _match_waf(self, response, text, signature):
        """Match response against WAF signature."""
        if self.verbose:
            logger.debug("Checking WAF signature: %s", signature)
        for header in signature.get("headers", []):
            for resp_header in response.headers:
                if re.match(header, resp_header, re.IGNORECASE):
                    return True
        if response.status in signature.get("status_codes", []):
            return True
        for pattern in signature.get("patterns", []):
            if text and re.search(pattern, text, re.IGNORECASE):
                return True
        return False

    def test_bypasses(self):
        """Test bypass techniques using tamper scripts in parallel."""
        if not self.results["waf_detected"]:
            logger.info("No WAF detected, skipping bypass tests")
            return

        logger.info("Starting bypass analysis for %s", self.results["waf_detected"])
        payload = self.url + "?id=1 AND 1=1"

        def run_tamper(tamper_name):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            response, text, _ = loop.run_until_complete(self._send_request(payload, tamper=tamper_name))
            if response and response.status == 200:
                # Validate bypass (check for application response, e.g., SQL error)
                if "error" in text.lower() or "sql" in text.lower():
                    logger.info("Bypass successful with tamper: %s", tamper_name)
                    self.results["bypasses"].append({
                        "tamper": tamper_name,
                        "payload": payload,
                        "status_code": response.status
                    })

        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            executor.map(run_tamper, self.tamper_scripts.keys())

    def save_results(self, output_file, output_format='json'):
        """Save scan results to a file (JSON, CSV, or HTML)."""
        if output_format == 'json':
            with open(output_file, 'w') as f:
                json.dump(self.results, f, indent=4)
            logger.info("Results saved to %s (JSON)", output_file)
        elif output_format == 'csv':
            with open(output_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["URL", "WAF Detected", "Bypasses", "Response Times", "Anomaly Score", "CVEs"])
                writer.writerow([
                    self.results["url"],
                    self.results["waf_detected"],
                    "; ".join([f"{b['tamper']}:{b['payload']}" for b in self.results["bypasses"]]),
                    "; ".join(map(str, self.results["response_times"])),
                    self.results["anomaly_score"],
                    "; ".join(self.results["cve_vulnerabilities"])
                ])
            logger.info("Results saved to %s (CSV)", output_file)
        elif output_format == 'html':
            env = Environment(loader=FileSystemLoader('.'))
            template = env.from_string("""
            <!DOCTYPE html>
            <html>
            <head>
                <title>SuperWAFScanner Report</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    h1 { color: #333; }
                </style>
            </head>
            <body>
                <h1>SuperWAFScanner Report</h1>
                <table>
                    <tr><th>URL</th><td>{{ results.url }}</td></tr>
                    <tr><th>WAF Detected</th><td>{{ results.waf_detected or 'None' }}</td></tr>
                    <tr><th>Bypasses</th><td>{{ results.bypasses | join('<br>') }}</td></tr>
                    <tr><th>Response Times</th><td>{{ results.response_times | join(', ') }}</td></tr>
                    <tr><th>Anomaly Score</th><td>{{ results.anomaly_score }}</td></tr>
                    <tr><th>CVEs</th><td>{{ results.cve_vulnerabilities | join('<br>') }}</td></tr>
                </table>
            </body>
            </html>
            """)
            with open(output_file, 'w') as f:
                f.write(template.render(results={
                    "url": self.results["url"],
                    "waf_detected": self.results["waf_detected"],
                    "bypasses": [f"{b['tamper']}: {b['payload']}" for b in self.results["bypasses"]],
                    "response_times": self.results["response_times"],
                    "anomaly_score": self.results["anomaly_score"],
                    "cve_vulnerabilities": self.results["cve_vulnerabilities"]
                }))
            logger.info("Results saved to %s (HTML)", output_file)

async def main():
    parser = argparse.ArgumentParser(description="SuperWAFScanner: Advanced WAF Detection and Bypass Tool")
    parser.add_argument("-u", "--url", required=True, help="Target URL to scan")
    parser.add_argument("--proxy", help="Single proxy in format type://address:port")
    parser.add_argument("--proxies", help="Comma-separated list of proxies")
    parser.add_argument("--tor", action="store_true", help="Use Tor as proxy")
    parser.add_argument("--tor-port", type=int, default=9050, help="Tor port (default: 9050)")
    parser.add_argument("--threads", type=int, default=4, help="Number of threads (default: 4)")
    parser.add_argument("--timeout", type=int, default=15, help="Request timeout in seconds (default: 15)")
    parser.add_argument("-o", "--output", default="waf_scan_results.json", help="Output file")
    parser.add_argument("--format", choices=['json', 'csv', 'html'], default='json', help="Output format (json, csv, html)")
    parser.add_argument("--signatures", help="Path to custom WAF signatures JSON file")
    parser.add_argument("--signature-url", help="URL to fetch WAF signatures")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument("--interactive", action="store_true", help="Run in interactive mode")
    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    scanner = SuperWAFScanner(
        url=args.url,
        proxy=args.proxy,
        proxies=args.proxies,
        use_tor=args.tor,
        tor_port=args.tor_port,
        threads=args.threads,
        timeout=args.timeout,
        signatures_file=args.signatures,
        signature_url=args.signature_url,
        verbose=args.verbose,
        interactive=args.interactive
    )

    await scanner.detect_waf()
    scanner.test_bypasses()
    scanner.save_results(args.output, args.format)

if platform.system() == "Emscripten":
    asyncio.ensure_future(main())
else:
    if __name__ == "__main__":
        asyncio.run(main())
