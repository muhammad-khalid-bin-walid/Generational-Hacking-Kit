#!/bin/bash

# Ultimate Wayback Machine search tool with advanced URL filtering, PDF analysis, Nuclei scanning, rate limit bypass, domain/date-based output directories, and loading screen.

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration defaults
LOG_FILE="wayback_search.log"
TEMP_DIR=$(mktemp -d)
CONFIG_FILE="wayback_search.conf"
EXTENSIONS="xls|xml|xlsx|json|pdf|sql|doc|docx|pptx|txt|git|zip|tar\.gz|tgz|bak|7z|rar|log|cache|secret|db|backup|yml|gz|config|csv|yaml|md|md5|exe|dll|bin|ini|bat|sh|tar|deb|rpm|iso|img|env|apk|msi|dmg|tmp|crt|pem|key|pub|asc"
SENSITIVE_KEYWORDS="internal use only|confidential|strictly private|personal & confidential|private|restricted|internal|not for distribution|do not share|proprietary|trade secret|classified|sensitive|bank statement|invoice|salary|contract|agreement|non disclosure|passport|social security|ssn|date of birth|credit card|identity|id number|company confidential|staff only|management only|internal only"
NUCLEI_TEMPLATES=""
NUCLEI_RATE_LIMIT=50
NUCLEI_TIMEOUT=10
RETRIES=3
VERBOSE=false
COMPRESS_OUTPUT=false
USE_PROXIES=false
PROXY_FILE="proxies.txt"
DELAY_RANGE="1-5"
DRY_RUN=false
POST_PROCESS=""
CPU_CORES=$(nproc || echo 4)
PROXY_REFRESH_INTERVAL=100
OUTPUT_BASE_DIR="."
SHOW_PROGRESS=true

# Function to log messages
log_message() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local color=$NC
    case "$level" in
        ERROR) color=$RED ;;
        INFO) color=$GREEN ;;
        WARN) color=$YELLOW ;;
        DEBUG) color=$BLUE ;;
        RESULT) color=$CYAN ;;
    esac
    if [[ "$VERBOSE" == true || "$level" != "DEBUG" ]]; then
        echo -e "${color}[$timestamp] $message${NC}" >> "$OUTPUT_DIR/$LOG_FILE"
        if [[ "$SHOW_PROGRESS" == true || "$level" == "ERROR" || "$level" == "RESULT" ]]; then
            echo -e "${color}$message${NC}"
        fi
    fi
}

# Function to display loading animation
show_loading_animation() {
    local message=$1
    local pid=$2
    if [[ "$SHOW_PROGRESS" != true ]]; then
        return
    fi
    local spinstr='|/-\'
    local i=0
    while kill -0 "$pid" 2>/dev/null; do
        local temp=${spinstr#?}
        printf "\r%s [%c] " "$message" "${spinstr:0:1}"
        spinstr=$temp${spinstr%"$temp"}
        sleep 0.1
        ((i++))
        if [[ $i -eq 50 ]]; then
            printf "\r%s     " "$message"
            i=0
        fi
    done
    printf "\r\033[K"
}

# Function to validate configuration
validate_config() {
    if [[ -z "$EXTENSIONS" ]]; then
        log_message ERROR "EXTENSIONS variable is empty. Must specify at least one file extension."
        exit 1
    fi
    if ! echo "$EXTENSIONS" | grep -qE '^[a-zA-Z0-9|.\+\-\\/]+$'; then
        log_message WARN "EXTENSIONS contains unexpected characters. Ensure it is a pipe-separated list (e.g., 'pdf|txt|tar\.gz')."
    fi
    if ! echo "$DELAY_RANGE" | grep -qE '^[0-9]+-[0-9]+$'; then
        log_message ERROR "Invalid DELAY_RANGE format. Must be 'min-max' (e.g., '1-5')."
        exit 1
    fi
    if [[ -n "$NUCLEI_TEMPLATES" && ! -d "$NUCLEI_TEMPLATES" ]]; then
        log_message ERROR "NUCLEI_TEMPLATES directory does not exist: $NUCLEI_TEMPLATES"
        exit 1
    fi
    if [[ ! -d "$OUTPUT_BASE_DIR" || ! -w "$OUTPUT_BASE_DIR" ]]; then
        log_message ERROR "Output base directory '$OUTPUT_BASE_DIR' is not writable."
        exit 1
    fi
}

# Function to load configuration file
load_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        log_message INFO "Loading configuration from $CONFIG_FILE..."
        source "$CONFIG_FILE"
    fi
}

# Function to check if a command is available
check_command() {
    if ! command -v "$1" &> /dev/null; then
        log_message ERROR "Command '$1' is not installed. Please install it and try again."
        exit 1
    fi
}

# Function to validate URL
validate_url() {
    local url=$1
    if [[ -z "$url" ]]; then
        log_message ERROR "No URL provided."
        return 1
    fi
    if ! echo "$url" | grep -qE '^([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$'; then
        log_message ERROR "Invalid URL format. Please provide a valid domain (e.g., example.com or sub.example.com)."
        return 1
    fi
    return 0
}

# Function to check network connectivity
check_network() {
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping network check."
        return
    fi
    local attempt=1
    local max_attempts=3
    local delay=2
    while [[ $attempt -le $max_attempts ]]; do
        log_message INFO "Checking network connectivity to web.archive.org (attempt $attempt/$max_attempts)..."
        if curl -s --connect-timeout 5 --head "https://web.archive.org" >/dev/null 2>&1; then
            log_message INFO "Network connectivity to web.archive.org confirmed."
            return 0
        fi
        log_message WARN "Network check failed. Retrying in $delay seconds..."
        sleep $delay
        ((attempt++))
    done
    log_message ERROR "No network connectivity to web.archive.org after $max_attempts attempts. Please check your network settings, DNS, or firewall. Ensure curl can access https://web.archive.org."
    exit 1
}

# Function to check disk space
check_disk_space() {
    local dir=$1
    local required_space=1048576 # 1MB in KB
    local available_space=$(df -k "$dir" | tail -1 | awk '{print $4}')
    if [[ "$available_space" -lt "$required_space" ]]; then
        log_message ERROR "Insufficient disk space in $dir. Required: 1MB, Available: $available_space KB."
        exit 1
    fi
}

# Function to validate and load proxies
load_proxies() {
    local proxy_file=$1
    local proxies=()
    if [[ ! -f "$proxy_file" ]]; then
        log_message WARN "Proxy file '$proxy_file' not found. Disabling proxies."
        return 1
    fi
    while IFS= read -r proxy; do
        if [[ -n "$proxy" && "$proxy" =~ ^(http|socks5)://[a-zA-Z0-9.-]+:[0-9]+$ ]]; then
            if [[ "$DRY_RUN" == true ]]; then
                proxies+=("$proxy")
                continue
            fi
            if curl -s --connect-timeout 5 --proxy "$proxy" https://web.archive.org &> /dev/null; then
                proxies+=("$proxy")
                log_message DEBUG "Valid proxy: $proxy"
            else
                log_message WARN "Proxy $proxy is not reachable. Skipping."
            fi
        fi
    done < "$proxy_file"
    if [[ ${#proxies[@]} -eq 0 ]]; then
        log_message WARN "No valid proxies found. Disabling proxies."
        return 1
    fi
    echo "${proxies[@]}"
}

# Function to refresh proxies
refresh_proxies() {
    local proxy_file=$1
    log_message INFO "Refreshing proxy list..."
    PROXIES=($(load_proxies "$proxy_file"))
    if [[ ${#PROXIES[@]} -eq 0 ]]; then
        USE_PROXIES=false
        log_message WARN "No valid proxies after refresh. Falling back to direct connection."
    else
        log_message INFO "Refreshed ${#PROXIES[@]} valid proxies."
    fi
}

# Function to get next proxy (sequential rotation)
get_next_proxy() {
    local proxies=($1)
    if [[ ${#proxies[@]} -eq 0 ]]; then
        echo ""
        return
    fi
    local index_file="$TEMP_DIR/proxy_index"
    local index=0
    if [[ -f "$index_file" ]]; then
        index=$(cat "$index_file")
    fi
    local proxy=${proxies[$index]}
    ((index=(index + 1) % ${#proxies[@]}))
    echo "$index" > "$index_file"
    echo "$proxy"
}

# Function to get random delay
get_random_delay() {
    local range=$1
    local min=${range%-*}
    local max=${range#*-}
    echo $((RANDOM % (max - min + 1) + min))
}

# Function to monitor rate limits
monitor_rate_limits() {
    local status_code=$1
    if [[ "$status_code" == "429" ]]; then
        log_message WARN "Rate limit detected (HTTP 429). Increasing delay range."
        local current_min=${DELAY_RANGE%-*}
        local current_max=${DELAY_RANGE#*-}
        DELAY_RANGE="$((current_min + 1))-$((current_max + 2))"
        log_message INFO "New delay range: $DELAY_RANGE"
    fi
}

# Function to prompt for rate limit bypass
prompt_for_rate_limit_bypass() {
    local choice=""
    read -p "Enable rate limit bypass (proxies and delays)? (y/n, default: n): " choice
    if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
        echo "true"
    else
        echo "false"
    fi
}

# Function to prompt for URL
prompt_for_url() {
    local url=""
    while [[ -z "$url" ]]; do
        read -p "Enter the domain to search (e.g., example.com): " url
        if validate_url "$url"; then
            echo "$url"
            return
        fi
        url=""
    done
}

# Function to create output directory
create_output_directory() {
    local domain=$1
    local base_dir=$2
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local output_dir="${base_dir}/${domain}_${timestamp}"
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Would create output directory $output_dir"
        echo "$output_dir"
        return
    fi
    if [[ -d "$output_dir" ]]; then
        read -p "Directory '$output_dir' exists. Overwrite contents? (y/n): " overwrite
        if [[ "$overwrite" != "y" && "$overwrite" != "Y" ]]; then
            log_message ERROR "Output directory exists and overwrite was not confirmed."
            exit 1
        fi
        rm -rf "$output_dir"/*
    else
        mkdir -p "$output_dir" || { log_message ERROR "Failed to create output directory $output_dir."; exit 1; }
    fi
    check_disk_space "$output_dir"
    echo "$output_dir"
}

# Function to prompt for input file for PDF search
prompt_for_pdf_input_file() {
    local filtered_file=$1
    local cdx_filtered_file=$2
    local choice=""
    echo "Select the file to search for sensitive PDFs:"
    echo "1) $filtered_file (filtered using uro and grep)"
    echo "2) $cdx_filtered_file (filtered using CDX API)"
    read -p "Enter choice (1 or 2, default: 1): " choice
    case "$choice" in
        2) echo "$cdx_filtered_file" ;;
        *|1) echo "$filtered_file" ;;
    esac
}

# Function to prompt for Nuclei scan
prompt_for_nuclei() {
    local choice=""
    read -p "Run Nuclei scans on output files? (y/n, default: n): " choice
    if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
        echo "true"
    else
        echo "false"
    fi
}

# Function to display help
show_help() {
    echo -e "${GREEN}Ultimate Wayback Machine Search Tool${NC}"
    echo "Usage: $0 [options]"
    echo "Options:"
    echo "  -h, --help            Show this help message"
    echo "  -u, --url             Domain to search (e.g., example.com)"
    echo "  -o, --output          Base directory for output (default: current directory)"
    echo "  -v, --verbose         Enable verbose output"
    echo "  -e, --extensions      Custom file extensions (e.g., 'pdf|txt|doc')"
    echo "  -k, --keywords        Custom sensitive keywords (e.g., 'confidential|secret')"
    echo "  -t, --templates       Custom Nuclei templates path"
    echo "  -c, --compress        Compress output files into a .tar.gz archive"
    echo "  -p, --proxy-file      File containing proxy list (e.g., proxies.txt)"
    echo "  -n, --no-proxy        Disable proxy usage"
    echo "  -d, --delay-range     Delay range for requests (e.g., '1-5')"
    echo "  --dry-run             Simulate script without network requests or file writes"
    echo "  --post-process        Path to custom post-processing script"
    echo "  --no-progress         Disable loading animation and progress dashboard"
    echo "Output:"
    echo "  Files are saved in <output_dir>/<domain>_<YYYYMMDD_HHMMSS>/:"
    echo "    raw.txt: Raw URLs from Wayback Machine"
    echo "    filtered.txt: URLs filtered by file extensions (using uro and grep)"
    echo "    cdx_filtered.txt: URLs filtered by file extensions (using CDX API)"
    echo "    sensitive_pdfs.txt: PDFs containing sensitive keywords"
    echo "    <type>.unique.txt: Deduplicated URLs"
    echo "    <ext>.txt: URLs categorized by file extension"
    echo "    sensitive_snippets.txt: Snippets of sensitive keywords from PDFs"
    echo "    <type>.valid.txt: Validated URLs"
    echo "    <type>.nuclei.json: Nuclei scan results (if enabled)"
    echo "    results.csv: CSV summary of results"
    echo "    wayback_search.log: Log file"
    echo "Configuration:"
    echo "  Settings can be overridden in $CONFIG_FILE."
    echo "Example: $0 -u example.com -o /path/to/output -v -c -p proxies.txt"
    exit 0
}

# Function to backup results
backup_results() {
    local output_dir=$1
    local base_dir=$2
    local backup_dir="${base_dir}/backups/$(basename "$output_dir")"
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Would backup to $backup_dir"
        return
    fi
    mkdir -p "$backup_dir"
    for file in "$output_dir"/*.{txt,json,csv,log}; do
        if [[ -f "$file" ]]; then
            cp "$file" "$backup_dir/" && log_message INFO "Backed up $file to $backup_dir"
        fi
    done
}

# Function to remove duplicates
remove_duplicates() {
    local input_file=$1
    local output_file=$2
    if [[ ! -f "$input_file" ]]; then
        log_message WARN "Input file '$input_file' does not exist for deduplication."
        return
    fi
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping deduplication for $input_file."
        return
    fi
    sort -u "$input_file" > "$output_file"
    log_message RESULT "Deduplicated URLs saved to $output_file ($(wc -l < "$output_file") lines)"
}

# Function to categorize files by extension
categorize_files() {
    local input_file=$1
    local output_dir=$2
    if [[ ! -f "$input_file" ]]; then
        log_message WARN "Input file '$input_file' does not exist for categorization."
        return
    fi
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping file categorization for $input_file."
        return
    fi
    log_message INFO "Categorizing URLs by file extension..."
    local ext_array=(${EXTENSIONS//|/ })
    for ext in "${ext_array[@]}"; do
        grep -E "\.${ext}$" "$input_file" > "${output_dir}/${ext}.txt"
        if [[ -s "${output_dir}/${ext}.txt" ]]; then
            log_message RESULT "URLs with .$ext saved to ${output_dir}/${ext}.txt ($(wc -l < "${output_dir}/${ext}.txt") lines)"
        fi
    done
}

# Function to highlight keywords in PDFs
highlight_keywords() {
    local input_file=$1
    local output_file=$2
    if [[ ! -f "$input_file" ]]; then
        log_message WARN "Input file '$input_file' does not exist for keyword highlighting."
        return
    fi
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping keyword highlighting for $input_file."
        return
    fi
    log_message INFO "Extracting sensitive keyword snippets from PDFs..."
    local temp_output="$TEMP_DIR/snippets.txt"
    while IFS= read -r url; do
        if [[ -n "$url" && "$url" =~ \.pdf$ ]]; then
            local text=$(curl -s --connect-timeout 10 "$url" | pdftotext - - 2>/dev/null)
            if echo "$text" | grep -Eai "$SENSITIVE_KEYWORDS" > "$TEMP_DIR/matches.txt"; then
                echo "URL: $url" >> "$temp_output"
                echo "Matches:" >> "$temp_output"
                cat "$TEMP_DIR/matches.txt" >> "$temp_output"
                echo "----------------------------------------" >> "$temp_output"
            fi
        fi
    done < "$input_file"
    if [[ -s "$temp_output" ]]; then
        mv "$temp_output" "$output_file"
        log_message RESULT "Sensitive keyword snippets saved to $output_file"
    else
        log_message INFO "No sensitive keyword snippets found."
    fi
}

# Function to validate URLs
validate_urls() {
    local input_file=$1
    local output_file=$2
    if [[ ! -f "$input_file" ]]; then
        log_message WARN "Input file '$input_file' does not exist for URL validation."
        return
    fi
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping URL validation for $input_file."
        return
    fi
    log_message INFO "Validating URLs in $input_file..."
    local temp_output="$TEMP_DIR/valid_urls.txt"
    while IFS= read -r url; do
        if curl -s --connect-timeout 5 --head "$url" &> /dev/null; then
            echo "$url" >> "$temp_output"
        fi
    done < "$input_file"
    if [[ -s "$temp_output" ]]; then
        mv "$temp_output" "$output_file"
        log_message RESULT "Valid URLs saved to $output_file ($(wc -l < "$output_file") lines)"
    else
        log_message INFO "No valid URLs found."
    fi
}

# Function to export results to CSV
export_to_csv() {
    local output_dir=$1
    local csv_file="${output_dir}/results.csv"
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping CSV export."
        return
    fi
    log_message INFO "Exporting results to $csv_file..."
    {
        echo "File Type,URL Count,Nuclei Findings"
        for suffix in raw.txt filtered.txt cdx_filtered.txt sensitive_pdfs.txt; do
            local count=0
            local nuclei_count=0
            if [[ -f "${output_dir}/${suffix}" ]]; then
                count=$(wc -l < "${output_dir}/${suffix}")
            fi
            if [[ -f "${output_dir}/${suffix%.txt}.nuclei.json" ]]; then
                nuclei_count=$(wc -l < "${output_dir}/${suffix%.txt}.nuclei.json")
            fi
            echo "$(basename "$suffix" .txt),$count,$nuclei_count"
        done
    } > "$csv_file"
    log_message RESULT "CSV summary saved to $csv_file"
}

# Function to fetch URLs from Wayback Machine with retries and proxies
fetch_urls() {
    local url=$1
    local output_file=$2
    local proxies=($3)
    local request_count=$4
    local attempt=1
    local backoff=2
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping fetch for $url."
        touch "$output_file"
        return
    fi
    # Refresh proxies if needed
    if [[ $request_count -ge $PROXY_REFRESH_INTERVAL && ${#proxies[@]} -gt 0 ]]; then
        refresh_proxies "$PROXY_FILE"
        proxies=("${PROXIES[@]}")
    fi
    while [[ $attempt -le $RETRIES ]]; do
        log_message INFO "Fetching URLs (attempt $attempt/$RETRIES)..."
        local proxy=""
        if [[ "$USE_PROXIES" == true && ${#proxies[@]} -gt 0 ]]; then
            proxy=$(get_next_proxy "${proxies[*]}")
            log_message DEBUG "Using proxy: $proxy"
        fi
        local curl_cmd=(curl -s -G --connect-timeout 10)
        [[ -n "$proxy" ]] && curl_cmd+=(--proxy "$proxy")
        curl_cmd+=("https://web.archive.org/cdx/search/cdx"
                   --data-urlencode "url=$url"
                   --data-urlencode "collapse=urlkey"
                   --data-urlencode "output=text"
                   --data-urlencode "fl=original")
        local status_code
        # Run curl in background with loading animation
        "${curl_cmd[@]}" > "$output_file" 2>"$TEMP_DIR/curl_error" &
        local curl_pid=$!
        show_loading_animation "Fetching URLs from Wayback Machine..." "$curl_pid"
        wait "$curl_pid"
        if [[ -s "$output_file" ]]; then
            local delay=$(get_random_delay "$DELAY_RANGE")
            log_message DEBUG "Sleeping for $delay seconds..."
            sleep "$delay"
            monitor_rate_limits "200"
            return 0
        fi
        status_code=$(grep -oP 'HTTP/\d\.\d\s+\K\d+' "$TEMP_DIR/curl_error" || echo "0")
        monitor_rate_limits "$status_code"
        if [[ "$status_code" == "429" ]]; then
            log_message WARN "Rate limit detected (HTTP 429). Retrying with backoff..."
            sleep $((backoff * attempt))
        else
            log_message WARN "Fetch attempt $attempt failed. Retrying..."
            sleep 2
        fi
        ((attempt++))
    done
    log_message ERROR "Failed to fetch URLs after $RETRIES attempts."
    exit 1
}

# Function to fetch and filter URLs
fetch_and_filter_urls() {
    local domain=$1
    local output_dir=$2
    local proxies=($3)
    local raw_file="${output_dir}/raw.txt"
    local filtered_file="${output_dir}/filtered.txt"
    local cdx_filtered_file="${output_dir}/cdx_filtered.txt"
    local temp_file="$TEMP_DIR/wayback_temp.txt"
    local request_count=0

    log_message INFO "Fetching URLs from Wayback Machine for *.$domain/* to $raw_file..."
    fetch_urls "*.$domain/*" "$temp_file" "${proxies[*]}" $request_count &
    local fetch_pid=$!
    show_loading_animation "Fetching raw URLs..." "$fetch_pid"
    wait "$fetch_pid"
    ((request_count++))
    if [[ ! -s "$temp_file" ]]; then
        log_message ERROR "No URLs fetched from Wayback Machine."
        exit 1
    fi
    mv "$temp_file" "$raw_file"
    remove_duplicates "$raw_file" "${output_dir}/raw.unique.txt"
    validate_urls "$raw_file" "${output_dir}/raw.valid.txt"
    log_message RESULT "Raw URLs saved to $raw_file ($(wc -l < "$raw_file") lines)"

    log_message INFO "Filtering URLs for specific file extensions to $filtered_file..."
    if command -v pv &> /dev/null; then
        pv "$raw_file" | uro | grep -E "$EXTENSIONS" > "$filtered_file" &
        local filter_pid=$!
        show_loading_animation "Filtering URLs with uro and grep..." "$filter_pid"
        wait "$filter_pid"
    else
        cat "$raw_file" | uro | grep -E "$EXTENSIONS" > "$filtered_file" &
        local filter_pid=$!
        show_loading_animation "Filtering URLs with uro and grep..." "$filter_pid"
        wait "$filter_pid"
    fi
    remove_duplicates "$filtered_file" "${output_dir}/filtered.unique.txt"
    validate_urls "$filtered_file" "${output_dir}/filtered.valid.txt"
    categorize_files "$filtered_file" "$output_dir"
    log_message RESULT "Filtered URLs saved to $filtered_file ($(wc -l < "$filtered_file") lines)"

    log_message INFO "Fetching URLs with CDX filter to $cdx_filtered_file..."
    fetch_urls "*.$domain/*&filter=original:.*\.($EXTENSIONS)$" "$cdx_filtered_file" "${proxies[*]}" $request_count &
    local cdx_pid=$!
    show_loading_animation "Fetching CDX-filtered URLs..." "$cdx_pid"
    wait "$cdx_pid"
    ((request_count++))
    remove_duplicates "$cdx_filtered_file" "${output_dir}/cdx_filtered.unique.txt"
    validate_urls "$cdx_filtered_file" "${output_dir}/cdx_filtered.valid.txt"
    categorize_files "$cdx_filtered_file" "$output_dir"
    log_message RESULT "CDX-filtered URLs saved to $cdx_filtered_file ($(wc -l < "$cdx_filtered_file") lines)"
}

# Function to search PDFs for sensitive keywords (parallelized)
search_pdfs() {
    local input_file=$1
    local output_pdfs=$2
    local snippets_file=$3

    if [[ ! -f "$input_file" ]]; then
        log_message ERROR "Input file '$input_file' does not exist."
        exit 1
    fi
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping PDF search for $input_file."
        return
    fi

    log_message INFO "Searching PDFs in $input_file for sensitive keywords..."
    local temp_output="$TEMP_DIR/sensitive_pdfs.txt"
    local pdf_urls="$TEMP_DIR/pdf_urls.txt"
    grep -Ea '\.pdf' "$input_file" > "$pdf_urls"

    if [[ ! -s "$pdf_urls" ]]; then
        log_message INFO "No PDFs found in $input_file."
        return
    fi

    # Function for parallel processing
    process_pdf() {
        local url=$1
        local text=$(curl -s --connect-timeout 10 "$url" | pdftotext - - 2>/dev/null)
        if echo "$text" | grep -Eaiq "$SENSITIVE_KEYWORDS"; then
            echo "$url"
            # Save snippet
            echo "URL: $url" >> "$TEMP_DIR/snippets.txt"
            echo "Matches:" >> "$TEMP_DIR/snippets.txt"
            echo "$text" | grep -Eai "$SENSITIVE_KEYWORDS" >> "$TEMP_DIR/snippets.txt"
            echo "----------------------------------------" >> "$TEMP_DIR/snippets.txt"
        fi
    }
    export -f process_pdf
    export SENSITIVE_KEYWORDS

    if command -v parallel &> /dev/null; then
        local jobs=$((CPU_CORES * 2))
        if command -v pv &> /dev/null; then
            cat "$pdf_urls" | pv -l -s $(wc -l < "$pdf_urls") | parallel -j "$jobs" process_pdf >> "$temp_output" &
            local pdf_pid=$!
            show_loading_animation "Scanning PDFs for sensitive keywords..." "$pdf_pid"
            wait "$pdf_pid"
        else
            cat "$pdf_urls" | parallel -j "$jobs" process_pdf >> "$temp_output" &
            local pdf_pid=$!
            show_loading_animation "Scanning PDFs for sensitive keywords..." "$pdf_pid"
            wait "$pdf_pid"
        fi
    else
        while IFS= read -r url; do
            process_pdf "$url" >> "$temp_output"
        done < "$pdf_urls" &
        local pdf_pid=$!
        show_loading_animation "Scanning PDFs for sensitive keywords..." "$pdf_pid"
        wait "$pdf_pid"
    fi

    if [[ -s "$temp_output" ]]; then
        mv "$temp_output" "$output_pdfs"
        log_message RESULT "Found $(wc -l < "$output_pdfs") PDFs with sensitive keywords. Saved to $output_pdfs"
    else
        log_message INFO "No PDFs with sensitive keywords found."
    fi
    if [[ -s "$TEMP_DIR/snippets.txt" ]]; then
        mv "$TEMP_DIR/snippets.txt" "$snippets_file"
        log_message RESULT "Sensitive keyword snippets saved to $snippets_file"
    fi
}

# Function to run Nuclei scans
run_nuclei() {
    local input_file=$1
    local output_file=$2
    local type=$3

    if [[ ! -f "$input_file" ]]; then
        log_message ERROR "Input file '$input_file' does not exist."
        return
    fi
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping Nuclei scan for $input_file."
        return
    fi

    log_message INFO "Running Nuclei scan on $input_file ($type)..."
    local nuclei_args=(-rl "$NUCLEI_RATE_LIMIT" -timeout "$NUCLEI_TIMEOUT" -jsonl -o "$output_file")
    if [[ -n "$NUCLEI_TEMPLATES" ]]; then
        nuclei_args+=(-t "$NUCLEI_TEMPLATES")
    else
        nuclei_args+=(-tags "http,file")
    fi

    if command -v pv &> /dev/null; then
        pv "$input_file" | nuclei "${nuclei_args[@]}" || log_message WARN "Nuclei scan on $input_file had issues." &
        local nuclei_pid=$!
        show_loading_animation "Running Nuclei scan on $type..." "$nuclei_pid"
        wait "$nuclei_pid"
    else
        cat "$input_file" | nuclei "${nuclei_args[@]}" || log_message WARN "Nuclei scan on $input_file had issues." &
        local nuclei_pid=$!
        show_loading_animation "Running Nuclei scan on $type..." "$nuclei_pid"
        wait "$nuclei_pid"
    fi

    if [[ -s "$output_file" ]]; then
        log_message RESULT "Nuclei results for $type saved to $output_file ($(wc -l < "$output_file") findings)"
    else
        log_message INFO "No Nuclei findings for $type."
    fi
}

# Function to compress output files
compress_outputs() {
    local output_dir=$1
    local archive="${output_dir}/results_$(date +%Y%m%d_%H%M%S).tar.gz"
    local files=()
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping compression."
        return
    fi
    for suffix in *.txt *.json *.csv *.log; do
        if [[ -f "${output_dir}/${suffix}" ]]; then
            files+=("${output_dir}/${suffix}")
        fi
    done
    if [[ ${#files[@]} -gt 0 ]]; then
        log_message INFO "Compressing output files to $archive..."
        tar -czf "$archive" -C "$output_dir" . && log_message RESULT "Archive created: $archive"
    else
        log_message WARN "No files to compress."
    fi
}

# Function to generate summary report
generate_summary() {
    local output_dir=$1
    local summary_file="${output_dir}/summary.txt"
    if [[ "$DRY_RUN" == true ]]; then
        log_message INFO "Dry run: Skipping summary generation."
        return
    fi
    {
        echo "Wayback Machine Search Summary"
        echo "============================="
        echo "Date: $(date)"
        echo "Domain: $DOMAIN"
        echo "Output Directory: $output_dir"
        echo "Proxies Used: $USE_PROXIES"
        echo ""
        echo "Results:"
        [[ -f "${output_dir}/raw.txt" ]] && echo "- Raw URLs: $(wc -l < "${output_dir}/raw.txt")"
        [[ -f "${output_dir}/filtered.txt" ]] && echo "- Filtered URLs (uro/grep): $(wc -l < "${output_dir}/filtered.txt")"
        [[ -f "${output_dir}/cdx_filtered.txt" ]] && echo "- Filtered URLs (CDX): $(wc -l < "${output_dir}/cdx_filtered.txt")"
        [[ -f "${output_dir}/sensitive_pdfs.txt" ]] && echo "- Sensitive PDFs: $(wc -l < "${output_dir}/sensitive_pdfs.txt")"
        for suffix in raw.txt filtered.txt cdx_filtered.txt sensitive_pdfs.txt; do
            if [[ -f "${output_dir}/${suffix%.txt}.unique.txt" ]]; then
                echo "- Unique $suffix: $(wc -l < "${output_dir}/${suffix%.txt}.unique.txt")"
            fi
            if [[ -f "${output_dir}/${suffix%.txt}.valid.txt" ]]; then
                echo "- Valid $suffix: $(wc -l < "${output_dir}/${suffix%.txt}.valid.txt")"
            fi
            if [[ -f "${output_dir}/${suffix%.txt}.nuclei.json" ]]; then
                echo "- Nuclei findings ($suffix): $(wc -l < "${output_dir}/${suffix%.txt}.nuclei.json")"
            fi
        done
        for ext in ${EXTENSIONS//|/ }; do
            if [[ -f "${output_dir}/${ext}.txt" ]]; then
                echo "- $ext URLs: $(wc -l < "${output_dir}/${ext}.txt")"
            fi
        done
    } > "$summary_file"
    log_message RESULT "Summary report saved to $summary_file"
}

# Function to show progress dashboard
show_progress_dashboard() {
    local output_dir=$1
    local pid=$2
    if [[ "$SHOW_PROGRESS" != true || "$DRY_RUN" == true || ! -t 1 ]]; then
        return
    fi
    log_message INFO "Displaying progress dashboard..."
    while kill -0 "$pid" 2>/dev/null; do
        clear
        echo -e "${CYAN}Wayback Machine Search Progress${NC}"
        echo "============================="
        echo "Domain: $DOMAIN"
        echo "Output Directory: $output_dir"
        echo ""
        echo "Current Results:"
        [[ -f "${output_dir}/raw.txt" ]] && echo "- Raw URLs: $(wc -l < "${output_dir}/raw.txt")"
        [[ -f "${output_dir}/filtered.txt" ]] && echo "- Filtered URLs (uro/grep): $(wc -l < "${output_dir}/filtered.txt")"
        [[ -f "${output_dir}/cdx_filtered.txt" ]] && echo "- Filtered URLs (CDX): $(wc -l < "${output_dir}/cdx_filtered.txt")"
        [[ -f "${output_dir}/sensitive_pdfs.txt" ]] && echo "- Sensitive PDFs: $(wc -l < "${output_dir}/sensitive_pdfs.txt")"
        for suffix in raw.txt filtered.txt cdx_filtered.txt sensitive_pdfs.txt; do
            if [[ -f "${output_dir}/${suffix%.txt}.nuclei.json" ]]; then
                echo "- Nuclei findings ($suffix): $(wc -l < "${output_dir}/${suffix%.txt}.nuclei.json")"
            fi
        done
        sleep 2
    done
    clear
}

# Function to run post-processing script
run_post_process() {
    local script=$1
    local output_dir=$2
    if [[ -n "$script" && -x "$script" ]]; then
        log_message INFO "Running post-processing script: $script"
        "$script" "$output_dir" || log_message WARN "Post-processing script failed."
    fi
}

# Cleanup function
cleanup() {
    log_message INFO "Cleaning up temporary files..."
    rm -rf "$TEMP_DIR"
}

# Trap to ensure cleanup on exit
trap cleanup EXIT

# Main script

# Parse options
DOMAIN=""
while [[ "$1" =~ ^- ]]; do
    case "$1" in
        -h|--help) show_help ;;
        -u|--url) DOMAIN="$2"; shift ;;
        -o|--output) OUTPUT_BASE_DIR="$2"; shift ;;
        -v|--verbose) VERBOSE=true ;;
        -e|--extensions) EXTENSIONS="$2"; shift ;;
        -k|--keywords) SENSITIVE_KEYWORDS="$2"; shift ;;
        -t|--templates) NUCLEI_TEMPLATES="$2"; shift ;;
        -c|--compress) COMPRESS_OUTPUT=true ;;
        -p|--proxy-file) PROXY_FILE="$2"; shift ;;
        -n|--no-proxy) USE_PROXIES=false ;;
        -d|--delay-range) DELAY_RANGE="$2"; shift ;;
        --dry-run) DRY_RUN=true ;;
        --post-process) POST_PROCESS="$2"; shift ;;
        --no-progress) SHOW_PROGRESS=false ;;
        *) log_message ERROR "Unknown option: $1"; show_help ;;
    esac
    shift
done

# Load and validate configuration
load_config
validate_config

# Check for required commands
check_command "curl"
check_command "uro"
check_command "grep"
check_command "pdftotext"

# Check optional commands
if [[ "$(prompt_for_nuclei)" == "true" ]]; then
    check_command "nuclei"
fi
if command -v parallel &> /dev/null; then
    log_message DEBUG "Parallel processing enabled with $CPU_CORES cores."
fi
if command -v pv &> /dev/null; then
    log_message DEBUG "Progress indicators enabled with pv."
fi

# Check network connectivity
check_network

# Load proxies if enabled
PROXIES=()
if [[ "$USE_PROXIES" == true ]]; then
    PROXIES=($(load_proxies "$PROXY_FILE"))
    if [[ ${#PROXIES[@]} -eq 0 ]]; then
        USE_PROXIES=false
        log_message WARN "Falling back to direct connection (no valid proxies)."
    else
        log_message INFO "Loaded ${#PROXIES[@]} valid proxies."
    fi
fi

# Prompt for rate limit bypass if not specified
if [[ -z "${USE_PROXIES+x}" ]]; then
    USE_PROXIES=$(prompt_for_rate_limit_bypass)
fi

# Get URL if not provided
if [[ -z "$DOMAIN" ]]; then
    DOMAIN=$(prompt_for_url)
else
    if ! validate_url "$DOMAIN"; then
        exit 1
    fi
fi

# Create output directory
OUTPUT_DIR=$(create_output_directory "$DOMAIN" "$OUTPUT_BASE_DIR")

# Backup existing results
backup_results "$OUTPUT_DIR" "$OUTPUT_BASE_DIR"

# Execute the main functions in background to allow progress dashboard
(
    fetch_and_filter_urls "$DOMAIN" "$OUTPUT_DIR" "${PROXIES[*]}"
    PDF_INPUT_FILE=$(prompt_for_pdf_input_file "${OUTPUT_DIR}/filtered.txt" "${OUTPUT_DIR}/cdx_filtered.txt")
    search_pdfs "$PDF_INPUT_FILE" "${OUTPUT_DIR}/sensitive_pdfs.txt" "${OUTPUT_DIR}/sensitive_snippets.txt"

    # Run Nuclei scans if requested
    if [[ "$(prompt_for_nuclei)" == "true" ]]; then
        for file in "${OUTPUT_DIR}/raw.valid.txt" "${OUTPUT_DIR}/filtered.valid.txt" "${OUTPUT_DIR}/cdx_filtered.valid.txt" "${OUTPUT_DIR}/sensitive_pdfs.txt"; do
            if [[ -f "$file" ]]; then
                type=$(basename "$file" | cut -d'.' -f1)
                run_nuclei "$file" "${OUTPUT_DIR}/${type}.nuclei.json" "$type"
            fi
        done
    fi

    # Generate summary report and CSV
    generate_summary "$OUTPUT_DIR"
    export_to_csv "$OUTPUT_DIR"

    # Compress output files if requested
    if [[ "$COMPRESS_OUTPUT" == true ]]; then
        compress_outputs "$OUTPUT_DIR"
    fi

    # Run post-processing script if specified
    run_post_process "$POST_PROCESS" "$OUTPUT_DIR"
) &
MAIN_PID=$!

# Show progress dashboard
show_progress_dashboard "$OUTPUT_DIR" "$MAIN_PID"

# Wait for main processing to complete
wait "$MAIN_PID"

log_message INFO "Script execution completed successfully."
log_message INFO "Results saved to $OUTPUT_DIR/:"
log_message INFO "- Raw URLs: ${OUTPUT_DIR}/raw.txt"
log_message INFO "- Filtered URLs (uro/grep): ${OUTPUT_DIR}/filtered.txt"
log_message INFO "- Filtered URLs (CDX): ${OUTPUT_DIR}/cdx_filtered.txt"
log_message INFO "- Sensitive PDFs: ${OUTPUT_DIR}/sensitive_pdfs.txt"
log_message INFO "- Sensitive Snippets: ${OUTPUT_DIR}/sensitive_snippets.txt"
log_message INFO "- CSV Summary: ${OUTPUT_DIR}/results.csv"
for suffix in raw.txt filtered.txt cdx_filtered.txt sensitive_pdfs.txt; do
    if [[ -f "${OUTPUT_DIR}/${suffix%.txt}.unique.txt" ]]; then
        log_message INFO "- Unique $suffix: ${OUTPUT_DIR}/${suffix%.txt}.unique.txt"
    fi
    if [[ -f "${OUTPUT_DIR}/${suffix%.txt}.valid.txt" ]]; then
        log_message INFO "- Valid $suffix: ${OUTPUT_DIR}/${suffix%.txt}.valid.txt"
    fi
    if [[ -f "${OUTPUT_DIR}/${suffix%.txt}.nuclei.json" ]]; then
        log_message INFO "- Nuclei results ($suffix): ${OUTPUT_DIR}/${suffix%.txt}.nuclei.json"
    fi
done
for ext in ${EXTENSIONS//|/ }; do
    if [[ -f "${OUTPUT_DIR}/${ext}.txt" ]]; then
        log_message INFO "- $ext URLs: ${OUTPUT_DIR}/${ext}.txt"
    fi
done
log_message INFO "- Summary: ${OUTPUT_DIR}/summary.txt"
log_message INFO "- Log: ${OUTPUT_DIR}/$LOG_FILE"
