import os
import sys
import json
import subprocess
import logging
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# ASCII Art Banner
BANNER = """
⠀⣀⣠⣴⣶⣶⣾⣿⣷⣶⣦⣬⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣤⣤⣀⠀⠀⠀⠀⢀⡔⢁⣤⣶⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣀⣰⣿⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⢀⣀⣀⡀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⢀⣠⣴⣶⣾⣿⡿⠋⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⠟⠁⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣿⣿⡝⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀⠀
⠉⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⣨⣿⣿⡏⢸⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⠿⢿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⠀⣰⡿⠛⣿⠃⠀⡆⠀⢻⣿⣿⣿⣿⣿⣿⠟⢀⡞⢂⠙⣿⣿⣿⣿⣤⣤⣤⣤⣀⣀⠀
⠀⠀⢀⣠⣴⣿⣿⣿⣿⣿⣿⣿⠻⣿⣿⡏⠀⢰⠏⠀⠀⠛⠀⠀⠁⠀⢸⣿⠏⢸⣿⣿⠀⠸⣿⢯⡆⢸⣿⣿⣿⣿⣿⣿⡿⠿⠛⠋⠁
⣠⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⢻⣿⡇⠀⡟⡆⠀⢠⣦⡀⠀⠀⣀⠚⠃⠀⠚⠁⠀⠀⠀⡤⢾⠃⣸⣿⣿⣿⠟⠋⠁⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡤⣄⣹⡇⠀⠀⠱⡀⠈⣻⣷⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⣠⠟⢁⡼⢿⣿⡿⠿⠛⠛⠂⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⢏⠉⢁⠀⠀⠀⠑⢞⠟⠁⠀⠀⠀⠀⣀⣶⠒⠀⠀⠀⠃⣠⠎⠀⠀⠈⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣆⠸⣧⡄⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠌⠳⠄⠀⠀⡜⢁⠀⠀⠀⡀⠀⠈⣶⡖⠒⠒⠂⠤⠤⢄
⠿⠿⠟⠛⠛⠛⠻⠿⠿⠿⢿⣿⣿⣿⣿⡓⡿⠁⠀⠀⢠⠋⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠁⡇⠀⠀⠀⡇⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⣿⡿⠿⠿⡧⠾⢇⣴⠟⢂⠔⢁⠀⠠⣀⠀⠀⠀⠀⣰⡇⢀⠇⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⢠
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟⠋⠁⠀⠀⠀⠙⢆⣈⠙⠒⠁⠴⠋⠀⠀⠀⠀⠁⢀⣾⠟⠀⢸⡦⠀⠀⠀⠀⠳⠀⠀⠀⢀⡠⠤⠤⡖⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠒⠦⢄⡀⠀⠀⠀⠀⣀⣴⠿⠋⠀⠀⡸⠁⢀⠞⠀⠀⢀⠀⠀⠀⠁⠀⠀⡜⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠒⠒⠉⢹⠧⣀⠀⠀⢀⡇⠀⣎⡠⠖⡋⢁⣀⠀⠀⠀⠀⢠⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠛⡆⢫⠑⠄⣼⣠⠞⠉⠀⠀⠈⠉⠉⠉⠙⠒⠲⢤⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡠⢾⠀⣇⠈⣆⡼⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢣⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠀⣘⣴⠧⢴⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠂⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⡼⠋⠀⢠⠃⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠀⢀⠞⠒⡆⠀⡇⣠⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠜
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣯⢀⡎⠀⠀⠓⠸⣶⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠑⡄⠀⠀⠀⠀⠀⠀⡇⡘⣰⠀⠀⠘⠽⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠸⡀⠀⠀⠀⠀⠀⢸⣷⠀⠀⠰⠂⠀⡷⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"""

# Global variables
SCAN_RESULTS = []
TOOLS_PATHS = {
    "nmap": "nmap",
    "sqlmap": "sqlmap",
    "nikto": "nikto",
    "wfuzz": "wfuzz",
    "dirb": "dirb",
    "gobuster": "gobuster",
    "amass": "amass",
    "subfinder": "subfinder",
    "httpx": "httpx",
    "ffuf": "ffuf",
    "nuclei": "nuclei",
    "masscan": "masscan",
    "arjun": "arjun",
    "commix": "commix",
    "sublist3r": "sublist3r",
    "dnsrecon": "dnsrecon",
    "recon-ng": "recon-ng",
    "hydra": "hydra",
    "wapiti": "wapiti",
    "whatweb": "whatweb",
    "curl": "curl",
    "theharvester": "theHarvester",
    "xsstrike": "xsstrike",
    "jq": "jq",
    "knockpy": "knockpy"
}
WORDLIST_PATH = "wordlist.txt"

def ensure_protocol(url):
    """Ensure the URL has a valid protocol (http or https)."""
    parsed_url = urlparse(url)
    if not parsed_url.scheme:
        return f"http://{url}"  # Default to HTTP if no scheme is provided
    return url

def run_tool(tool_name, args):
    """Run an external tool and capture its output."""
    try:
        result = subprocess.run([TOOLS_PATHS[tool_name]] + args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            logging.info(f"{tool_name} completed successfully.")
            return result.stdout
        else:
            logging.error(f"{tool_name} failed with error: {result.stderr}")
            return None
    except Exception as e:
        logging.error(f"Error running {tool_name}: {e}")
        return None

def save_results_to_folder(tool_name, output):
    """Save tool output to a dedicated folder."""
    folder_name = f"results/{tool_name}"
    os.makedirs(folder_name, exist_ok=True)  # Create folder if it doesn't exist
    file_path = f"{folder_name}/{tool_name}_output.txt"
    try:
        with open(file_path, "w") as f:
            f.write(output)
        logging.info(f"Saved {tool_name} output to {file_path}")
        return file_path
    except Exception as e:
        logging.error(f"Error saving {tool_name} output: {e}")
        return None

def scan_with_nmap(target):
    """Perform network scanning using Nmap."""
    logging.info("Running Nmap...")
    output = run_tool("nmap", ["-sV", "-T4", target])
    if output:
        file_path = save_results_to_folder("nmap", output)
        SCAN_RESULTS.append({"type": "Nmap Scan", "output_file": file_path})

def scan_with_sqlmap(url, params):
    """Automate SQL injection exploitation using SQLMap."""
    logging.info("Running SQLMap...")
    param_string = "&".join([f"{k}={v}" for k, v in params.items()])
    output = run_tool("sqlmap", ["-u", f"{url}?{param_string}", "--batch"])
    if output:
        file_path = save_results_to_folder("sqlmap", output)
        SCAN_RESULTS.append({"type": "SQLMap Scan", "output_file": file_path})

def scan_with_nikto(url):
    """Scan web servers for misconfigurations and vulnerabilities using Nikto."""
    logging.info("Running Nikto...")
    output = run_tool("nikto", ["-h", url])
    if output:
        file_path = save_results_to_folder("nikto", output)
        SCAN_RESULTS.append({"type": "Nikto Scan", "output_file": file_path})

def scan_with_wfuzz(url):
    """Brute-force directories, files, and parameters using Wfuzz."""
    logging.info("Running Wfuzz...")
    output = run_tool("wfuzz", ["-c", "-z", f"file,{WORDLIST_PATH}", f"{url}/FUZZ"])
    if output:
        file_path = save_results_to_folder("wfuzz", output)
        SCAN_RESULTS.append({"type": "Wfuzz Scan", "output_file": file_path})

def scan_with_dirb(url):
    """Discover hidden directories and files using Dirb."""
    logging.info("Running Dirb...")
    output = run_tool("dirb", [url, WORDLIST_PATH])
    if output:
        file_path = save_results_to_folder("dirb", output)
        SCAN_RESULTS.append({"type": "Dirb Scan", "output_file": file_path})

def scan_with_gobuster(url):
    """Fast brute-forcing for directories, files, and subdomains using Gobuster."""
    logging.info("Running Gobuster...")
    output = run_tool("gobuster", ["dir", "-u", url, "-w", WORDLIST_PATH])
    if output:
        file_path = save_results_to_folder("gobuster", output)
        SCAN_RESULTS.append({"type": "Gobuster Scan", "output_file": file_path})

def scan_with_amass(domain):
    """Enumerate subdomains and map attack surfaces using Amass."""
    logging.info("Running Amass...")
    output = run_tool("amass", ["enum", "-d", domain])
    if output:
        file_path = save_results_to_folder("amass", output)
        SCAN_RESULTS.append({"type": "Amass Scan", "output_file": file_path})

def scan_with_subfinder(domain):
    """Passive subdomain discovery using Subfinder."""
    logging.info("Running Subfinder...")
    output = run_tool("subfinder", ["-d", domain])
    if output:
        file_path = save_results_to_folder("subfinder", output)
        SCAN_RESULTS.append({"type": "Subfinder Scan", "output_file": file_path})

def save_results_to_file(output_file="scan_results.json"):
    """Save scan results to a JSON file."""
    try:
        with open(output_file, "w") as f:
            json.dump(SCAN_RESULTS, f, indent=4)
        logging.info(f"Scan results saved to {output_file}")
    except Exception as e:
        logging.error(f"Error saving results to file: {e}")

def main():
    print(BANNER)
    if len(sys.argv) != 3:
        print("Usage: python vuln_scanner.py <URL> <parameters>")
        print("Example: python vuln_scanner.py http://example.com/page \"param1=value1&param2=value2\"")
        sys.exit(1)

    target_url = sys.argv[1]
    raw_params = sys.argv[2]

    # Parse parameters into a dictionary
    params = dict(pair.split("=") for pair in raw_params.split("&"))

    # Ensure the URL has a valid protocol
    target_url = ensure_protocol(target_url)

    # Extract domain from the URL
    parsed_url = urlparse(target_url)
    domain = parsed_url.netloc

    # Run scans with various tools
    scan_with_nmap(domain)
    scan_with_sqlmap(target_url, params)
    scan_with_nikto(target_url)
    scan_with_wfuzz(target_url)
    scan_with_dirb(target_url)
    scan_with_gobuster(target_url)
    scan_with_amass(domain)
    scan_with_subfinder(domain)

    # Save results to file
    save_results_to_file()

if __name__ == "__main__":
    main()
